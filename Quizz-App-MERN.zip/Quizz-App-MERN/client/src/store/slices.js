// src/store/userSlice.js
import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  user: null,            // user info from backend
  isAuthenticated: false // track if user is logged in
};

const userSlice = createSlice({
  name: "user",
  initialState,
  reducers: {
    /** Set user data after login */
    setUser: (state, action) => {
      state.user = action.payload;  // just store user object
      state.isAuthenticated = action.payload.isVerified;
    },

    /** Update user details without logging out */
    updateUser: (state, action) => {
      if (state.user) {
        state.user = { ...state.user, ...action.payload };
      }
    },

    /** Logout clears everything */
    logout: (state) => {
      state.user = null;
      state.isAuthenticated = false;
    },
  },
});

export const { setUser, updateUser, logout } = userSlice.actions;
export default userSlice.reducer;
