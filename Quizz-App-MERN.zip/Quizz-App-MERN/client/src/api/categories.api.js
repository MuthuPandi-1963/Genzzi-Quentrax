import AxiosInstance from "./axiosInstance.js";

const url = "categories";

export const CategoriesAPI = {
  // Fetch all categories
  getAll: () => AxiosInstance.get(`/${url}`),

  // Fetch category by ID
  getById: (id) => AxiosInstance.get(`/${url}/${id}`),

  // Create a new category
  create: (data) => AxiosInstance.post(`/${url}`, data),

  // Create multiple categories
  createMany: (data) => AxiosInstance.post(`/${url}/many`, data),

  // Update a category by ID
  update: (id, data) => AxiosInstance.put(`/${url}/${id}`, data),

  // Delete a category by ID
  delete: (id) => AxiosInstance.delete(`/${url}/${id}`),
};

