import axios from 'axios'
import { store } from '../store/store.js'
import { logout } from '../store/slices.js'

const AxiosInstance = axios.create({
  baseURL: import.meta.env.VITE_BACKEND_URL,
  withCredentials: true,
  timeout: 20000, // 20s
  timeoutErrorMessage: "Server is waking up, please wait..."
});

AxiosInstance.interceptors.response.use(
  res => res,
  error => {
    if (error.code === "ECONNABORTED") {
      error.message = "Network is slow or server is initializing";
    }
    
    // Handle 401 Unauthorized - token expired or invalid
    if (error.response && error.response.status === 401) {
      // Clear auth state
      store.dispatch(logout());
      
      // Clear any stored tokens from localStorage if present
      localStorage.removeItem('token');
      localStorage.removeItem('user');
      
      // Redirect to login page if not already there
      if (window.location.pathname !== '/login' && window.location.pathname !== '/signup') {
        window.location.href = '/login';
      }
    }
    
    return Promise.reject(error);
  }
);


export default AxiosInstance;