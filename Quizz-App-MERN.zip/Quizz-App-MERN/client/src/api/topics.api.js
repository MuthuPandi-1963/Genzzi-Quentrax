import AxiosInstance from "./axiosInstance.js";

const url = "topics";

export const TopicsAPI = {
  // Fetch all topics
  getAll: () => AxiosInstance.get(`/${url}`),

  // Fetch topic by ID
  getById: (id) => AxiosInstance.get(`/${url}/${id}`),

  // Create a new topic
  create: (data) => AxiosInstance.post(`/${url}`, data),

  // Create multiple topics
  createMany: (data) => AxiosInstance.post(`/${url}/many`, data),

  // Update a topic by ID
  update: (id, data) => AxiosInstance.put(`/${url}/${id}`, data),

  // Delete a topic by ID
  delete: (id) => AxiosInstance.delete(`/${url}/${id}`),
};

