import AxiosInstance from "./axiosInstance.js";

const url = "questions";

export const QuestionsAPI = {
  // Fetch all questions
  getAll: () => AxiosInstance.get(`/${url}`),

  // Fetch question by ID
  getById: (id) => AxiosInstance.get(`/${url}/${id}`),

  // Create a new question
  create: (data) => AxiosInstance.post(`/${url}`, data),

  // Create multiple questions
  createMany: (data) => AxiosInstance.post(`/${url}/many`, data),

  // Update a question by ID
  update: (id, data) => AxiosInstance.put(`/${url}/${id}`, data),

  // Delete a question by ID
  delete: (id) => AxiosInstance.delete(`/${url}/${id}`),

  getQuestionByTopicId : (id) =>AxiosInstance.get(`/${url}/topic/${id}`)
};

