import {CategoriesAPI} from "./categories.api.js";
import {TopicsAPI} from "./topics.api.js";
import {QuestionsAPI} from "./questions.api.js";
import {QuizAPI} from "./quiz.api.js";
import {QuizHistoryAPI} from "./quiz.history.api.js";
import {AuthAPI} from "./auth.api.js";
import { QuizQuestionsAPI } from "./quiz.questions.api.js";

export {
  CategoriesAPI,
  TopicsAPI,
  QuestionsAPI,
  QuizAPI,
  QuizHistoryAPI,
  AuthAPI,
  QuizQuestionsAPI
  
};


