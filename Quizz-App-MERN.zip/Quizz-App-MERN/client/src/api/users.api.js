import AxiosInstance from "./axiosInstance.js";

export const UsersAPI = {
  getAll: (params) => AxiosInstance.get("/users", { params }),
  getById: (id) => AxiosInstance.get(`/users/${id}`),
  create: (data) => AxiosInstance.post("/users", data),
  update: (id, data) => AxiosInstance.put(`/users/${id}`, data),
  delete: (id) => AxiosInstance.delete(`/users/${id}`),
  updateProfile: (data) => AxiosInstance.put("/users/profile", data),
  changePassword: (data) => AxiosInstance.put("/users/password", data),
};
