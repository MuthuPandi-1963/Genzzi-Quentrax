import AxiosInstance from "./axiosInstance.js";

const url = "quizzes";

export const QuizAPI = {
  // Fetch all quizzes
  getAll: () => AxiosInstance.get(`/${url}`),

  // Fetch quiz by ID
  getById: (id) => AxiosInstance.get(`/${url}/${id}`),

  // Create a new quiz
  create: (data) => AxiosInstance.post(`/${url}`, data),

  // Create multiple quizzes
  createMany: (data) => AxiosInstance.post(`/${url}/many`, data),

  // Update a quiz by ID
  update: (id, data) => AxiosInstance.put(`/${url}/${id}`, data),

  // Delete a quiz by ID
  delete: (id) => AxiosInstance.delete(`/${url}/${id}`),
  getQuizByTopicId : (id) =>AxiosInstance.get(`/${url}/topic/${id}`),

  AddQuestionsInQuiz: (quizId, addedQuestionIds) =>AxiosInstance.put(`/quizzes/${quizId}/questions`, { questions: addedQuestionIds })

};

