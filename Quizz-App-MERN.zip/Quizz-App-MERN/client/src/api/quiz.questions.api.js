import AxiosInstance from "./axiosInstance.js";

const url = "quiz/questions";

export const QuizQuestionsAPI = {
  // Fetch all quiz questions
  getAll: () => AxiosInstance.get(`/${url}`),

  // Fetch quiz question by ID
  getById: (id) => AxiosInstance.get(`/${url}/${id}`),

  // Create a single quiz question
  create: (data) => AxiosInstance.post(`/${url}`, data),

  // Create multiple quiz questions
  createMany: (data) => AxiosInstance.post(`/${url}/many`, data),

  // Delete a quiz question by ID
  delete: (id) => AxiosInstance.delete(`/${url}/${id}`),
};

