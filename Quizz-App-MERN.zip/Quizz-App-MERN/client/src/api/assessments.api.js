import AxiosInstance from "./axiosInstance.js";

/**
 * Assessments API
 * All API calls related to assessments
 */
export const AssessmentsAPI = {
  // ==================== CRUD OPERATIONS ====================
  getAll: (params) => AxiosInstance.get("/assessments", { params }),
  getById: (id) => AxiosInstance.get(`/assessments/${id}`),
  create: (data) => AxiosInstance.post("/assessments", data),
  update: (id, data) => AxiosInstance.put(`/assessments/${id}`, data),
  delete: (id) => AxiosInstance.delete(`/assessments/${id}`),

  // ==================== MY ASSESSMENTS ====================
  getMyAssessments: (params) => AxiosInstance.get("/assessments/my", { params }),

  // ==================== ASSESSMENT ACTIONS ====================
  startAssessment: (id) => AxiosInstance.post(`/assessments/${id}/start`),
  submitAttempt: (id, data) => AxiosInstance.post(`/assessments/${id}/submit`, data),
  publish: (id) => AxiosInstance.post(`/assessments/${id}/publish`),
  getCompletion: (id) => AxiosInstance.get(`/assessments/${id}/completion`),

  // ==================== TOPICS ====================
  getTopics: () => AxiosInstance.get("/assessments/topics"),

  // ==================== ASSIGNMENT ENDPOINTS ====================
  assignUsers: (id, data) => AxiosInstance.post(`/assessments/${id}/assign-users`, data),
  getAssignedUsers: (id, params) => AxiosInstance.get(`/assessments/${id}/assignments`, { params }),
  unassignUser: (assessmentId, userId) =>
    AxiosInstance.delete(`/assessments/${assessmentId}/assignments/${userId}`),
  updateAssignment: (assessmentId, userId, data) =>
    AxiosInstance.put(`/assessments/${assessmentId}/assignments/${userId}`, data),
  getUserAssessments: (userId, params) =>
    AxiosInstance.get(`/assessments/user/${userId}`, { params }),

  // ==================== ASSIGNABLE USERS ====================
  // Used by admin assignment modal
  getAssignableUsers: (params = {}) => AxiosInstance.get("/assessments/assignable-users", { params }),
};