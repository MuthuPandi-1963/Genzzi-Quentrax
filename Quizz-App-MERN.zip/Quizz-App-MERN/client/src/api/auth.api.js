import AxiosInstance from "./axiosInstance.js";

const url = "auth";

export const AuthAPI = {
  // Fetch all categories
  signup: (data) => AxiosInstance.post(`/${url}/signup`,data),
  login: (data) => AxiosInstance.post(`/${url}/login`,data),
  VerifyEmail : (token)=>AxiosInstance.get(`/${url}/verify-email?token=${token}`),
  logout : ()=> AxiosInstance.post(`/${url}/logout`),

  refreshAuth : ()=>AxiosInstance.get(`/${url}/refresh-token`),

  getUser : ()=>AxiosInstance.get("/users"),
  getUserById : (id)=>AxiosInstance.get(`/users/${id}`)


};

