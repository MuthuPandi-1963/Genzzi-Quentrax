import AxiosInstance from "./axiosInstance.js";

const url = "quiz/history";

export const QuizHistoryAPI = {
  // Record a new quiz attempt
  create: (data) => AxiosInstance.post(`/${url}`, data),

  // Fetch all quiz history for a specific user
  getByUser: (userId) => AxiosInstance.get(`/${url}/user/${userId}`),

  // Fetch a single quiz history by ID
  getById: (id) => AxiosInstance.get(`/${url}/${id}`),

  getAllHistory : ()=> AxiosInstance.get(`/${url}/users`)
};

