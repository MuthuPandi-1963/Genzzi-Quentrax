import AxiosInstance from "./axiosInstance.js";

export const DashboardAPI = {
  admin: () => AxiosInstance.get("/dashboard/admin"),
  staff: () => AxiosInstance.get("/dashboard/staff"),
  student: () => AxiosInstance.get("/dashboard/student"),
  analytics: () => AxiosInstance.get("/dashboard/analytics"),
};
