// components/layout/Sidebar.tsx
import React from 'react'
import { Link, useLocation } from 'react-router-dom'
import { 
  LayoutDashboard,
  Users,
  FolderOpen,
  BookOpen,
  HelpCircle,
  Trophy,
  X,
  ChevronLeft
} from 'lucide-react'
import {cn} from '../../lib/utils'
import { Button } from '@/components/ui/button'
// import { ScrollArea } from '@/components/ui/scr  oll-area'

const menuItems = [
  { icon: LayoutDashboard, label: 'Dashboard', path: '/admin' },
  { icon: Trophy, label: 'Quiz Management', path: 'quizzes' },
  { icon: FolderOpen, label: 'Categories', path: 'categories' },
  { icon: BookOpen, label: 'Topics', path: 'topics' },
  { icon: HelpCircle, label: 'Questions', path: 'questions' },
  { icon: HelpCircle, label: 'Assessments', path: 'assessments' },
  { icon: Users, label: 'Student Management', path: 'users' },
  { icon: Trophy, label: 'Quiz History', path: 'quiz/history' },
  { icon: Trophy, label: 'Reports', path: 'reports' },
  { icon: LayoutDashboard, label: 'Analytics', path: 'analytics' },
]



const Sidebar = ({ open, setOpen }) => {
  const location = useLocation()
  const [collapsed, setCollapsed] = React.useState(false)

  return (
    <>
      {/* Mobile overlay */}
      {open && (
        <div 
          className="fixed inset-0 bg-background/80 backdrop-blur-sm z-40 lg:hidden"
          onClick={() => setOpen(false)}
        />
      )}

      <aside
        className={cn(
          "fixed inset-y-0 left-0 z-50 w-64 bg-card border-r transition-transform duration-300 lg:static lg:translate-x-0",
          collapsed && "w-20",
          !open && "-translate-x-full lg:translate-x-0"
        )}
      >
        <div className="flex flex-col h-full">
          {/* Header */}
          <div className="flex items-center justify-between p-4 border-b">
              <Link to={"/"}>
            <div className={cn("flex items-center gap-2", collapsed && "justify-center")}>
              <Trophy className="h-6 w-6 text-primary" />
              {!collapsed && (
                <span className="text-lg font-semibold">quentrax</span>
              )}

            </div>
              </Link>
            
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setCollapsed(!collapsed)}
              className={cn("hidden lg:flex", collapsed && "mx-auto")}
            >
              <ChevronLeft className={cn("h-4 w-4 transition-transform", collapsed && "rotate-180")} />
            </Button>
            
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setOpen(false)}
              className="lg:hidden"
            >
              <X className="h-4 w-4" />
            </Button>
          </div>

          {/* Navigation */}
          <div className="flex-1 p-4">
            <nav className="space-y-2">
              {menuItems.map((item) => {
                const isActive = location.pathname === item.path
                return (
                  <Link
                    key={item.path}
                    to={item.path}
                    onClick={() => setOpen(false)}
                    className={cn(
                      "flex items-center gap-3 rounded-lg px-3 py-2 text-sm transition-colors hover:bg-accent",
                      isActive && "bg-accent text-accent-foreground",
                      collapsed && "justify-center"
                    )}
                  >
                    <item.icon className="h-4 w-4" />
                    {!collapsed && <span>{item.label}</span>}
                  </Link>
                )
              })}
            </nav>
          </div>
        </div>
      </aside>
    </>
  )
}

export default Sidebar