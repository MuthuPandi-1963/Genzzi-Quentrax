import { Users, Trophy, Activity, ClipboardList } from "lucide-react";
import { useSelector } from "react-redux";
import { useDashboard } from "@/hooks/useDashboard";
import StatCard from "../../components/custom/StatCard";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import React from "react";
const Dashboard = () => {
  const role = useSelector((s) => s.user.user?.role);
  const { adminQuery, staffQuery } = useDashboard();

  const isAdmin = role === "ADMIN";
  const query = isAdmin ? adminQuery : staffQuery;
  const stats = query.data;
  const isLoading = query.isLoading;

  if (isLoading) return <div>Loading...</div>;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">
          {isAdmin ? "Admin Dashboard" : "Staff Dashboard"}
        </h1>
        <p className="text-muted-foreground">
          Monitor quizzes, assessments, and student activity.
        </p>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {isAdmin ? (
          <>
            <StatCard title="Total Students" value={stats?.totalStudents ?? 0} icon={Users} />
            <StatCard title="Staff" value={stats?.totalStaff ?? 0} icon={Users} />
            <StatCard title="Quizzes" value={stats?.totalQuizzes ?? 0} icon={Trophy} />
            <StatCard
              title="Active Assessments"
              value={stats?.activeAssessments ?? 0}
              icon={ClipboardList}
            />
          </>
        ) : (
          <>
            <StatCard title="My Quizzes" value={stats?.myQuizzes ?? 0} icon={Trophy} />
            <StatCard title="My Assessments" value={stats?.myAssessments ?? 0} icon={ClipboardList} />
            <StatCard title="Students" value={stats?.totalStudents ?? 0} icon={Users} />
            <StatCard title="Pending" value={stats?.pendingAssignments ?? 0} icon={Activity} />
          </>
        )}
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Recent attempts</CardTitle>
        </CardHeader>
        <CardContent className="space-y-2">
          {(stats?.recentAttempts ?? []).map((a, i) => (
            <div key={a.id ?? i} className="flex justify-between text-sm border-b py-2">
              <span>
                {a.user?.name} — {a.quiz?.title}
              </span>
              <span className="font-medium">{a.score}%</span>
            </div>
          ))}
          {!stats?.recentAttempts?.length && (
            <p className="text-sm text-muted-foreground">No recent activity.</p>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default Dashboard;
