// components/layout/Topbar.tsx
import React, { useState } from 'react'
import { Search, Bell, Sun, Moon, User, LogOut, Settings, PanelRightClose, Home } from 'lucide-react'
// import { useTheme } from '../theme-provider'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
// import { useTheme } from '../../hooks/useTheme'
import { useAuth } from '../../hooks/useAuth'
import { Link, useNavigate } from 'react-router-dom'


const Topbar = ({ onMenuClick }) => {
  // const { theme, setTheme } = useTheme()
        const theme = "light"

  const {useLogout} = useAuth(); 
  const [searchQuery, setSearchQuery] = useState('')
  const navigate = useNavigate();

  const handleLogout = async () => {
    try {
      await useLogout.mutateAsync();
      // Clear any user-related state here if needed
      navigate('/login');
      window.location.reload()
    } catch (error) {
      console.error('Logout failed:', error);
    }
  }


  return (
    <header className="flex items-center justify-between p-4 border-b bg-card">
      <div className="flex items-center gap-4">
        <Button
          variant="ghost"
          size="icon"
          onClick={onMenuClick}
          className="lg:hidden"
        >
          <PanelRightClose className="h-4 w-4" />
        </Button>
        
        <div className="relative w-80">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search users, quizzes, categories..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>
      </div>

      <div className="flex items-center gap-4">
        {/* <Button
          variant="ghost"
          size="icon"
          onClick={() => setTheme(theme === 'light' ? 'dark' : 'light')}
        >
          {theme === 'light' ? <Moon className="h-4 w-4" /> : <Sun className="h-4 w-4" />}
        </Button> */}

          <Link to={"/"}>
        <Button variant="ghost" size="icon" className="relative">
          <Home className="h-4 w-4" />
          <span className="absolute -top-1 -right-1 h-2 w-2 bg-red-500 rounded-full" />
        </Button>
          </Link>

        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" className="relative h-8 w-8 rounded-full">
              <User className="h-4 w-4" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuLabel>Admin User</DropdownMenuLabel>
            <DropdownMenuSeparator />
            {/* <DropdownMenuItem>
              <Settings className="h-4 w-4 mr-2" />
              Settings
            </DropdownMenuItem> */}
            <DropdownMenuItem>
              <Button onClick={handleLogout} variant="ghost" className="w-full flex items-center p-0">
              <LogOut className="h-4 w-4 mr-2" />
              Logout
              </Button>
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </header>
  )
}

export default Topbar