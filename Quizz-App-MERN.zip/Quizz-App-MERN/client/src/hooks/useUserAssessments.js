import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { AssessmentsAPI } from "../api/assessments.api";

/**
 * Get current user assessments
 */
export const useMyAssessments = () =>
  useQuery({
    queryKey: ["userAssessments"],
    queryFn: () => AssessmentsAPI.getMyAssessments(),
    select: (res) => {
      const assignments = res.data?.data || [];

      return {
        assessments: assignments,
        activeAssessments: assignments.filter(
          (a) => a.status === "IN_PROGRESS" || a.status === "PENDING"
        ),
        upcomingAssessments: assignments.filter(
          (a) => a.status === "UPCOMING"
        ),
        expiredAssessments: assignments.filter(
          (a) => a.status === "EXPIRED"
        ),
      };
    },
  });

/**
 * Start assessment
 */
export const useRefAssessmentStart = () => {
  const queryClient = useQueryClient();

  const mutation = useMutation({
    mutationFn: (assessmentId) =>
      AssessmentsAPI.startAssessment(assessmentId),

    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["userAssessments"] });
    },
  });

  return {
    startAssessment: mutation.mutate,
    isLoading: mutation.isPending,
    ...mutation,
  };
};

/**
 * ✅ ADD THIS (missing hook)
 * Compute assessment availability state
 */
export const useAssessmentState = (assessment) => {
  if (!assessment) {
    return {
      state: "unknown",
      isAvailable: false,
      reason: "No assessment",
      buttonLabel: "Unavailable",
    };
  }

  const now = new Date();
  const start = assessment.startDate ? new Date(assessment.startDate) : null;
  const end = assessment.endDate ? new Date(assessment.endDate) : null;

  if (assessment.published === false) {
    return {
      state: "draft",
      isAvailable: false,
      reason: "Not published yet",
      buttonLabel: "Not Available",
    };
  }

  if (start && now < start) {
    return {
      state: "upcoming",
      isAvailable: false,
      reason: "Assessment not started yet",
      buttonLabel: "Upcoming",
    };
  }

  if (end && now > end) {
    return {
      state: "expired",
      isAvailable: false,
      reason: "Assessment expired",
      buttonLabel: "Expired",
    };
  }

  return {
    state: "active",
    isAvailable: true,
    reason: null,
    buttonLabel: "Start",
  };
};