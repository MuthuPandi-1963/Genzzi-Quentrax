import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { QuizHistoryAPI } from "../api/quiz.history.api";

export const useQuizHistory = () => {
  const queryClient = useQueryClient();

  // Fetch all quizzes
  const { data, isLoading, isError } = useQuery({
    queryKey: ["quiz-history"],
    queryFn: QuizHistoryAPI.getAllHistory,// Adjust if your API wraps data
    select : (res)=>res.data,
    staleTime: 1000 * 60 * 5, // 5 minutes cache
  });

  // Mutation: Create a new quiz
  const createQuiz = useMutation({
    mutationFn: QuizHistoryAPI.create,
    onSuccess: () => queryClient.invalidateQueries(["quiz-history"]),
  });

  

  return {
    quizHistory: data || [],
    isLoading,
    isError,
    createQuiz,
  };
};
