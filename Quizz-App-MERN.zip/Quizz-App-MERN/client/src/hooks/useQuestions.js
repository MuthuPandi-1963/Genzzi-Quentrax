import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { QuestionsAPI } from "../api/questions.api";

export const useQuestions = () => {
  const queryClient = useQueryClient();

  // Fetch all questions
  const { data, isLoading, isError } = useQuery({
    queryKey: ["questions"],
    queryFn: QuestionsAPI.getAll,
    select: (res) => res.data, // Adjust if your API wraps data
    staleTime: 1000 * 60 * 5, // 5 minutes cache
  });

  // Mutation: Create a new question
  const createQuestion = useMutation({
    mutationFn: QuestionsAPI.create,
    onSuccess: () => queryClient.invalidateQueries(["questions"]),
  });
  const createManyQuestion = useMutation({
    mutationFn: QuestionsAPI.createMany,
    onSuccess: () => queryClient.invalidateQueries(["questions"]),
  });

  // Mutation: Update a question
  const updateQuestion = useMutation({
    mutationFn: ({ id, payload }) => QuestionsAPI.update(id, payload),
    onSuccess: () => queryClient.invalidateQueries(["questions"]),
  });

  // Mutation: Delete a question
  const deleteQuestion = useMutation({
    mutationFn: (id) => QuestionsAPI.delete(id),
    onSuccess: () => queryClient.invalidateQueries(["questions"]),
  });

  return {
    questions: data || [],
    isLoading,
    isError,
    createQuestion,
    updateQuestion,
    deleteQuestion,
    createManyQuestion
  };
};


export const getQuestionByTopicId = (id)=>{
  const {data,isLoading,isError} = useQuery({
    queryKey : ["questions","topic",id],
    queryFn :()=> QuestionsAPI.getQuestionByTopicId(id),
    enabled : !!id
  })
  return {data,isLoading,isError}
}