import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { QuizAPI } from "../api/quiz.api";

export const useQuizzes = () => {
  const queryClient = useQueryClient();

  // Fetch all quizzes
  const { data, isLoading, isError } = useQuery({
    queryKey: ["quizzes"],
    queryFn: QuizAPI.getAll,
    select: (res) => res.data, // Adjust if your API wraps data
    staleTime: 1000 * 60 * 5, // 5 minutes cache
  });

  // Mutation: Create a new quiz
  const createQuiz = useMutation({
    mutationFn: QuizAPI.create,
    onSuccess: () => queryClient.invalidateQueries(["quizzes"]),
  });

  // Mutation: Update a quiz
  const updateQuiz = useMutation({
    mutationFn: ({ id, payload }) => QuizAPI.update(id, payload),
    onSuccess: () => queryClient.invalidateQueries(["quizzes"]),
  });

  // Mutation: Delete a quiz
  const deleteQuiz = useMutation({
    mutationFn: (id) => QuizAPI.delete(id),
    onSuccess: () => queryClient.invalidateQueries(["quizzes"]),
  });

  return {
    quizzes: data || [],
    isLoading,
    isError,
    createQuiz,
    updateQuiz,
    deleteQuiz,
  };
};
export const useQuizzesByTopic = (topicId, options = {}) => {
  return useQuery({
    queryKey: ["quizzes", "topic", topicId],
    queryFn: () => QuizAPI.getQuizByTopicId(topicId),
    select: (res) => res.data?.data || [],
    enabled: !!topicId, // Only run when topicId exists
    staleTime: 1000 * 60 * 5,
    ...options,
  });
};

export const useQuizQuestionById = (id) => {
  return useQuery({
    queryKey: ['quiz-question', id],           // object form
    queryFn: () => QuizQuestionsAPI.getById(id), // object form
    enabled: !!id,                              // only fetch if id exists
  })
}

export const useQuestionsByTopic = (topicId) => {
  return useQuery({
    queryKey: ['topic-questions', topicId],
    queryFn: () => QuizQuestionsAPI.getByTopicId(topicId),
    enabled: !!topicId,
  })
}

export const useAddQuestionsInQuiz = (quizId) => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: (questions) => QuizAPI.AddQuestionsInQuiz(quizId, questions),
    onSuccess: (data) => {
      // Invalidate quizzes to refetch updated data
      queryClient.invalidateQueries(["quizzes"]);
    },
    onError: (error) => {
      console.error("Failed to add questions:", error);
    },
  });
};