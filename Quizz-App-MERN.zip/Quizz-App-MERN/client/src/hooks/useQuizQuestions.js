// hooks/useQuizQuestions.js
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { QuizQuestionsAPI } from "../api/quiz.questions.api";

export const useQuizQuestions = () => {
  const queryClient = useQueryClient();

  /** -----------------------------
   *  Fetch All Questions
   * ----------------------------*/
  const {
    data: questions,
    isLoading,
    isError,
  } = useQuery({
    queryKey: ["quiz-questions"],
    queryFn: QuizQuestionsAPI.getAll,
    select: (res) => res.data,
    staleTime: 1000 * 60 * 5, // cache for 5 mins
  });

  /** -----------------------------
   *  Create Single Question
   * ----------------------------*/
  const createQuestion = useMutation({
    mutationFn: QuizQuestionsAPI.create,
    onSuccess: () => queryClient.invalidateQueries(["quiz-questions"]),
  });

  /** -----------------------------
   *  Create Many Questions
   * ----------------------------*/
  const createManyQuestions = useMutation({
    mutationFn: QuizQuestionsAPI.createMany,
    onSuccess: () => queryClient.invalidateQueries(["quiz-questions"]),
  });

  /** -----------------------------
   *  Update a Question
   * ----------------------------*/
  const updateQuestion = useMutation({
    mutationFn: ({ id, payload }) => QuizQuestionsAPI.update(id, payload),
    onSuccess: () => queryClient.invalidateQueries(["quiz-questions"]),
  });

  /** -----------------------------
   *  Delete a Question
   * ----------------------------*/
  const deleteQuestion = useMutation({
    mutationFn: (id) => QuizQuestionsAPI.delete(id),
    onSuccess: () => queryClient.invalidateQueries(["quiz-questions"]),
  });

  return {
    // questions: questions || [],
    // isLoading,
    // isError,
    createQuestion,
    createManyQuestions,
    updateQuestion,
    deleteQuestion,
  };
};


export const getQuestionsByQuizId = (id)=>{
    const {data,isLoading,isError} = useQuery({
        queryKey : ["questions","quiz",id],
        queryFn : ()=>QuizQuestionsAPI.getById(id),
        enabled : !!id
    })
    return {data,isLoading,isError}
}