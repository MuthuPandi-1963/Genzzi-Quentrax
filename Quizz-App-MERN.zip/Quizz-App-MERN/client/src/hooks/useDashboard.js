import { useQuery } from "@tanstack/react-query";
import { DashboardAPI } from "../api/dashboard.api";
import { useSelector } from "react-redux";

export const useDashboard = () => {
  const role = useSelector((s) => s.user.user?.role);

  const adminQuery = useQuery({
    queryKey: ["dashboard", "admin"],
    queryFn: () => DashboardAPI.admin(),
    select: (r) => r.data.data,
    enabled: role === "ADMIN",
  });

  const staffQuery = useQuery({
    queryKey: ["dashboard", "staff"],
    queryFn: () => DashboardAPI.staff(),
    select: (r) => r.data.data,
    enabled: role === "STAFF" || role === "ADMIN",
  });

  const studentQuery = useQuery({
    queryKey: ["dashboard", "student"],
    queryFn: () => DashboardAPI.student(),
    select: (r) => r.data.data,
    enabled: role === "STUDENT",
  });

  const analyticsQuery = useQuery({
    queryKey: ["dashboard", "analytics"],
    queryFn: () => DashboardAPI.analytics(),
    select: (r) => r.data.data,
    enabled: role === "STAFF" || role === "ADMIN",
  });

  return { adminQuery, staffQuery, studentQuery, analyticsQuery, role };
};
