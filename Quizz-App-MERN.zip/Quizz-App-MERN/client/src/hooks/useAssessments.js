import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import axios from 'axios';

const API_BASE = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';

export const useAssessments = () => {
  return useQuery({
    queryKey: ['assessments'],
    queryFn: async () => {
      const { data } = await axios.get(`${API_BASE}/assessments`);
      // Backend returns { success, message, count, data: assessments }
      // Frontend expects an array.
      return Array.isArray(data)
        ? data
        : Array.isArray(data?.data)
        ? data.data
        : [];
    },
  });
};


export const useAssessmentMutations = () => {
  const queryClient = useQueryClient();

  const create = useMutation({
    mutationFn: async (payload) => {
      const { data } = await axios.post(`${API_BASE}/assessments`, payload);
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['assessments'] });
    },
  });

  const update = useMutation({
    mutationFn: async ({ id, ...payload }) => {
      const { data } = await axios.put(`${API_BASE}/assessments/${id}`, payload);
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['assessments'] });
    },
  });

  const remove = useMutation({
    mutationFn: async (id) => {
      await axios.delete(`${API_BASE}/assessments/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['assessments'] });
    },
  });

  return { create, update, remove };
};