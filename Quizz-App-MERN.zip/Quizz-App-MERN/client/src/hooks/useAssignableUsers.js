import { useQuery } from "@tanstack/react-query";

import { AssessmentsAPI } from "@/api/assessments.api";

export const useAssignableUsers = () => {
  const {
    data,
    isLoading,
    error,
    refetch,
  } = useQuery({
    queryKey: ["assessments", "assignable-users"],
    queryFn: async () => {
      const response = await AssessmentsAPI.getAssignableUsers();
      return response.data;
    },
    staleTime: 5 * 60 * 1000,
    retry: 1,
    select: (res) => res?.data || [],
  });

  return {
    users: data,
    loading: isLoading,
    error,
    refetch,
  };
};

