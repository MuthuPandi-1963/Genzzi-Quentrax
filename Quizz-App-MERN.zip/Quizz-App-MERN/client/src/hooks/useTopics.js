import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { TopicsAPI } from "../api/topics.api";

export const useTopics = () => {
  const queryClient = useQueryClient();

  // Fetch all topics
  const { data, isLoading, isError ,error} = useQuery({
    queryKey: ["topics"],
    queryFn: TopicsAPI.getAll,
    select: (res) => res.data, // Adjust if your API wraps data
    staleTime: 1000 * 60 * 5, // Cache for 5 minutes
    refetchOnWindowFocus: false,
    retry  : 0,
  });

  // Mutation: Create a new topic
  const createTopic = useMutation({
    mutationFn: TopicsAPI.create,
    onSuccess: () => queryClient.invalidateQueries(["topics"]),
  });

  // Mutation: Update a topic
  const updateTopic = useMutation({
    mutationFn: ({ id, data }) => TopicsAPI.update(id, data),
    onSuccess: () => queryClient.invalidateQueries(["topics"]),
  });

  // Mutation: Delete a topic
  const deleteTopic = useMutation({
    mutationFn: (id) => TopicsAPI.delete(id),
    onSuccess: () => queryClient.invalidateQueries(["topics"]),
  });
  console.log(data,isError,error);
  
  return {
    topics: !isError && data || [],
    isLoading,
    isError,
    createTopic,
    updateTopic,
    deleteTopic,
  };
};
