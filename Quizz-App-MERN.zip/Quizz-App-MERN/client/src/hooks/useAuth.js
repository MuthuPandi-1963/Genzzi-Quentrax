import { useMutation, useQuery } from "@tanstack/react-query"
import { AuthAPI } from "../api/auth.api"

 export const useAuth = ()=>{
    const useSignup = useMutation({
        mutationFn : AuthAPI.signup,
    })

    const useLogin = useMutation({
        mutationFn : AuthAPI.login
    })

    const useVerifyEmail = (token)=> useQuery({
        queryKey : ["auth",token],
        queryFn :()=> AuthAPI.VerifyEmail(token),
        enabled : !!token
    })
     
    const useLogout = useMutation({
        mutationFn : AuthAPI.logout
    })
    const useRefreshAuth = useMutation({
        mutationFn : AuthAPI.refreshAuth
    })
    return {useSignup,useLogin,useVerifyEmail,useLogout,useRefreshAuth}
}

export const getUsers = ()=>{
    return useQuery({
        queryKey : ["users"],
        queryFn : AuthAPI.getUser,
        refetchOnWindowFocus : false,
        retry : 1,
        select : (res)=>res.data    
    })
}

export const getUsersById = (id) => {
   const {data,isLoading,isError} = useQuery({
    queryKey: ["users", id],
    queryFn: () => AuthAPI.getUserById(id),
    refetchOnWindowFocus: false,
    retry: 1,
    select: (res) => res.data,
    enabled: !!id, // only run query if id exists
  });
  console.log(data);
  
  return {data,isLoading,isError}
};

