import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { CategoriesAPI } from "../api/categories.api";

export const useCategories = () => {
  const queryClient = useQueryClient();

  // Fetch all categories
  const { data, isLoading, isError } = useQuery({
    queryKey: ["categories"],
    queryFn: CategoriesAPI.getAll,
    select: (res) => res.data, // Adjust if your API wraps data
    staleTime: 1000 * 60 * 5,  // 5 minutes cache
  });

  // Mutation: Create a new category
  const createCategory = useMutation({
    mutationFn: CategoriesAPI.create,
    onSuccess: () => {
      // Invalidate categories query to refetch updated list
      queryClient.invalidateQueries(["categories"]);
    },
  });

  // Mutation: Update an existing category
  const updateCategory = useMutation({
    mutationFn: ({id, data}) =>{
      console.log(id,data);
      
      return CategoriesAPI.update(id, data)
    },
    onSuccess: () => queryClient.invalidateQueries(["categories"]),
  });

  // Mutation: Delete a category
  const deleteCategory = useMutation({
    mutationFn: (id) => CategoriesAPI.delete(id),
    onSuccess: () => queryClient.invalidateQueries(["categories"]),
  });

  return {
    categories: data || [],
    isLoading,
    isError,
    createCategory,
    updateCategory,
    deleteCategory,
  };
};
