import React from 'react'
import { MainRoutes } from './routes/Main';
import { useDispatch } from 'react-redux';
import { useAuth } from './hooks/useAuth';
import { useEffect } from 'react';
import { setUser } from './store/slices';
import AdminRoutes from './routes/Admin';
import { Route, Routes, useLocation, useNavigate } from 'react-router-dom';
import { StaffAdminRoutes } from "./routes/PrivateRoute";
import { getRoleHomePath } from "./utils/roleRedirect";

export default function App() {
  const { useRefreshAuth } = useAuth();
  const refreshAuth = useRefreshAuth;  
  const {pathname} = useLocation()
  const nav = useNavigate()

  const dispatch = useDispatch()
  useEffect(() => {
    refreshAuth.mutate(undefined, {
      onSuccess: (res) => {
        const user = res.data?.data;
        dispatch(setUser(user));
        const saved = localStorage.getItem("redirectPath");
        const target =
          saved && saved !== "/login" && saved !== "/signup"
            ? saved
            : getRoleHomePath(user?.role);
        nav(target || "/");
      },
      onError: (err) => {
        console.error("Refresh Auth Error:", err);
      },
    });
  }, []);

  useEffect(()=>{

    if(!(pathname.includes("login") || pathname.includes("signup"))){

      localStorage.setItem("redirectPath",pathname)
    }
  },[pathname])

  return (
    <>
      <Routes>
        {MainRoutes}
        <Route element={<StaffAdminRoutes />}>{AdminRoutes}</Route>
      </Routes>
    </>
  );
}
