// pages/QuizHistory.tsx
import React, { useState } from 'react'
import { Search, Filter, CheckCircle, XCircle, Eye, Download } from 'lucide-react'
import { useQuery } from '@tanstack/react-query'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Badge } from '@/components/ui/badge'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { useQuizHistory } from '../../hooks/useQuizHistory'


const QuizHistory = () => {
  const [searchTerm, setSearchTerm] = useState('')
  const [dateFilter, setDateFilter] = useState('all')
  const {quizHistory : {data : quizHistory}} = useQuizHistory()

  // const quizHistory = [
  //       { 
  //         id: 1, 
  //         user: 'John Doe', 
  //         quiz: 'JavaScript Fundamentals',
  //         score: 85,
  //         totalQuestions: 20,
  //         correctAnswers: 17,
  //         timeSpent: '25:30',
  //         completedAt: '2023-11-15 14:30:00',
  //         status: 'completed'
  //       },
  //       { 
  //         id: 2, 
  //         user: 'Sarah Smith', 
  //         quiz: 'React Advanced Patterns',
  //         score: 92,
  //         totalQuestions: 15,
  //         correctAnswers: 14,
  //         timeSpent: '35:15',
  //         completedAt: '2023-11-14 16:45:00',
  //         status: 'completed'
  //       },
  //     ]
  const getScoreColor = (score) => {
    if (score >= 90) return 'text-green-600'
    if (score >= 70) return 'text-yellow-600'
    return 'text-red-600'
  }

  function countCorrectAnswers(answers) {
  // Parse JSON if it's a string
  const parsedAnswers = typeof answers === "string" ? JSON.parse(answers) : answers;

  // Filter answers where isCorrect is true
  const correctAnswers = parsedAnswers.filter(item => item.isCorrect);

  // Return both the count and the filtered array
  return {
    count: correctAnswers.length,
    correctAnswers,
    total : parsedAnswers.length
  }
}
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Quiz History</h1>
          <p className="text-muted-foreground">Track and analyze quiz attempts</p>
        </div>
        <Button variant="outline">
          <Download className="h-4 w-4 mr-2" />
          Export CSV
        </Button>
      </div>

      {/* Filters */}
      <div className="flex gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search by user or quiz..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>
        <Select value={dateFilter} onValueChange={setDateFilter}>
          <SelectTrigger className="w-40">
            <SelectValue placeholder="Date Range" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Time</SelectItem>
            <SelectItem value="today">Today</SelectItem>
            <SelectItem value="week">This Week</SelectItem>
            <SelectItem value="month">This Month</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Quiz History Table */}
      <div className="border rounded-lg">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>User</TableHead>
              <TableHead>Email</TableHead>
              <TableHead>Quiz Title</TableHead>
              <TableHead>Score</TableHead>
              <TableHead>Correct Answers</TableHead>
              <TableHead>Completed</TableHead>
              <TableHead>Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {quizHistory?.map((attempt) => (
              <TableRow key={attempt.id}>
                <TableCell className="font-medium">{attempt.user.name}</TableCell>
                <TableCell className="font-medium">{attempt.user.email}</TableCell>
                <TableCell>{attempt.quiz.title}</TableCell>
                <TableCell>
                  <span className={`font-bold ${getScoreColor(attempt.score)}`}>
                    {attempt.score}
                  </span>
                </TableCell>
                <TableCell>
                  {countCorrectAnswers(attempt.answers).count} / {countCorrectAnswers(attempt.answers).total}
                </TableCell>
                <TableCell>{new Date(attempt.completedAt) <= Date.now() ? "Completed" : "pending"}</TableCell>
                <TableCell>
                  {new Date(attempt.completedAt).toLocaleString()}
                </TableCell>
                {/* <TableCell>
                  <Button variant="ghost" size="icon">
                    <Eye className="h-4 w-4" />
                  </Button>
                </TableCell> */}
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  )
}

export default QuizHistory;