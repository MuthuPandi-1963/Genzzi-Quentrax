// components/dashboard/AnalyticsCharts.tsx
import React from 'react'
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar, PieChart, Pie, Cell } from 'recharts'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs'

const participationData = [
  { month: 'Jan', participants: 400 },
  { month: 'Feb', participants: 600 },
  { month: 'Mar', participants: 800 },
  { month: 'Apr', participants: 1200 },
  { month: 'May', participants: 1800 },
  { month: 'Jun', participants: 2400 },
]

const categoryData = [
  { name: 'JavaScript', activity: 400 },
  { name: 'Python', activity: 300 },
  { name: 'React', activity: 200 },
  { name: 'Node.js', activity: 150 },
  { name: 'CSS', activity: 100 },
]

const roleData = [
  { name: 'Students', value: 75 },
  { name: 'Teachers', value: 15 },
  { name: 'Admins', value: 10 },
]

const COLORS = ['#d97706', '#06b6d4', '#fbbf24', '#f87171', '#a78bfa']

const AnalyticsCharts = () => {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Analytics Overview</CardTitle>
        <CardDescription>Platform performance and user engagement metrics</CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="participation">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="participation">Participation</TabsTrigger>
            <TabsTrigger value="categories">Categories</TabsTrigger>
            <TabsTrigger value="users">Users</TabsTrigger>
          </TabsList>
          
          <TabsContent value="participation" className="space-y-4">
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={participationData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis />
                  <Tooltip />
                  <Line type="monotone" dataKey="participants" stroke="#8884d8" strokeWidth={2} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </TabsContent>
          
          <TabsContent value="categories" className="space-y-4">
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={categoryData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis />
                  <Tooltip />
                  <Bar dataKey="activity" fill="#8884d8" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </TabsContent>
          
          <TabsContent value="users" className="space-y-4">
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={roleData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                    outerRadius={80}
                    fill="#d97706"
                    dataKey="value"
                  >
                    {roleData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  )
}

export default AnalyticsCharts