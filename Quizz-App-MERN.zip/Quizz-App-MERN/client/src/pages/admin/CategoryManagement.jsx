// pages/CategoryManagement.tsx
import React, { useState } from 'react'
import { Plus, Search, Image, Edit, Trash2, MoreHorizontal } from 'lucide-react'
import { useQuery } from '@tanstack/react-query'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Badge } from '@/components/ui/badge'
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu'
import CategoryForm from '../../components/forms/CategoryForm'
import { useCategories } from '../../hooks/useCategories'


const CategoryManagement = () => {
  const [searchTerm, setSearchTerm] = useState('')
  const [isFormOpen, setIsFormOpen] = useState(false)
  const [editingCategory, setEditingCategory] = useState(null)
  const {categories : {data : categories},isLoading} = useCategories()

  const filteredCategories = categories?.filter(category => 
    category.name.toLowerCase().includes(searchTerm.toLowerCase())
  )

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Category Management</h1>
          <p className="text-muted-foreground">Organize quizzes by categories and topics</p>
        </div>
        <Button onClick={() => setIsFormOpen(true)}>
          <Plus className="h-4 w-4 mr-2" />
          Add Category
        </Button>
      </div>

      {/* Search */}
      <div className="flex gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search categories..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>
      </div>

      {/* Categories Table */}
<div className="border rounded-lg">
  <Table className="w-full text-center">
    {/* Table Header */}
    <TableHeader>
      <TableRow>
        <TableHead className="text-center w-20">Image</TableHead>
        <TableHead className="text-center w-40">Title</TableHead>
        <TableHead className="text-center w-80">Description</TableHead>
        <TableHead className="text-center w-32">Created</TableHead>
        <TableHead className="text-center w-20">More</TableHead>
      </TableRow>
    </TableHeader>

    {/* Table Body */}
    <TableBody>
    
      {filteredCategories?.map((category) => (
        <TableRow key={category.id} className="hover:bg-muted/50">
          {/* Image Cell */}
          <TableCell className="text-center">
            <div className="flex items-center justify-center">
              <div className="h-10 w-10 rounded-lg bg-muted flex items-center justify-center">
                {category.imageUrl ? (
                  <img
                    src={category.imageUrl}
                    alt={category.name}
                    className="h-8 w-8 rounded object-cover"
                  />
                ) : (
                  <Image className="h-5 w-5 text-muted-foreground" />
                )}
              </div>
            </div>
          </TableCell>

          {/* Title Cell */}
          <TableCell className="text-center">
            <div className="font-medium">{category.name}</div>
          </TableCell>

          {/* Description Cell */}
          <TableCell className="text-sm text-muted-foreground text-center truncate max-w-[20rem]">
            {category.description}
          </TableCell>

          {/* Created Date Cell */}
          <TableCell className="text-center">
            {new Date(category.createdAt).toLocaleDateString()}
          </TableCell>

          {/* Action Menu */}
          <TableCell className="text-center">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon">
                  <MoreHorizontal className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem
                  onClick={() => {
                    setEditingCategory(category);
                    setIsFormOpen(true);
                  }}
                >
                  <Edit className="h-4 w-4 mr-2" />
                  Edit
                </DropdownMenuItem>
                <DropdownMenuItem className="text-red-600">
                  <Trash2 className="h-4 w-4 mr-2" />
                  Delete
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </TableCell>
        </TableRow>
      ))}
    </TableBody>
  </Table>
</div>


      <CategoryForm 
        open={isFormOpen} 
        onOpenChange={setIsFormOpen}
        category={editingCategory}
        onSuccess={() => {
          setIsFormOpen(false)
          setEditingCategory(null)
        }}
      />
    </div>
  )
}

export default CategoryManagement;