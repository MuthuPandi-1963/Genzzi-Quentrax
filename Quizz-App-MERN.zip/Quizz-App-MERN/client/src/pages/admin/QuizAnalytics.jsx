eimport { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { BarChart3, Users, Trophy, Clock, TrendingUp, AlertTriangle } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

const QuizAnalytics = () => {
  const { quizId } = useParams();
  const [analytics, setAnalytics] = useState(null);
  const [loading, setLoading] = useState(true);
  const [quiz, setQuiz] = useState(null);

  useEffect(() => {
    fetchAnalytics();
  }, [quizId]);

  const fetchAnalytics = async () => {
    try {
      const response = await fetch(`/api/attempts/quiz/${quizId}/analytics`);
      const data = await response.json();
      if (data.success) {
        setAnalytics(data.data);
      }
    } catch (error) {
      console.error('Error fetching analytics:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (!analytics) {
    return (
      <div className="min-h-screen bg-gray-50 p-6">
        <div className="max-w-7xl mx-auto">
          <Card>
            <CardContent className="py-12 text-center text-gray-500">
              No analytics data available for this quiz.
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">Quiz Analytics</h1>
          <p className="text-gray-600 mt-2">Performance metrics and insights</p>
        </div>

        {/* Overview Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-3">
              <CardTitle className="text-sm font-medium text-gray-600">Total Attempts</CardTitle>
              <BarChart3 className="w-5 h-5 text-blue-600" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-gray-900">{analytics.totalAttempts}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-3">
              <CardTitle className="text-sm font-medium text-gray-600">Pass Rate</CardTitle>
              <TrendingUp className="w-5 h-5 text-green-600" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-gray-900">{analytics.passRate.toFixed(1)}%</div>
              <p className="text-sm text-gray-500">{analytics.passedAttempts} passed</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-3">
              <CardTitle className="text-sm font-medium text-gray-600">Average Score</CardTitle>
              <Trophy className="w-5 h-5 text-yellow-600" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-gray-900">{analytics.averageScore}%</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-3">
              <CardTitle className="text-sm font-medium text-gray-600">Avg. Time</CardTitle>
              <Clock className="w-5 h-5 text-purple-600" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-gray-900">
                {Math.floor(analytics.averageTime / 60)}m
              </div>
              <p className="text-sm text-gray-500">
                {analytics.averageTime % 60}s avg
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Score Distribution */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Score Distribution</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {analytics.scoreDistribution.map((range, idx) => (
                <div key={idx} className="flex items-center gap-4">
                  <div className="w-24 text-sm font-medium text-gray-600">{range.range}</div>
                  <div className="flex-1 bg-gray-200 rounded-full h-6">
                    <div
                      className="bg-blue-600 h-6 rounded-full flex items-center justify-center text-white text-sm font-medium"
                      style={{ width: `${analytics.totalAttempts > 0 ? (range.count / analytics.totalAttempts) * 100 : 0}%` }}
                    >
                      {range.count}
                    </div>
                  </div>
                  <div className="w-16 text-right text-sm text-gray-600">
                    {analytics.totalAttempts > 0 ? ((range.count / analytics.totalAttempts) * 100).toFixed(1) : 0}%
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Top Performers */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Trophy className="w-5 h-5 text-yellow-600" />
              Top Performers
            </CardTitle>
          </CardHeader>
          <CardContent>
            {analytics.topPerformers.length === 0 ? (
              <p className="text-gray-500 text-center py-8">No attempts yet</p>
            ) : (
              <div className="overflow-x-auto">
                <table className="min-w-full">
                  <thead>
                    <tr className="border-b">
                      <th className="text-left py-3 px-4 text-sm font-medium text-gray-600">Rank</th>
                      <th className="text-left py-3 px-4 text-sm font-medium text-gray-600">Student</th>
                      <th className="text-left py-3 px-4 text-sm font-medium text-gray-600">Score</th>
                      <th className="text-left py-3 px-4 text-sm font-medium text-gray-600">Time Spent</th>
                      <th className="text-left py-3 px-4 text-sm font-medium text-gray-600">Submitted</th>
                    </tr>
                  </thead>
                  <tbody>
                    {analytics.topPerformers.map((performer, idx) => (
                      <tr key={idx} className="border-b hover:bg-gray-50">
                        <td className="py-3 px-4">
                          <Badge variant={idx === 0 ? 'default' : 'outline'} className={idx === 0 ? 'bg-yellow-100 text-yellow-800' : ''}>
                            #{idx + 1}
                          </Badge>
                        </td>
                        <td className="py-3 px-4">
                          <div className="font-medium text-gray-900">{performer.userName || 'Anonymous'}</div>
                          <div className="text-sm text-gray-500">{performer.userEmail || ''}</div>
                        </td>
                        <td className="py-3 px-4">
                          <div className="font-bold text-gray-900">{performer.score.toFixed(1)}%</div>
                        </td>
                        <td className="py-3 px-4 text-gray-600">
                          {Math.floor(performer.timeSpent / 60)}m {performer.timeSpent % 60}s
                        </td>
                        <td className="py-3 px-4 text-gray-600">
                          {new Date(performer.submittedAt).toLocaleString()}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default QuizAnalytics;