import { useState, useEffect } from 'react';
import { Plus, Search, Edit2, Trash2, FolderOpen, Tag, Users, Globe, Lock } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { toast } from 'react-hot-toast';

const QuestionBankManagement = () => {
  const [questionBanks, setQuestionBanks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [open, setOpen] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [subjectFilter, setSubjectFilter] = useState('');
  const [selectedBank, setSelectedBank] = useState(null);
  const [showQuestions, setShowQuestions] = useState(false);

  const [form, setForm] = useState({
    name: '',
    description: '',
    subject: '',
    category: '',
    tags: '',
    isPublic: false
  });

  const userId = localStorage.getItem('userId') || 'demo-user';

  useEffect(() => {
    fetchQuestionBanks();
  }, []);

  const fetchQuestionBanks = async () => {
    try {
      const params = new URLSearchParams();
      if (subjectFilter) params.append('subject', subjectFilter);
      if (searchTerm) params.append('search', searchTerm);

      const response = await fetch(`/api/question-banks?${params.toString()}`);
      const data = await response.json();
      if (data.success) {
        setQuestionBanks(data.data);
      }
    } catch (error) {
      console.error('Error fetching question banks:', error);
    } finally {
      setLoading(false);
    }
  };

  const resetForm = () => {
    setForm({
      name: '',
      description: '',
      subject: '',
      category: '',
      tags: '',
      isPublic: false
    });
    setEditingId(null);
  };

  const handleChange = (key, value) => {
    setForm(prev => ({ ...prev, [key]: value }));
  };

  const openCreateModal = () => {
    resetForm();
    setOpen(true);
  };

  const openEditModal = (bank) => {
    setForm({
      name: bank.name || '',
      description: bank.description || '',
      subject: bank.subject || '',
      category: bank.category || '',
      tags: bank.tags?.join(', ') || '',
      isPublic: bank.isPublic || false
    });
    setEditingId(bank.id);
    setOpen(true);
  };

  const handleSubmit = async () => {
    if (!form.name.trim() || !form.subject.trim()) {
      toast.error('Name and subject are required');
      return;
    }

    try {
      const url = editingId 
        ? `/api/question-banks/${editingId}`
        : '/api/question-banks';
      
      const method = editingId ? 'PUT' : 'POST';

      const response = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...form,
          tags: form.tags.split(',').map(t => t.trim()).filter(Boolean),
          createdBy: userId
        })
      });

      const data = await response.json();
      if (data.success) {
        toast.success(editingId ? 'Question bank updated' : 'Question bank created');
        resetForm();
        setOpen(false);
        fetchQuestionBanks();
      }
    } catch (error) {
      console.error('Error saving question bank:', error);
      toast.error('Failed to save question bank');
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Are you sure you want to delete this question bank?')) return;

    try {
      const response = await fetch(`/api/question-banks/${id}`, { method: 'DELETE' });
      const data = await response.json();
      if (data.success) {
        toast.success('Question bank deleted');
        fetchQuestionBanks();
      }
    } catch (error) {
      console.error('Error deleting question bank:', error);
      toast.error('Failed to delete question bank');
    }
  };

  const viewQuestions = (bank) => {
    setSelectedBank(bank);
    setShowQuestions(true);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">Question Bank</h1>
          <p className="text-gray-600 mt-2">Create and manage reusable question collections</p>
        </div>

        {/* Filters & Actions */}
        <div className="flex flex-col md:flex-row gap-4 mb-6">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
            <Input
              placeholder="Search question banks..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
          <Select value={subjectFilter} onValueChange={setSubjectFilter}>
            <SelectTrigger className="w-40">
              <SelectValue placeholder="All Subjects" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Subjects</SelectItem>
              <SelectItem value="Mathematics">Mathematics</SelectItem>
              <SelectItem value="Science">Science</SelectItem>
              <SelectItem value="English">English</SelectItem>
              <SelectItem value="Programming">Programming</SelectItem>
            </SelectContent>
          </Select>
          <Button onClick={openCreateModal}>
            <Plus className="h-4 w-4 mr-2" />
            New Bank
          </Button>
        </div>

        {/* Question Banks Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {questionBanks.map((bank) => (
            <Card key={bank.id} className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-2">
                    <FolderOpen className="w-5 h-5 text-blue-600" />
                    <CardTitle className="text-lg">{bank.name}</CardTitle>
                  </div>
                  <div className="flex gap-1">
                    {bank.isPublic ? (
                      <Globe className="w-4 h-4 text-green-600" />
                    ) : (
                      <Lock className="w-4 h-4 text-gray-400" />
                    )}
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-gray-600 mb-4 line-clamp-2">
                  {bank.description || 'No description provided'}
                </p>

                <div className="flex flex-wrap gap-2 mb-4">
                  <Badge variant="outline">{bank.subject}</Badge>
                  {bank.category && (
                    <Badge variant="secondary">{bank.category}</Badge>
                  )}
                  {bank.tags?.slice(0, 3).map((tag, idx) => (
                    <Badge key={idx} variant="outline" className="flex items-center gap-1">
                      <Tag className="w-3 h-3" />
                      {tag}
                    </Badge>
                  ))}
                </div>

                <div className="flex items-center justify-between text-sm text-gray-500 mb-4">
                  <div className="flex items-center gap-1">
                    <Users className="w-4 h-4" />
                    <span>{bank.questions?.length || 0} questions</span>
                  </div>
                  <span>{new Date(bank.createdAt).toLocaleDateString()}</span>
                </div>

                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => viewQuestions(bank)}
                  >
                    View Questions
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => openEditModal(bank)}
                  >
                    <Edit2 className="w-4 h-4" />
                  </Button>
                  <Button
                    variant="destructive"
                    size="sm"
                    onClick={() => handleDelete(bank.id)}
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {questionBanks.length === 0 && (
          <Card>
            <CardContent className="py-12 text-center text-gray-500">
              No question banks found. Create your first one!
            </CardContent>
          </Card>
        )}

        {/* Create/Edit Dialog */}
        <Dialog open={open} onOpenChange={(open) => {
          if (!open) resetForm();
          setOpen(open);
        }}>
          <DialogContent className="sm:max-w-lg">
            <DialogHeader>
              <DialogTitle>
                {editingId ? 'Edit Question Bank' : 'Create Question Bank'}
              </DialogTitle>
            </DialogHeader>

            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label>Name <span className="text-red-500">*</span></Label>
                <Input
                  placeholder="Enter bank name"
                  value={form.name}
                  onChange={(e) => handleChange('name', e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label>Description</Label>
                <Textarea
                  placeholder="Enter description"
                  value={form.description}
                  onChange={(e) => handleChange('description', e.target.value)}
                  rows={3}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Subject <span className="text-red-500">*</span></Label>
                  <Input
                    placeholder="e.g., Mathematics"
                    value={form.subject}
                    onChange={(e) => handleChange('subject', e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Category</Label>
                  <Input
                    placeholder="e.g., Algebra"
                    value={form.category}
                    onChange={(e) => handleChange('category', e.target.value)}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label>Tags (comma separated)</Label>
                <Input
                  placeholder="e.g., easy, chapter1, midterm"
                  value={form.tags}
                  onChange={(e) => handleChange('tags', e.target.value)}
                />
              </div>

              <div className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  id="isPublic"
                  checked={form.isPublic}
                  onChange={(e) => handleChange('isPublic', e.target.checked)}
                  className="h-4 w-4"
                />
                <Label htmlFor="isPublic">Make this bank public (shareable)</Label>
              </div>
            </div>

            <DialogFooter>
              <Button variant="outline" onClick={() => setOpen(false)}>
                Cancel
              </Button>
              <Button onClick={handleSubmit}>
                {editingId ? 'Update' : 'Create'}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* View Questions Dialog */}
        <Dialog open={showQuestions} onOpenChange={setShowQuestions}>
          <DialogContent className="sm:max-w-2xl">
            <DialogHeader>
              <DialogTitle>{selectedBank?.name} - Questions</DialogTitle>
            </DialogHeader>

            <div className="mt-4">
              {selectedBank?.questions?.length === 0 ? (
                <p className="text-gray-500 text-center py-8">No questions in this bank</p>
              ) : (
                <div className="space-y-3 max-h-96 overflow-y-auto">
                  {selectedBank?.questions?.map((entry, idx) => (
                    <div key={idx} className="p-3 border rounded-lg">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <p className="font-medium text-gray-900">
                            {entry.question.questionText}
                          </p>
                          <div className="flex gap-2 mt-2">
                            <Badge variant="outline">{entry.question.questionType}</Badge>
                            <Badge variant="secondary">{entry.question.difficulty}</Badge>
                            <Badge>{entry.question.marks} marks</Badge>
                          </div>
                        </div>
                        <span className="text-sm text-gray-500">#{idx + 1}</span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <DialogFooter>
              <Button variant="outline" onClick={() => setShowQuestions(false)}>
                Close
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
};

export default QuestionBankManagement;