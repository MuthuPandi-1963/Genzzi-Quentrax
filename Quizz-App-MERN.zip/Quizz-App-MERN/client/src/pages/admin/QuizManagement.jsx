// pages/QuizManagement.tsx
import React, { useState } from 'react'
import {
  Plus, Search, Play, Edit, Trash2,
  MoreHorizontal, Clock
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow
} from '@/components/ui/table'
import { Badge } from '@/components/ui/badge'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger
} from '@/components/ui/dropdown-menu'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from '@/components/ui/select'
import { useQuizzes } from '../../hooks/useQuizzes'
import QuizForm from '../../components/forms/QuizForm'
import QuizQuestionForm from '../../components/forms/QuizQuestionForm'

const QuizManagement = () => {
  const [searchTerm, setSearchTerm] = useState('')
  const [statusFilter, setStatusFilter] = useState('all')
  const [openQuizForm, setOpenQuizForm] = useState(false)
  const [editQuiz, setEditQuiz] = useState(null)
  const [openQuestionForm, setOpenQuestionForm] = useState(false)
  const [currentQuiz, setCurrentQuiz] = useState(null)

  const { quizzes: { data: quizzes }, isLoading, deleteQuiz } = useQuizzes()

  if (isLoading) return <p>Loading...</p>

  const getStatusBadge = (status) => {
    const statuses = {
      active: { label: 'Active', color: 'bg-green-100 text-green-800' },
      draft: { label: 'Draft', color: 'bg-yellow-100 text-yellow-800' },
      inactive: { label: 'Inactive', color: 'bg-red-100 text-red-800' }
    }
    return statuses[status] || statuses.draft
  }

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Quiz Management</h1>
          <p className="text-muted-foreground text-sm">
            Create and manage interactive quizzes
          </p>
        </div>
        <Button onClick={() => { setEditQuiz(null); setOpenQuizForm(true) }}>
          <Plus className="h-4 w-4 mr-2" />
          Create Quiz
        </Button>
      </div>

      {/* Filters */}
      <div className="flex gap-4 items-center">
        <div className="relative flex-1 max-w-sm">
          <Input
            placeholder="Search quizzes..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-40">
            <SelectValue placeholder="Status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Status</SelectItem>
            <SelectItem value="active">Active</SelectItem>
            <SelectItem value="draft">Draft</SelectItem>
            <SelectItem value="inactive">Inactive</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Quizzes Table */}
      <div className="border rounded-lg shadow-sm overflow-x-auto">
        <Table className="w-full">
          <TableHeader>
            <TableRow>
              <TableHead className="text-center">Quiz Title</TableHead>
              <TableHead className="text-center">Category/Topic</TableHead>
              <TableHead className="text-center">Details</TableHead>
              <TableHead className="text-center">Total Points</TableHead>
              <TableHead className="text-center">Duration</TableHead>
              <TableHead className="text-center">Status</TableHead>
              <TableHead className="text-center">Created</TableHead>
              <TableHead className="text-center">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {quizzes?.map((quiz) => {
              const statusInfo = getStatusBadge(quiz.status)
              return (
                <TableRow
                  key={quiz.id}
                  className="hover:bg-muted/50 transition-colors"
                >
                  {/* Quiz Title */}
                  <TableCell className="text-center">
                    <div>
                      <div className="font-semibold">{quiz.title}</div>
                      <div className="text-sm text-muted-foreground line-clamp-1">
                        {quiz.description}
                      </div>
                    </div>
                  </TableCell>

                  {/* Category / Topic */}
                  <TableCell className="text-center">
                    <div className="text-sm">
                      <div>{quiz?.category}</div>
                      <div className="text-muted-foreground">
                        {quiz?.topic ? quiz.topic.name : 'None'}
                      </div>
                    </div>
                  </TableCell>

                  {/* Question Details */}
                  <TableCell className="text-center">
                    <div className="flex justify-center items-center gap-2 text-sm">
                      <Play className="h-3 w-3" />
                      {quiz.questions.length} Qs
                    </div>
                  </TableCell>

                  {/* Total Points */}
                  <TableCell className="text-center font-medium">
                    {quiz.totalPoints}
                  </TableCell>

                  {/* Duration */}
                  <TableCell className="text-center">
                    <div className="flex justify-center items-center gap-1">
                      <Clock className="h-4 w-4" />
                      {quiz.timeLimit}m
                    </div>
                  </TableCell>

                  {/* Status */}
                  <TableCell className="text-center">
                    <Badge className={statusInfo.color}>{statusInfo.label}</Badge>
                  </TableCell>

                  {/* Created Date */}
                  <TableCell className="text-center">
                    {new Date(quiz.createdAt).toLocaleDateString()}
                  </TableCell>

                  {/* Actions */}
                  <TableCell>
                    <div className="flex justify-center gap-2">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => {
                          setCurrentQuiz(quiz)
                          setOpenQuestionForm(true)
                        }}
                      >
                        Add Questions
                      </Button>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem
                            onClick={() => { setEditQuiz(quiz); setOpenQuizForm(true) }}
                          >
                            <Edit className="h-4 w-4 mr-2" /> Edit
                          </DropdownMenuItem>
                          <DropdownMenuItem
                            className="text-red-600"
                            onClick={() => deleteQuiz.mutate(quiz.id)}
                          >
                            <Trash2 className="h-4 w-4 mr-2" /> Delete
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  </TableCell>
                </TableRow>
              )
            })}
          </TableBody>
        </Table>
      </div>

      {/* Modals */}
      {openQuizForm && (
        <QuizForm quiz={editQuiz} onClose={() => setOpenQuizForm(false)} />
      )}
      {openQuestionForm && currentQuiz && (
        <QuizQuestionForm quiz={currentQuiz} onClose={() => setOpenQuestionForm(false)} />
      )}
    </div>
  )
}

export default QuizManagement
