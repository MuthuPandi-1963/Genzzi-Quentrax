import { useDashboard } from "@/hooks/useDashboard";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export default function AnalyticsPage() {
  const { analyticsQuery } = useDashboard();
  const data = analyticsQuery.data;

  if (analyticsQuery.isLoading) return <p>Loading analytics...</p>;

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold">Analytics</h1>

      <div className="grid md:grid-cols-3 gap-4">
        <Card>
          <CardHeader>
            <CardTitle>Pass rate</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold text-green-600">
              {data?.passFailRatio?.pass ?? 0}
            </p>
            <p className="text-sm text-muted-foreground">Passed (≥60%)</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>Fail rate</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold text-red-600">
              {data?.passFailRatio?.fail ?? 0}
            </p>
            <p className="text-sm text-muted-foreground">Below 60%</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>Topic performance</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            {(data?.topicPerformance ?? []).map((t) => (
              <div key={t.topic} className="flex justify-between text-sm">
                <span>{t.topic}</span>
                <span className="font-medium">{t.avgScore}%</span>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
