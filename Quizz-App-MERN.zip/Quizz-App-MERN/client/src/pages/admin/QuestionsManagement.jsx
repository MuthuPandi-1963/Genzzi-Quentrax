// pages/QuestionManagement.tsx
import React, { useState } from "react";
import { Plus, Search, Edit, Trash2, MoreHorizontal, CopyPlus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { useQuestions } from "../../hooks/useQuestions";
import QuestionForm from "../../components/forms/QuestionForm";
import QuestionBulkImportForm from "../../components/forms/MultipleQuestionsForm";

const QuestionManagement = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [typeFilter, setTypeFilter] = useState("all");
  const [difficultyFilter, setDifficultyFilter] = useState("all");
  const [editingQuestion, setEditingQuestion] = useState(null);
  const [bulkQuestions,setBulkQuestions] = useState(false)
  const {
    questions: { data: questions },
    isLoading,
    deleteQuestion
  } = useQuestions();
  console.log(questions);

  const questionList = questions || [];

  // Difficulty label mapping
  const difficultyMap = {
    easy: "Beginner",
    medium: "Intermediate",
    hard: "Advanced",
  };

  const getTypeBadge = (type) => {
    const types = {
      MCQ: { label: "MCQ", color: "bg-blue-100 text-blue-800" },
      TRUE_FALSE: { label: "True/False", color: "bg-green-100 text-green-800" },
      FILL_BLANK: {
        label: "Fill Blank",
        color: "bg-purple-100 text-purple-800",
      },
    };
    return types[type] || { label: type, color: "bg-gray-100 text-gray-800" };
  };

  const filteredQuestions = questionList
    .filter((q) => typeFilter === "all" || q.questionType === typeFilter)
    .filter(
      (q) => difficultyFilter === "all" || q.difficulty === difficultyFilter
    )
    .filter(
      (q) =>
        searchTerm === "" ||
        q.questionText.toLowerCase().includes(searchTerm.toLowerCase())
    );

  if (isLoading) return <div>Loading...</div>;

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">
            Question Management
          </h1>
          <p className="text-muted-foreground">
            Create and manage quiz questions
          </p>
        </div>
        <div className="flex items-center gap-x-6 ">
          <Button onClick={() => setBulkQuestions(prev=>!prev)}>
          <CopyPlus className="h-4 w-4 mr-2" />
          Add Many Question
        </Button>
        <Button onClick={() => setEditingQuestion({})}>
          <Plus className="h-4 w-4 mr-2" />
          Add Question
        </Button>
        </div>
      </div>

      {/* Filters */}
      <div className="flex gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search questions..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>
        <Select value={typeFilter} onValueChange={setTypeFilter}>
          <SelectTrigger className="w-40">
            <SelectValue placeholder="Question Type" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Types</SelectItem>
            <SelectItem value="MCQ">Multiple Choice</SelectItem>
            <SelectItem value="TRUE_FALSE">True/False</SelectItem>
            <SelectItem value="FILL_BLANK">Fill Blank</SelectItem>
          </SelectContent>
        </Select>
        <Select value={difficultyFilter} onValueChange={setDifficultyFilter}>
          <SelectTrigger className="w-40">
            <SelectValue placeholder="Difficulty" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Levels</SelectItem>
            <SelectItem value="easy">Beginner</SelectItem>
            <SelectItem value="medium">Intermediate</SelectItem>
            <SelectItem value="hard">Advanced</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Questions Table */}
      <div className="border rounded-lg">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Question</TableHead>
              <TableHead>Type</TableHead>
              <TableHead>Category/Topic</TableHead>
              <TableHead>Difficulty</TableHead>
              <TableHead>Points</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="w-12"></TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredQuestions.map((question) => {
              const typeInfo = getTypeBadge(question.questionType);
              return (
                <TableRow key={question.id}>
                  <TableCell className="max-w-md">
                    <div className="font-medium line-clamp-2">
                      {question.questionText}
                    </div>
                    {question.questionType === "MCQ" && question.options && (
                      <div className="text-sm text-muted-foreground mt-1">
                        Options:{" "}
                        {question.options.map((o) => o.text).join(", ")}
                      </div>
                    )}
                  </TableCell>
                  <TableCell>
                    <Badge className={typeInfo.color}>{typeInfo.label}</Badge>
                  </TableCell>
                  <TableCell>
                    <div className="text-sm">
                      <div>{question.topic?.name}</div>
                      <div className="text-muted-foreground w-60 truncate">
                        {question.topic?.description}
                      </div>
                    </div>
                  </TableCell>
                  <TableCell>
                    <Badge variant="outline">
                      {difficultyMap[question.difficulty]}
                    </Badge>
                  </TableCell>
                  <TableCell>{question.points}</TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <Switch checked={question.status === "active"} />
                      <span
                        className={
                          question.status === "active"
                            ? "text-green-600"
                            : "text-red-600"
                        }
                      >
                        {question.status === "active" ? "Active" : "Inactive"}
                      </span>
                    </div>
                  </TableCell>
                  <TableCell>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon">
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem
                          onClick={() => setEditingQuestion(question)}
                        >
                          <Edit className="h-4 w-4 mr-2" />
                          Edit
                        </DropdownMenuItem>
                        <DropdownMenuItem className="text-red-600" 
                        onClick={()=>deleteQuestion.mutate(question.id)}>
                          <Trash2 className="h-4 w-4 mr-2" />
                          Delete
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      </div>

      {/* Question Form Modal */}
      {editingQuestion && (
        <QuestionForm
          question={editingQuestion}
          onClose={() => setEditingQuestion(null)}
        />
      )}
      {bulkQuestions && (
        <QuestionBulkImportForm bulkQuestions={bulkQuestions} setBulkQuestions={setBulkQuestions}/>
      )}
    </div>
  );
};

export default QuestionManagement;
