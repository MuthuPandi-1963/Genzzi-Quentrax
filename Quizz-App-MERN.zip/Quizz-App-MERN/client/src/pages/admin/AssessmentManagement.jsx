import React, { useState } from "react";
import { Plus, Edit2, Trash2, Users, FileText, Eye } from "lucide-react";
import { useAssessments, useAssessmentMutations } from "@/hooks/useAssessments";
import { useTopics } from "@/hooks/useTopics";
import UserAssignmentModal from "@/components/admin/UserAssignmentModal";
import QuestionViewerModal from "@/components/admin/QuestionViewerModal";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";

import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";

import { toast } from "react-hot-toast";

export default function AssessmentManagement() {
  const { data: assessments = [], isLoading } = useAssessments();
  const { create, remove, update } = useAssessmentMutations();
  const { data: topics = [] } = useTopics()?.topics || {};

  const [open, setOpen] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [showAssignModal, setShowAssignModal] = useState(false);
  const [showQuestionModal, setShowQuestionModal] = useState(false);
  const [selectedAssessment, setSelectedAssessment] = useState(null);

  const [form, setForm] = useState({
    title: "",
    description: "",
    status: "",
    topicId: "",
    startDate: "",
    endDate: "",
    duration: 30, // in minutes
    passingScore: 50,
    // Assessment Configuration
    allowReview: false,
    allowRetry: false,
    showResultImmediately: false,
    shuffleQuestions: true,
    shuffleOptions: true,
    proctoredMode: false,
    maxViolations: 3,
    maxAttempts: 1,
  });

  const isEditing = !!editingId;

  const resetForm = () => {
    setForm({
      title: "",
      description: "",
      status: "",
      topicId: "",
      startDate: "",
      endDate: "",
      duration: 30,
      passingScore: 50,
      allowReview: false,
      allowRetry: false,
      showResultImmediately: false,
      shuffleQuestions: true,
      shuffleOptions: true,
      proctoredMode: false,
      maxViolations: 3,
      maxAttempts: 1,
    });
    setEditingId(null);
  };

  const handleChange = (key, value) => {
    setForm((prev) => ({ ...prev, [key]: value }));
  };

  const openCreateModal = () => {
    resetForm();
    setOpen(true);
  };

  const openEditModal = (assessment) => {
    setForm({
      title: assessment.title || "",
      description: assessment.description || "",
      status: assessment.status || "",
      topicId: assessment.topicId || "",
      startDate: assessment.startDate ? assessment.startDate.split("T")[0] : "",
      endDate: assessment.endDate ? assessment.endDate.split("T")[0] : "",
      duration: assessment.duration || 30,
      passingScore: assessment.passingScore || 50,
      allowReview: assessment.allowReview ?? false,
      allowRetry: assessment.allowRetry ?? false,
      showResultImmediately: assessment.showResultImmediately ?? false,
      shuffleQuestions: assessment.shuffleQuestions ?? true,
      shuffleOptions: assessment.shuffleOptions ?? true,
      proctoredMode: assessment.proctoredMode ?? false,
      maxViolations: assessment.maxViolations ?? 3,
      maxAttempts: assessment.maxAttempts ?? 1,
    });
    setEditingId(assessment.id);
    setOpen(true);
  };

  const validateForm = () => {
    if (!form.title?.trim()) {
      toast.error("Title is required");
      return false;
    }
    if (!form.topicId) {
      toast.error("Please select a topic");
      return false;
    }
    if (!form.status) {
      toast.error("Please select status");
      return false;
    }
    if (!form.startDate || !form.endDate) {
      toast.error("Please select both start and end dates");
      return false;
    }
    if (new Date(form.startDate) > new Date(form.endDate)) {
      toast.error("End date must be after start date");
      return false;
    }
    return true;
  };

  const handleSubmit = () => {
    if (!validateForm()) return;

    const payload = {
      ...form,
      startDate: form.startDate,
      endDate: form.endDate,
    };

    if (isEditing) {
      update.mutate(
        { id: editingId, ...payload },
        {
          onSuccess: () => {
            toast.success("Assessment updated successfully");
            resetForm();
            setOpen(false);
          },
          onError: (error) => {
            toast.error(error?.message || "Failed to update assessment");
          },
        }
      );
    } else {
      create.mutate(payload, {
        onSuccess: () => {
          toast.success("Assessment created successfully");
          resetForm();
          setOpen(false);
        },
        onError: (error) => {
          toast.error(error?.message || "Failed to create assessment");
        },
      });
    }
  };

  const handleDelete = (id) => {
    if (!window.confirm("Are you sure you want to delete this assessment?")) return;

    remove.mutate(id, {
      onSuccess: () => toast.success("Assessment deleted successfully"),
      onError: (error) => toast.error(error?.message || "Failed to delete assessment"),
    });
  };

  const openAssignModal = (assessment) => {
    setSelectedAssessment(assessment);
    setShowAssignModal(true);
  };

  const openQuestionModal = (assessment) => {
    setSelectedAssessment(assessment);
    setShowQuestionModal(true);
  };

  if (isLoading) {
    return <div className="p-6 text-center">Loading assessments...</div>;
  }

  return (
    <div className="space-y-6 p-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Assessment Management</h1>
          <p className="text-muted-foreground">Create and manage assessments</p>
        </div>

        <Button onClick={openCreateModal}>
          <Plus className="h-4 w-4 mr-2" />
          New Assessment
        </Button>
      </div>

      {/* Assessment List */}
      <div className="grid gap-4">
        {assessments.length === 0 ? (
          <Card>
            <CardContent className="py-12 text-center text-muted-foreground">
              No assessments found. Create your first one!
            </CardContent>
          </Card>
        ) : (
          assessments.map((assessment) => (
            <Card key={assessment.id} className="hover:shadow-md transition-shadow">
              <CardHeader className="flex flex-row items-center justify-between pb-3">
                <CardTitle className="text-lg">{assessment.title}</CardTitle>
                <Badge variant={assessment.status === "ACTIVE" ? "default" : "secondary"}>
                  {assessment.status}
                </Badge>
              </CardHeader>

              <CardContent>
                <p className="text-sm text-muted-foreground mb-4 line-clamp-2">
                  {assessment.description || "No description provided"}
                </p>

                <div className="flex justify-between items-center text-xs text-gray-500">
                  <div className="space-x-4">
                    <span>Start: {assessment.startDate ? new Date(assessment.startDate).toLocaleDateString() : "N/A"}</span>
                    <span>End: {assessment.endDate ? new Date(assessment.endDate).toLocaleDateString() : "N/A"}</span>
                  </div>

                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => openAssignModal(assessment)}
                      title="Assign Users"
                    >
                      <Users className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => openQuestionModal(assessment)}
                      title="View Questions"
                    >
                      <FileText className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => openEditModal(assessment)}
                    >
                      <Edit2 className="h-4 w-4 mr-1" />
                      Edit
                    </Button>
                    <Button
                      variant="destructive"
                      size="sm"
                      onClick={() => handleDelete(assessment.id)}
                    >
                      <Trash2 className="h-4 w-4 mr-1" />
                      Delete
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>

      {/* Create/Edit Dialog */}
      <Dialog open={open} onOpenChange={(open) => {
        if (!open) resetForm();
        setOpen(open);
      }}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>{isEditing ? "Edit Assessment" : "Create New Assessment"}</DialogTitle>
          </DialogHeader>

          <div className="space-y-5 py-2">
            <div className="space-y-2">
              <Label>Title <span className="text-red-500">*</span></Label>
              <Input
                placeholder="Enter assessment title"
                value={form.title}
                onChange={(e) => handleChange("title", e.target.value)}
              />
            </div>

            

            <div className="space-y-2">
              <Label>Description</Label>
              <Textarea
                placeholder="Enter description (optional)"
                value={form.description}
                onChange={(e) => handleChange("description", e.target.value)}
                rows={3}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Topic <span className="text-red-500">*</span></Label>
                <Select value={form.topicId} onValueChange={(v) => handleChange("topicId", v)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select Topic" />
                  </SelectTrigger>
                  <SelectContent>
                    {topics.map((topic) => (
                      <SelectItem key={topic.id} value={topic.id}>
                        {topic.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Status <span className="text-red-500">*</span></Label>
                <Select value={form.status} onValueChange={(v) => handleChange("status", v)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select Status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="DRAFT">Draft</SelectItem>
                    <SelectItem value="ACTIVE">Active</SelectItem>
                    <SelectItem value="COMPLETED">Completed</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Duration (minutes) <span className="text-red-500">*</span></Label>
                <Input
                  type="number"
                  min="1"
                  value={form.duration}
                  onChange={(e) => handleChange("duration", parseInt(e.target.value))}
                />
              </div>

              <div className="space-y-2">
                <Label>Passing Score (%) <span className="text-red-500">*</span></Label>
                <Input
                  type="number"
                  min="0"
                  max="100"
                  value={form.passingScore}
                  onChange={(e) => handleChange("passingScore", parseInt(e.target.value))}
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Start Date <span className="text-red-500">*</span></Label>
                <Input
                  type="date"
                  value={form.startDate}
                  onChange={(e) => handleChange("startDate", e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label>End Date <span className="text-red-500">*</span></Label>
                <Input
                  type="date"
                  value={form.endDate}
                  onChange={(e) => handleChange("endDate", e.target.value)}
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Max Attempts</Label>
                <Input
                  type="number"
                  min="1"
                  value={form.maxAttempts}
                  onChange={(e) => handleChange("maxAttempts", parseInt(e.target.value))}
                />
              </div>

              <div className="space-y-2">
                <Label>Max Violations</Label>
                <Input
                  type="number"
                  min="1"
                  max="10"
                  value={form.maxViolations}
                  onChange={(e) => handleChange("maxViolations", parseInt(e.target.value))}
                />
              </div>
            </div>

            {/* Security & Behavior Options */}
            <div className="border-t pt-4">
              <Label className="text-base font-semibold">Security & Behavior Options</Label>
              <div className="grid grid-cols-2 gap-4 mt-3">
                <div className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    id="proctoredMode"
                    checked={form.proctoredMode}
                    onChange={(e) => handleChange("proctoredMode", e.target.checked)}
                    className="h-4 w-4"
                  />
                  <Label htmlFor="proctoredMode" className="text-sm cursor-pointer">
                    Proctored Mode
                  </Label>
                </div>

                <div className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    id="shuffleQuestions"
                    checked={form.shuffleQuestions}
                    onChange={(e) => handleChange("shuffleQuestions", e.target.checked)}
                    className="h-4 w-4"
                  />
                  <Label htmlFor="shuffleQuestions" className="text-sm cursor-pointer">
                    Shuffle Questions
                  </Label>
                </div>

                <div className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    id="shuffleOptions"
                    checked={form.shuffleOptions}
                    onChange={(e) => handleChange("shuffleOptions", e.target.checked)}
                    className="h-4 w-4"
                  />
                  <Label htmlFor="shuffleOptions" className="text-sm cursor-pointer">
                    Shuffle Options
                  </Label>
                </div>

                <div className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    id="allowReview"
                    checked={form.allowReview}
                    onChange={(e) => handleChange("allowReview", e.target.checked)}
                    className="h-4 w-4"
                  />
                  <Label htmlFor="allowReview" className="text-sm cursor-pointer">
                    Allow Review
                  </Label>
                </div>

                <div className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    id="allowRetry"
                    checked={form.allowRetry}
                    onChange={(e) => handleChange("allowRetry", e.target.checked)}
                    className="h-4 w-4"
                  />
                  <Label htmlFor="allowRetry" className="text-sm cursor-pointer">
                    Allow Retry
                  </Label>
                </div>

                <div className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    id="showResultImmediately"
                    checked={form.showResultImmediately}
                    onChange={(e) => handleChange("showResultImmediately", e.target.checked)}
                    className="h-4 w-4"
                  />
                  <Label htmlFor="showResultImmediately" className="text-sm cursor-pointer">
                    Show Result Immediately
                  </Label>
                </div>
              </div>
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleSubmit} disabled={create.isPending || update.isPending}>
              {create.isPending || update.isPending
                ? "Saving..."
                : isEditing
                ? "Update Assessment"
                : "Create Assessment"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* User Assignment Modal */}
      {selectedAssessment && (
        <UserAssignmentModal
          assessmentId={selectedAssessment.id}
          open={showAssignModal}
          onOpenChange={setShowAssignModal}
          onAssigned={() => {
            // Refresh assessments if needed
          }}
        />
      )}

      {/* Question Viewer Modal */}
      {selectedAssessment && (
        <QuestionViewerModal
          assessmentId={selectedAssessment.id}
          open={showQuestionModal}
          onOpenChange={setShowQuestionModal}
        />
      )}
    </div>
  );
}
