import React, { useState, useMemo, useCallback } from "react";
import { Plus, Search, Star, Edit, Trash2, MoreHorizontal } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import _ from "lodash";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useTopics } from "../../hooks/useTopics";
import TopicForm from "../../components/forms/TopicForm";
import toast from "react-hot-toast";

const difficultyMap= {
  beginner: "easy",
  intermediate: "medium",
  advanced: "hard",
};

const getDifficultyColor = (difficulty) => {
  switch (difficulty) {
    case "easy":
      return "bg-green-100 text-green-800";
    case "medium":
      return "bg-yellow-100 text-yellow-800";
    case "hard":
      return "bg-red-100 text-red-800";
    default:
      return "bg-gray-100 text-gray-800";
  }
};

const TopicManagement = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("all");
  const [difficultyFilter, setDifficultyFilter] = useState("all");
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingTopic, setEditingTopic] = useState(null);

  const {
    topics: { data: topics },
    isLoading,
    deleteTopic,
  } = useTopics({ refetchOnWindowFocus: false }); // prevent infinite refetch

  // Memoized categories to avoid re-creating array on every render
  const categories = useMemo(
    () => _.uniq(topics?.map((t) => t.category.name) || []),
    [topics]
  );

  const filteredTopics = useMemo(() => {
    return topics?.filter((topic) => {
      const matchesSearch = topic.name.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesCategory = categoryFilter === "all" || topic.category.name === categoryFilter;
      const mappedDifficulty = difficultyMap[difficultyFilter] || difficultyFilter;
      const matchesDifficulty = difficultyFilter === "all" || topic.difficulty === mappedDifficulty;
      return matchesSearch && matchesCategory && matchesDifficulty;
    });
  }, [topics, searchTerm, categoryFilter, difficultyFilter]);

  const handleEdit = useCallback((topic) => {
    setEditingTopic(topic);
    setIsFormOpen(true);
  }, []);

  const handleDelete = useCallback(
    (topicId) => {
      if (!confirm("Are you sure you want to delete this topic?")) return;
      deleteTopic.mutate(topicId, {
        onSuccess: () => toast.success("Topic deleted successfully"),
        onError: () => toast.error("Failed to delete topic"),
      });
    },
    [deleteTopic]
  );

  if (isLoading) return <p>Loading...</p>;

  return (
    <>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Topic Management</h1>
            <p className="text-muted-foreground">Manage topics and their difficulty levels</p>
          </div>
          <Button
            onClick={() => {
              setEditingTopic(null);
              setIsFormOpen(true);
            }}
          >
            <Plus className="h-4 w-4 mr-2" />
            Add Topic
          </Button>
        </div>

        {/* Filters */}
        <div className="flex gap-4">
          {/* Search */}
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search topics..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>

          {/* Category Filter */}
          <Select value={categoryFilter} onValueChange={setCategoryFilter}>
            <SelectTrigger className="w-40">
              <SelectValue placeholder="Category" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Categories</SelectItem>
              {categories.map((category, idx) => (
                <SelectItem key={idx} value={category}>
                  {category}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          {/* Difficulty Filter */}
          <Select value={difficultyFilter} onValueChange={setDifficultyFilter}>
            <SelectTrigger className="w-40">
              <SelectValue placeholder="Difficulty" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Levels</SelectItem>
              <SelectItem value="beginner">Beginner</SelectItem>
              <SelectItem value="intermediate">Intermediate</SelectItem>
              <SelectItem value="advanced">Advanced</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Topics Table */}
        <div className="border rounded-lg overflow-hidden">
          <Table className="w-full">
            <TableHeader>
              <TableRow className="bg-muted/50">
                <TableHead className="text-center">S No</TableHead>
                <TableHead className="text-center">Image</TableHead>
                <TableHead className="text-center">Topic</TableHead>
                <TableHead className="text-center">Category</TableHead>
                <TableHead className="text-center">Difficulty</TableHead>
                <TableHead className="text-center">Tags</TableHead>
                <TableHead className="text-center">Created</TableHead>
                <TableHead className="w-12 text-center"></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredTopics?.map((topic, idx) => (
                <TableRow key={topic.id} className="hover:bg-muted/30">
                  <TableCell className="font-medium text-center">{idx + 1}.</TableCell>
                  <TableCell className="font-medium text-center">
                    <img
                      src={topic.imageUrl}
                      alt={topic.name}
                      className="w-10 h-10 rounded-md object-cover"
                    />
                  </TableCell>
                  <TableCell className="font-medium text-center">{topic.name}</TableCell>
                  <TableCell className="text-center">
                    <Badge variant="outline" className="px-2 py-0.5">
                      {topic.category.name}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-center w-fit">
                    <Badge className={`gap-1 pl-2 py-0.5 ${getDifficultyColor(topic.difficulty)}`}>
                      <Star className="h-3 w-3 fill-current" />
                      {topic.difficulty}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-center w-fit">
                    <div className="flex items-center justify-center gap-1 flex-wrap">
                      {topic.tags.map((tag) => (
                        <span key={tag} className="text-xs bg-muted px-2 py-1 rounded-md">
                          {tag}
                        </span>
                      ))}
                    </div>
                  </TableCell>
                  <TableCell className="text-center">
                    {new Date(topic.createdAt).toLocaleDateString()}
                  </TableCell>
                  <TableCell className="text-center">
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon">
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem className="cursor-pointer" onClick={() => handleEdit(topic)}>
                          <Edit className="h-4 w-4 mr-2" />
                          Edit
                        </DropdownMenuItem>
                        <DropdownMenuItem
                          className="text-red-600 cursor-pointer focus:text-red-700"
                          onClick={() => handleDelete(topic.id)}
                        >
                          <Trash2 className="h-4 w-4 mr-2" />
                          Delete
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </div>

      {/* Topic Form */}
      <TopicForm
        open={isFormOpen}
        onOpenChange={setIsFormOpen}
        topic={editingTopic}
        onSuccess={() => {
          setIsFormOpen(false);
          setEditingTopic(null);
        }}
      />
    </>
  );
};

export default TopicManagement;
