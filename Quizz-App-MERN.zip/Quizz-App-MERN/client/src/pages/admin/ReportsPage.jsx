import { useState, useEffect } from 'react';
import { Download, AlertTriangle, Users, Activity, Calendar } from 'lucide-react';

const ReportsPage = () => {
  const [analytics, setAnalytics] = useState(null);
  const [warnings, setWarnings] = useState([]);
  const [loading, setLoading] = useState(true);
  const [quizzes, setQuizzes] = useState([]);
  const [dateRange, setDateRange] = useState({
    startDate: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    endDate: new Date().toISOString().split('T')[0]
  });
  const [selectedQuiz, setSelectedQuiz] = useState('');

  useEffect(() => {
    fetchAnalytics();
    fetchWarnings();
    fetchQuizzes();
  }, [dateRange, selectedQuiz]);

  const fetchAnalytics = async () => {
    try {
      const params = new URLSearchParams();
      params.append('startDate', dateRange.startDate);
      params.append('endDate', dateRange.endDate);
      if (selectedQuiz) params.append('quizId', selectedQuiz);

      const response = await fetch(`/api/analytics?${params.toString()}`);
      const data = await response.json();
      if (data.success) {
        setAnalytics(data.data);
      }
    } catch (error) {
      console.error('Error fetching analytics:', error);
    }
  };

  const fetchWarnings = async () => {
    try {
      if (!selectedQuiz) {
        setWarnings([]);
        return;
      }

      const params = new URLSearchParams();
      params.append('startDate', dateRange.startDate);
      params.append('endDate', dateRange.endDate);
      params.append('limit', '100');

      const response = await fetch(`/api/quiz/${selectedQuiz}/warnings?${params.toString()}`);
      const data = await response.json();
      if (data.success) {
        setWarnings(data.data);
      }
    } catch (error) {
      console.error('Error fetching warnings:', error);
    }
  };

  const fetchQuizzes = async () => {
    try {
      const response = await fetch('/api/quizzes');
      const data = await response.json();
      if (data.success) {
        setQuizzes(data.data);
      }
    } catch (error) {
      console.error('Error fetching quizzes:', error);
    }
  };

  const exportCSV = async () => {
    try {
      const params = new URLSearchParams();
      params.append('startDate', dateRange.startDate);
      params.append('endDate', dateRange.endDate);
      if (selectedQuiz) params.append('quizId', selectedQuiz);

      const response = await fetch(`/api/export/csv?${params.toString()}`);
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `violations-report-${dateRange.startDate}-${dateRange.endDate}.csv`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
    } catch (error) {
      console.error('Error exporting CSV:', error);
    }
  };

  const getViolationTypeColor = (type) => {
    const colors = {
      RIGHT_CLICK: 'bg-red-100 text-red-800',
      COPY_PASTE: 'bg-orange-100 text-orange-800',
      KEYBOARD_SHORTCUT: 'bg-yellow-100 text-yellow-800',
      TAB_SWITCH: 'bg-purple-100 text-purple-800',
      EXIT_FULLSCREEN: 'bg-blue-100 text-blue-800',
      DEVTOOLS_OPENED: 'bg-pink-100 text-pink-800',
      DEVTOOLS_KEY: 'bg-pink-100 text-pink-800',
      DEVTOOLS_SHORTCUT: 'bg-pink-100 text-pink-800',
      PRINT_SCREEN: 'bg-indigo-100 text-indigo-800',
      PAGE_REFRESH: 'bg-green-100 text-green-800'
    };
    return colors[type] || 'bg-gray-100 text-gray-800';
  };

  const getViolationTypeLabel = (type) => {
    const labels = {
      RIGHT_CLICK: 'Right Click',
      COPY_PASTE: 'Copy/Paste',
      KEYBOARD_SHORTCUT: 'Keyboard Shortcut',
      TAB_SWITCH: 'Tab Switch',
      EXIT_FULLSCREEN: 'Exit Fullscreen',
      DEVTOOLS_OPENED: 'DevTools Opened',
      DEVTOOLS_KEY: 'F12 Pressed',
      DEVTOOLS_SHORTCUT: 'DevTools Shortcut',
      PRINT_SCREEN: 'Print Screen',
      PAGE_REFRESH: 'Page Refresh'
    };
    return labels[type] || type;
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">Security Reports & Analytics</h1>
          <p className="text-gray-600 mt-2">Monitor exam security violations and generate reports</p>
        </div>

        {/* Filters */}
        <div className="bg-white rounded-lg shadow p-6 mb-6">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Start Date
              </label>
              <input
                type="date"
                value={dateRange.startDate}
                onChange={(e) => setDateRange({ ...dateRange, startDate: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                End Date
              </label>
              <input
                type="date"
                value={dateRange.endDate}
                onChange={(e) => setDateRange({ ...dateRange, endDate: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Quiz
              </label>
              <select
                value={selectedQuiz}
                onChange={(e) => setSelectedQuiz(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="">All Quizzes</option>
                {quizzes.map(quiz => (
                  <option key={quiz._id} value={quiz._id}>{quiz.title}</option>
                ))}
              </select>
            </div>
            <div className="flex items-end">
              <button
                onClick={exportCSV}
                className="w-full flex items-center justify-center gap-2 px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 transition-colors"
              >
                <Download className="w-4 h-4" />
                Export CSV
              </button>
            </div>
          </div>
        </div>

        {/* Analytics Cards */}
        {analytics && (
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <div className="bg-white rounded-lg shadow p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Total Violations</p>
                  <p className="text-3xl font-bold text-gray-900">{analytics.totalViolations}</p>
                </div>
                <div className="p-3 bg-red-100 rounded-full">
                  <AlertTriangle className="w-6 h-6 text-red-600" />
                </div>
              </div>
            </div>

            <div className="bg-white rounded-lg shadow p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Unique Users</p>
                  <p className="text-3xl font-bold text-gray-900">{analytics.uniqueUsers}</p>
                </div>
                <div className="p-3 bg-blue-100 rounded-full">
                  <Users className="w-6 h-6 text-blue-600" />
                </div>
              </div>
            </div>

            <div className="bg-white rounded-lg shadow p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Violation Types</p>
                  <p className="text-3xl font-bold text-gray-900">{analytics.violationsByType.length}</p>
                </div>
                <div className="p-3 bg-purple-100 rounded-full">
                  <Activity className="w-6 h-6 text-purple-600" />
                </div>
              </div>
            </div>

            <div className="bg-white rounded-lg shadow p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Time Period</p>
                  <p className="text-lg font-bold text-gray-900">
                    {Math.ceil((new Date(dateRange.endDate) - new Date(dateRange.startDate)) / (1000 * 60 * 60 * 24))} days
                  </p>
                </div>
                <div className="p-3 bg-green-100 rounded-full">
                  <Calendar className="w-6 h-6 text-green-600" />
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Violations by Type */}
        {analytics && analytics.violationsByType.length > 0 && (
          <div className="bg-white rounded-lg shadow p-6 mb-8">
            <h2 className="text-xl font-bold text-gray-900 mb-4">Violations by Type</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {analytics.violationsByType.map((item) => (
                <div key={item.type} className="border border-gray-200 rounded-lg p-4">
                  <div className="flex items-center justify-between mb-2">
                    <span className={`px-2 py-1 rounded text-sm font-medium ${getViolationTypeColor(item.type)}`}>
                      {getViolationTypeLabel(item.type)}
                    </span>
                    <span className="text-2xl font-bold text-gray-900">{item.count}</span>
                  </div>
                  <p className="text-sm text-gray-600">
                    Affected users: {item.uniqueUsers}
                  </p>
                  <div className="mt-2 w-full bg-gray-200 rounded-full h-2">
                    <div
                      className="bg-blue-600 h-2 rounded-full"
                      style={{ width: `${(item.count / analytics.totalViolations) * 100}%` }}
                    ></div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Recent Violations Table */}
        <div className="bg-white rounded-lg shadow">
          <div className="px-6 py-4 border-b border-gray-200">
            <h2 className="text-xl font-bold text-gray-900">Recent Violations</h2>
          </div>
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Timestamp
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    User
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Quiz
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Type
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Warning #
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {warnings.map((warning) => (
                  <tr key={warning._id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      {new Date(warning.timestamp).toLocaleString()}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm font-medium text-gray-900">
                        {warning.user?.name || 'Unknown'}
                      </div>
                      <div className="text-sm text-gray-500">
                        {warning.user?.email || ''}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      {warning.quiz?.title || 'Unknown'}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${getViolationTypeColor(warning.type)}`}>
                        {getViolationTypeLabel(warning.type)}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      {warning.metadata?.warningCount || 1}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          {warnings.length === 0 && (
            <div className="px-6 py-12 text-center text-gray-500">
              No violations found in the selected time period
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ReportsPage;