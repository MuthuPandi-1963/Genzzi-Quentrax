import React, { useState, useEffect } from 'react';


import { useParams, useNavigate } from 'react-router-dom';
import SecureQuizWrapper from '@/components/SecureQuizWrapper';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Clock, CheckCircle, ChevronLeft, ChevronRight, Flag } from 'lucide-react';

import { toast } from 'react-hot-toast';

const QuizPage = () => {
  const { quizId } = useParams();
  const navigate = useNavigate();
  const [quizData, setQuizData] = useState(null);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [answers, setAnswers] = useState({});
  const [timeRemaining, setTimeRemaining] = useState(0);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [flaggedQuestions, setFlaggedQuestions] = useState(new Set());
  const [userId] = useState(() => localStorage.getItem('userId') || 'demo-user');

  // Fetch quiz data
  useEffect(() => {
    const startQuiz = async () => {
      try {
        const response = await fetch('/api/attempts/start', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ quizId, userId })
        });

        const data = await response.json();
        if (data.success) {
          setQuizData(data.data);
          setTimeRemaining(data.data.duration * 60); // Convert minutes to seconds
        } else {
          toast.error(data.message || 'Failed to start quiz');
          navigate('/assessments');
        }
      } catch (error) {
        console.error('Error starting quiz:', error);
        toast.error('Failed to start quiz');
        navigate('/assessments');
      }
    };

    if (quizId && userId) {
      startQuiz();
    }
  }, [quizId, userId, navigate]);

  // Timer
  useEffect(() => {
    if (timeRemaining <= 0 || isSubmitted || !quizData) return;

    const timer = setInterval(() => {
      setTimeRemaining(prev => {
        if (prev <= 1) {
          handleSubmit();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [timeRemaining, isSubmitted, quizData]);

  const formatTime = (seconds) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const handleAnswerSelect = (questionId, selectedOption) => {
    setAnswers(prev => ({
      ...prev,
      [questionId]: selectedOption
    }));

    // Auto-save answer
    const answerObj = quizData.questions.find(q => q.id === questionId);
    if (answerObj) {
      saveAnswer(answerObj.answerId, selectedOption);
    }
  };

  const saveAnswer = async (answerId, selectedOption) => {
    try {
      await fetch('/api/attempts/save-answer', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          attemptId: quizData.attemptId,
          userId,
          answerId,
          selectedOption
        })
      });
    } catch (error) {
      console.error('Error saving answer:', error);
    }
  };

  const handleSubmit = async () => {
    if (isSubmitted) return;

    try {
      const formattedAnswers = quizData.questions.map(q => ({
        questionId: q.id,
        answerId: q.answerId,
        selectedOption: answers[q.id] || null
      }));

      const response = await fetch('/api/attempts/submit', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          attemptId: quizData.attemptId,
          userId,
          answers: formattedAnswers
        })
      });

      const data = await response.json();
      if (data.success) {
        setIsSubmitted(true);
        toast.success('Quiz submitted successfully!');
        
        if (data.data.resultVisible) {
          navigate(`/quiz-results/${quizData.attemptId}`);
        } else {
          navigate('/assessments');
        }
      } else {
        toast.error(data.message || 'Failed to submit quiz');
      }
    } catch (error) {
      console.error('Error submitting quiz:', error);
      toast.error('Failed to submit quiz');
    }
  };



  const toggleFlag = (questionId) => {
    setFlaggedQuestions(prev => {
      const newSet = new Set(prev);
      if (newSet.has(questionId)) {
        newSet.delete(questionId);
      } else {
        newSet.add(questionId);
      }
      return newSet;
    });
  };

  if (!quizData) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  const currentQuestion = quizData.questions[currentQuestionIndex];
  const progress = ((currentQuestionIndex + 1) / quizData.questions.length) * 100;
  const answeredCount = Object.keys(answers).length;

  return (
    <SecureQuizWrapper
      quizId={quizId}
      userId={userId}
      attemptId={quizData?.attemptId}
    >

      <div className="min-h-screen bg-gray-50">
        {/* Timer & Progress Bar */}
        <div className="bg-white shadow-sm border-b sticky top-14 z-40">
          <div className="max-w-7xl mx-auto px-4 py-3">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <Clock className={`w-5 h-5 ${timeRemaining < 300 ? 'text-red-500 animate-pulse' : 'text-gray-500'}`} />
                <span className={`font-mono text-lg font-bold ${timeRemaining < 300 ? 'text-red-600' : 'text-gray-900'}`}>
                  {formatTime(timeRemaining)}
                </span>
              </div>
              <div className="text-sm text-gray-600">
                Question {currentQuestionIndex + 1} of {quizData.questions.length}
              </div>
              <div className="flex items-center gap-2">
                <Badge variant="outline">
                  Answered: {answeredCount}/{quizData.questions.length}
                </Badge>
                {flaggedQuestions.size > 0 && (
                  <Badge variant="secondary">
                    Flagged: {flaggedQuestions.size}
                  </Badge>
                )}
              </div>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2">
              <div 
                className="bg-blue-600 h-2 rounded-full transition-all duration-300" 
                style={{ width: `${progress}%` }}
              ></div>
            </div>
          </div>
        </div>

        {/* Main Content */}
        <div className="max-w-4xl mx-auto px-4 py-8">
          <Card>
            <CardHeader>
              <div className="flex items-start justify-between">
                <div>
                  <CardTitle className="text-lg">
                    <span className="text-blue-600 mr-2">Q{currentQuestionIndex + 1}.</span>
                    {currentQuestion.questionText}
                  </CardTitle>
                  <div className="flex items-center gap-2 mt-2">
                    <Badge variant="outline">{currentQuestion.questionType}</Badge>
                    <Badge variant="secondary">{currentQuestion.marks} marks</Badge>
                    {flaggedQuestions.has(currentQuestion.id) && (
                      <Badge variant="destructive" className="flex items-center gap-1">
                        <Flag className="w-3 h-3" /> Flagged
                      </Badge>
                    )}
                  </div>
                </div>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => toggleFlag(currentQuestion.id)}
                  className={flaggedQuestions.has(currentQuestion.id) ? 'bg-red-50 text-red-600' : ''}
                >
                  <Flag className="w-4 h-4" />
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              {/* Options for MCQ */}
              {currentQuestion.questionType === 'MCQ' && currentQuestion.options && (
                <div className="space-y-3">
                  {currentQuestion.options.map((option, idx) => (
                    <div
                      key={idx}
                      onClick={() => handleAnswerSelect(currentQuestion.id, option)}
                      className={`p-4 border rounded-lg cursor-pointer transition-all ${
                        answers[currentQuestion.id] === option
                          ? 'border-blue-500 bg-blue-50 ring-2 ring-blue-200'
                          : 'border-gray-200 hover:border-gray-300 hover:bg-gray-50'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center ${
                          answers[currentQuestion.id] === option
                            ? 'border-blue-500 bg-blue-500 text-white'
                            : 'border-gray-300'
                        }`}>
                          {answers[currentQuestion.id] === option && (
                            <CheckCircle className="w-4 h-4" />
                          )}
                        </div>
                        <span className="font-medium">{option}</span>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/* True/False */}
              {currentQuestion.questionType === 'TRUE_FALSE' && (
                <div className="space-y-3">
                  <div
                    onClick={() => handleAnswerSelect(currentQuestion.id, true)}
                    className={`p-4 border rounded-lg cursor-pointer transition-all ${
                      answers[currentQuestion.id] === true
                        ? 'border-green-500 bg-green-50 ring-2 ring-green-200'
                        : 'border-gray-200 hover:border-gray-300 hover:bg-gray-50'
                    }`}
                  >
                    <span className="font-medium">True</span>
                  </div>
                  <div
                    onClick={() => handleAnswerSelect(currentQuestion.id, false)}
                    className={`p-4 border rounded-lg cursor-pointer transition-all ${
                      answers[currentQuestion.id] === false
                        ? 'border-red-500 bg-red-50 ring-2 ring-red-200'
                        : 'border-gray-200 hover:border-gray-300 hover:bg-gray-50'
                    }`}
                  >
                    <span className="font-medium">False</span>
                  </div>
                </div>
              )}

              {/* Fill in the Blank */}
              {currentQuestion.questionType === 'FILL_BLANK' && (
                <div className="space-y-3">
                  <input
                    type="text"
                    value={answers[currentQuestion.id] || ''}
                    onChange={(e) => handleAnswerSelect(currentQuestion.id, e.target.value)}
                    placeholder="Type your answer here..."
                    className="w-full p-4 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  />
                </div>
              )}

              {/* Navigation */}
              <div className="flex items-center justify-between mt-8 pt-6 border-t">
                <Button
                  variant="outline"
                  onClick={() => setCurrentQuestionIndex(prev => Math.max(0, prev - 1))}
                  disabled={currentQuestionIndex === 0}
                >
                  <ChevronLeft className="w-4 h-4 mr-1" />
                  Previous
                </Button>

                <div className="flex items-center gap-2">
                  <Button
                    variant="destructive"
                    onClick={() => {
                      if (window.confirm('Are you sure you want to submit the quiz?')) {
                        handleSubmit();
                      }
                    }}
                  >
                    Submit Quiz
                  </Button>
                </div>

                <Button
                  variant="outline"
                  onClick={() => setCurrentQuestionIndex(prev => Math.min(quizData.questions.length - 1, prev + 1))}
                  disabled={currentQuestionIndex === quizData.questions.length - 1}
                >
                  Next
                  <ChevronRight className="w-4 h-4 ml-1" />
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Question Navigator */}
          <Card className="mt-6">
            <CardHeader>
              <CardTitle className="text-lg">Question Navigator</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-5 md:grid-cols-10 gap-2">
                {quizData.questions.map((q, idx) => (
                  <button
                    key={q.id}
                    onClick={() => setCurrentQuestionIndex(idx)}
                    className={`p-2 text-sm rounded-lg border transition-all ${
                      idx === currentQuestionIndex
                        ? 'border-blue-500 bg-blue-50 ring-2 ring-blue-200'
                        : answers[q.id]
                        ? 'border-green-500 bg-green-50'
                        : 'border-gray-200 hover:border-gray-300'
                    } ${flaggedQuestions.has(q.id) ? 'ring-2 ring-red-300' : ''}`}
                  >
                    {idx + 1}
                  </button>
                ))}
              </div>
              <div className="flex items-center gap-4 mt-4 text-xs text-gray-500">
                <div className="flex items-center gap-1">
                  <div className="w-3 h-3 bg-blue-50 border border-blue-500 rounded"></div>
                  Current
                </div>
                <div className="flex items-center gap-1">
                  <div className="w-3 h-3 bg-green-50 border border-green-500 rounded"></div>
                  Answered
                </div>
                <div className="flex items-center gap-1">
                  <div className="w-3 h-3 border border-gray-200 rounded"></div>
                  Unanswered
                </div>
                <div className="flex items-center gap-1">
                  <div className="w-3 h-3 border border-red-300 ring-2 ring-red-200 rounded"></div>
                  Flagged
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </SecureQuizWrapper>
  );
};

export default QuizPage;