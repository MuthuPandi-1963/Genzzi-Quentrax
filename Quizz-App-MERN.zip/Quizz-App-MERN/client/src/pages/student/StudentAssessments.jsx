import React from "react";
import { Calendar, Clock, FileText, AlertCircle, CheckCircle2, Play } from "lucide-react";
import { useMyAssessments, useRefAssessmentStart, useAssessmentState } from "@/hooks/useUserAssessments";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";
import { toast } from "react-hot-toast";
import PropTypes from "prop-types";

export default function StudentAssessments() {
  const navigate = useNavigate();
  const { 
    assessments, 
    activeAssessments, 
    upcomingAssessments, 
    expiredAssessments,
    loading, 
    error 
  } = useMyAssessments();
  const { startAssessment, isLoading: isStarting } = useRefAssessmentStart();

  const handleStartAssessment = (assessmentId) => {
    startAssessment(assessmentId, {
      onSuccess: () => {
        // Navigate to quiz/test page
        navigate(`/quiz/${assessmentId}`);
      },
      onError: (err) => {
        toast.error(err?.response?.data?.message || "Cannot start assessment");
      },
    });
  };

  if (loading) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-24 text-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto"></div>
        <p className="mt-4 text-muted-foreground">Loading assessments...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-24 text-center">
        <AlertCircle className="h-12 w-12 text-red-500 mx-auto mb-4" />
        <p className="text-red-600">Failed to load assessments</p>
        <Button 
          variant="outline" 
          className="mt-4"
          onClick={() => window.location.reload()}
        >
          Retry
        </Button>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto px-4 py-24 space-y-8">
      <div>
        <h1 className="text-3xl font-bold">My Assessments</h1>
        <p className="text-muted-foreground mt-1">
          View and complete your assigned assessments
        </p>
      </div>

      {/* Active Assessments */}
      {activeAssessments.length > 0 && (
        <section>
          <div className="flex items-center gap-2 mb-4">
            <CheckCircle2 className="h-5 w-5 text-green-600" />
            <h2 className="text-xl font-semibold">Available Now ({activeAssessments.length})</h2>
          </div>
          <div className="grid gap-4">
            {activeAssessments.map((assignment) => (
              <AssessmentCard
                key={assignment.id}
                assignment={assignment}
                onStart={() => handleStartAssessment(assignment.assessmentId, assignment.assessment)}
                isStarting={isStarting}
              />
            ))}
          </div>
        </section>
      )}

      {/* Upcoming Assessments */}
      {upcomingAssessments.length > 0 && (
        <section>
          <div className="flex items-center gap-2 mb-4">
            <Calendar className="h-5 w-5 text-blue-600" />
            <h2 className="text-xl font-semibold">Upcoming ({upcomingAssessments.length})</h2>
          </div>
          <div className="grid gap-4">
            {upcomingAssessments.map((assignment) => (
              <AssessmentCard
                key={assignment.id}
                assignment={assignment}
                onStart={() => {}}
                isStarting={false}
              />
            ))}
          </div>
        </section>
      )}

      {/* Expired Assessments */}
      {expiredAssessments.length > 0 && (
        <section>
          <div className="flex items-center gap-2 mb-4">
            <AlertCircle className="h-5 w-5 text-orange-600" />
            <h2 className="text-xl font-semibold">Expired ({expiredAssessments.length})</h2>
          </div>
          <div className="grid gap-4">
            {expiredAssessments.map((assignment) => (
              <AssessmentCard
                key={assignment.id}
                assignment={assignment}
                onStart={() => {}}
                isStarting={false}
              />
            ))}
          </div>
        </section>
      )}

      {/* Empty State */}
      {!assessments?.length && (
        <Card>
          <CardContent className="py-12 text-center">
            <FileText className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <p className="text-muted-foreground">No assessments assigned yet.</p>
            <p className="text-sm text-muted-foreground mt-2">
              Check back later or contact your instructor.
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

function AssessmentCard({ assignment, onStart, isStarting }) {
  const { assessment } = assignment;
  const assessmentState = useAssessmentState(assessment);

  const formatDate = (dateString) => {
    if (!dateString) return "N/A";
    const date = new Date(dateString);
    return date.toLocaleDateString("en-US", {
      month: "short",
      day: "numeric",
      year: "numeric",
    });
  };


  const getStateBadgeVariant = (state) => {
    switch (state) {
      case "active":
        return "default";
      case "upcoming":
        return "secondary";
      case "expired":
        return "destructive";
      default:
        return "outline";
    }
  };

  const getAssignmentStatusColor = (status) => {
    switch (status) {
      case "PENDING":
        return "bg-yellow-100 text-yellow-800";
      case "IN_PROGRESS":
        return "bg-blue-100 text-blue-800";
      case "COMPLETED":
        return "bg-green-100 text-green-800";
      case "EXEMPTED":
        return "bg-gray-100 text-gray-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  return (
    <Card className={`hover:shadow-md transition-shadow ${!assessmentState.isAvailable ? 'opacity-75' : ''}`}>
      <CardHeader className="pb-3">
        <div className="flex justify-between items-start gap-4">
          <div className="flex-1">
            <CardTitle className="text-lg">{assessment.title}</CardTitle>
            {assessment.description && (
              <p className="text-sm text-muted-foreground mt-1 line-clamp-2">
                {assessment.description}
              </p>
            )}
          </div>
          <div className="flex items-center gap-2 flex-shrink-0">
            <Badge variant={getStateBadgeVariant(assessmentState.state)}>
              {assessmentState.state.toUpperCase()}
            </Badge>
            <Badge className={getAssignmentStatusColor(assignment.status)} variant="outline">
              {assignment.status}
            </Badge>
          </div>
        </div>
      </CardHeader>

      <CardContent>
        <div className="grid gap-4">
          {/* Assessment Info */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
            {assessment.timeLimit && (
              <div className="flex items-center gap-2">
                <Clock className="h-4 w-4 text-muted-foreground" />
                <span>{assessment.timeLimit} minutes</span>
              </div>
            )}
            {assessment.startDate && (
              <div className="flex items-center gap-2">
                <Calendar className="h-4 w-4 text-muted-foreground" />
                <span>From: {formatDate(assessment.startDate)}</span>
              </div>
            )}
            {assessment.endDate && (
              <div className="flex items-center gap-2">
                <Calendar className="h-4 w-4 text-muted-foreground" />
                <span>Until: {formatDate(assessment.endDate)}</span>
              </div>
            )}
            {assessment.quiz && (
              <div className="flex items-center gap-2">
                <FileText className="h-4 w-4 text-muted-foreground" />
                <span>{assessment.quiz.totalPoints || 0} points</span>
              </div>
            )}
          </div>

          {/* Availability Info */}
          {!assessmentState.isAvailable && assessmentState.reason && (
            <div className="text-sm text-muted-foreground bg-muted p-2 rounded">
              {assessmentState.reason}
            </div>
          )}

          {/* Action Button */}
          <div className="flex justify-end">
            {assessmentState.isAvailable ? (
              <Button 
                onClick={onStart} 
                disabled={isStarting}
                size="sm"
              >
                {isStarting ? (
                  <>
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                    Starting...
                  </>
                ) : (
                  <>
                    <Play className="h-4 w-4 mr-2" />
                    Start Assessment
                  </>
                )}
              </Button>
            ) : (
              <Button disabled size="sm" variant="outline">
                {assessmentState.buttonLabel}
              </Button>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

AssessmentCard.propTypes = {
  assignment: PropTypes.shape({
    id: PropTypes.string.isRequired,
    assessmentId: PropTypes.string.isRequired,
    status: PropTypes.string.isRequired,
    assessment: PropTypes.shape({
      title: PropTypes.string.isRequired,
      description: PropTypes.string,
      timeLimit: PropTypes.number,
      startDate: PropTypes.string,
      endDate: PropTypes.string,
      published: PropTypes.bool,
      quiz: PropTypes.shape({
        totalPoints: PropTypes.number,
      }),
    }).isRequired,
  }).isRequired,
  onStart: PropTypes.func.isRequired,
  isStarting: PropTypes.bool.isRequired,
};
