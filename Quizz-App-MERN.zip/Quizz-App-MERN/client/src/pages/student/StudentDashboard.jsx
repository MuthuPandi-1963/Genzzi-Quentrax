import { Link } from "react-router-dom";
import { BookOpen, ClipboardList, Trophy, TrendingUp } from "lucide-react";
import { useDashboard } from "@/hooks/useDashboard";
import StatCard from "@/components/custom/StatCard";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

export default function StudentDashboard() {
  const { studentQuery } = useDashboard();
  const data = studentQuery.data;
  const loading = studentQuery.isLoading;

  if (loading) return <p className="p-8">Loading dashboard...</p>;

  return (
    <div className="max-w-6xl mx-auto px-4 py-24 space-y-8">
      <div>
        <h1 className="text-3xl font-bold">Student Dashboard</h1>
        <p className="text-muted-foreground">Track quizzes, assessments, and your progress</p>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <StatCard title="Avg Score" value={`${data?.avgScore ?? 0}%`} icon={TrendingUp} />
        <StatCard title="Attempts" value={data?.totalAttempts ?? 0} icon={BookOpen} />
        <StatCard title="Rank" value={data?.rank ? `#${data.rank}` : "—"} icon={Trophy} />
        <StatCard
          title="Assessments"
          value={data?.assignedAssessments?.length ?? 0}
          icon={ClipboardList}
        />
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle>Quick actions</CardTitle>
          </CardHeader>
          <CardContent className="flex flex-wrap gap-2">
            <Button asChild>
              <Link to="/topics">Take a Quiz</Link>
            </Button>
            <Button variant="outline" asChild>
              <Link to="/student/assessments">Assessments</Link>
            </Button>
            <Button variant="outline" asChild>
              <Link to="/student/results">View Results</Link>
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Assigned assessments</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            {(data?.assignedAssessments ?? []).slice(0, 5).map((a) => (
              <div key={a.id} className="flex justify-between items-center border-b pb-2">
                <span className="text-sm font-medium">{a.assessment?.title}</span>
                <Badge variant="outline">{a.assessment?.type}</Badge>
              </div>
            ))}
            {!data?.assignedAssessments?.length && (
              <p className="text-sm text-muted-foreground">No assessments assigned yet.</p>
            )}
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Recent quiz attempts</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            {(data?.recentAttempts ?? []).map((h) => (
              <div key={h.id} className="flex justify-between py-2 border-b">
                <span>{h.quiz?.title}</span>
                <span className="font-semibold text-primary">{h.score}%</span>
              </div>
            ))}
            {!data?.recentAttempts?.length && (
              <p className="text-sm text-muted-foreground">No attempts yet. Start a quiz!</p>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
