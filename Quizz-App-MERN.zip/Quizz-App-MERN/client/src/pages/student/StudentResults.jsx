import { useSelector } from "react-redux";
import { useQuery } from "@tanstack/react-query";
import { QuizHistoryAPI } from "@/api/quiz.history.api";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

export default function StudentResults() {
  const userId = useSelector((s) => s.user.user?.id);
  const { data, isLoading } = useQuery({
    queryKey: ["quiz-history", userId],
    queryFn: () => QuizHistoryAPI.getByUser(userId),
    enabled: !!userId,
    select: (r) => r.data,
  });

  if (isLoading) return <p className="p-8 pt-24">Loading results...</p>;

  const history = data?.data ?? data ?? [];

  return (
    <div className="max-w-4xl mx-auto px-4 py-24 space-y-6">
      <h1 className="text-3xl font-bold">My Results</h1>
      <p className="text-muted-foreground">Score analysis and quiz attempt history</p>

      <div className="grid gap-4">
        {history.map((h) => (
          <Card key={h.id}>
            <CardHeader className="flex flex-row justify-between">
              <CardTitle className="text-base">{h.quiz?.title}</CardTitle>
              <Badge variant={h.score >= 60 ? "default" : "destructive"}>
                {h.score}%
              </Badge>
            </CardHeader>
            <CardContent className="text-sm text-muted-foreground">
              Completed: {new Date(h.completedAt).toLocaleString()}
            </CardContent>
          </Card>
        ))}
        {!history.length && <p className="text-muted-foreground">No results yet.</p>}
      </div>
    </div>
  );
}
