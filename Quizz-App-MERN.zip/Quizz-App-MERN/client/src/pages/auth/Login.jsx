"use client";

import React, { useState, useCallback } from "react";
import SignupImage from "@/assets/8c07bbba3700334b31f217f98658ff15-Picsart-BackgroundRemover.jpg";
import { motion } from "framer-motion";
import { Eye, EyeOff, Mail, Lock, ArrowRight, Award } from "lucide-react";
import Background from "@/assets/signu.jpg";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";

import { useAuth } from "@/hooks/useAuth";
import { toast } from "react-hot-toast";
import { Link, useNavigate } from "react-router-dom";
import { useDispatch } from "react-redux";
import { setUser } from "../../store/slices";
import { getRoleHomePath } from "@/utils/roleRedirect";

export default function Login() {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const { useLogin: loginMutation } = useAuth();

  const [showPassword, setShowPassword] = useState(false);

  const [formData, setFormData] = useState({
    email: "",
    password: "",
  });

  const handleChange = useCallback((e) => {
    const { name, value } = e.target;

    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  }, []);

  const handleSubmit = useCallback(
    (e) => {
      e.preventDefault();

      if (loginMutation.isPending) return;

      const email = formData.email.trim();
      const password = formData.password.trim();

      if (!email || !password) {
        toast.error("Email and password are required");
        return;
      }

      loginMutation.mutate(
        { email, password },
        {
          onSuccess: (res) => {
            const user = res?.data?.data;

            toast.success(res?.data?.message || "Login successful");

            if (user) {
              dispatch(setUser(user));

              navigate(getRoleHomePath(user.role), { replace: true });
            }
          },

          onError: (err) => {
            const message =
              err?.response?.data?.message ||
              err?.message ||
              "Unable to login. Please try again.";

            toast.error(message);
          },
        },
      );
    },
    [dispatch, formData, loginMutation, navigate],
  );

  return (
    <div
      className="min-h-screen relative overflow-hidden bg-cover bg-center bg-no-repeat"
      style={{
        backgroundImage: `url(${Background})`,
      }}
    >
      {/* Overlay */}
      <div className="absolute inset-0 bg-black/50" />

      {/* Main Content */}
      <div className="relative z-10 min-h-screen flex items-center justify-center px-6">
        <div className="w-full max-w-7xl flex items-center justify-between gap-16">
          {/* Left Animated Image */}
          <motion.div
            className="hidden lg:flex flex-1 justify-center items-center"
            initial={{ opacity: 0, x: -100 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
          >
            <div className="relative">
              {/* Glow Effect */}
              <div className="absolute inset-0 bg-blue-500/20 blur-3xl rounded-full scale-125" />

              <motion.img
                src={SignupImage}
                alt="Learning Illustration"
                className="relative z-10 w-[500px] max-w-full drop-shadow-2xl"
                animate={{
                  y: [0, -20, 0],
                  rotate: [0, 2, 0, -2, 0],
                }}
                transition={{
                  duration: 6,
                  repeat: Infinity,
                  ease: "easeInOut",
                }}
                whileHover={{
                  scale: 1.05,
                }}
              />
            </div>
          </motion.div>

          {/* Login Card */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="w-full max-w-md"
          >
            <Card className="border-0 shadow-2xl bg-white/95 backdrop-blur-md">
              <CardHeader className="text-center space-y-4">
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{
                    delay: 0.2,
                    type: "spring",
                  }}
                >
                  <div className="w-16 h-16 mx-auto rounded-full bg-gradient-to-r from-blue-500 to-purple-600 flex items-center justify-center">
                    <Award className="w-8 h-8 text-white" />
                  </div>
                </motion.div>

                <div>
                  <CardTitle className="text-3xl font-bold text-slate-900">
                    Welcome Back
                  </CardTitle>

                  <CardDescription className="mt-2">
                    Sign in to continue to your account
                  </CardDescription>
                </div>
              </CardHeader>

              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-5">
                  {" "}
                  {/* Email */}
                  <div className="space-y-2">
                    <Label htmlFor="email">Email Address</Label>{" "}
                    <div className="relative">
                      {" "}
                      <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />{" "}
                      <Input
                        id="email"
                        name="email"
                        type="email"
                        autoComplete="email"
                        placeholder="Enter your email"
                        value={formData.email}
                        onChange={handleChange}
                        className="pl-10 h-11 text-accent-foreground"
                        required
                      />{" "}
                    </div>{" "}
                  </div>{" "}
                  {/* Password */}{" "}
                  <div className="space-y-2">
                    {" "}
                    <Label htmlFor="password">Password</Label>{" "}
                    <div className="relative">
                      <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-accent-foreground" />{" "}
                      <Input
                        id="password"
                        name="password"
                        type={showPassword ? "text" : "password"}
                        autoComplete="current-password"
                        placeholder="Enter your password"
                        value={formData.password}
                        onChange={handleChange}
                        className="pl-10 pr-12 h-11 text-accent-foreground"
                        required
                      />{" "}
                      <button
                        type="button"
                        aria-label={
                          showPassword ? "Hide password" : "Show password"
                        }
                        onClick={() => setShowPassword((prev) => !prev)}
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                      >
                        {" "}
                        {showPassword ? (
                          <EyeOff className="h-4 w-4" />
                        ) : (
                          <Eye className="h-4 w-4" />
                        )}{" "}
                      </button>{" "}
                    </div>{" "}
                  </div>{" "}
                  {/* Submit */}{" "}
                  <Button
                    type="submit"
                    disabled={loginMutation.isPending}
                    className="w-full h-11 bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700"
                  >
                    {" "}
                    {loginMutation.isPending ? (
                      <div className="h-5 w-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    ) : (
                      <>
                        {" "}
                        Sign In <ArrowRight className="ml-2 h-4 w-4" />{" "}
                      </>
                    )}{" "}
                  </Button>{" "}
                </form>{" "}
                <div className="mt-6 text-center text-sm text-muted-foreground">
                  {" "}
                  Don't have an account?{" "}
                  <Link
                    to="/signup"
                    className="font-medium text-primary hover:underline"
                  >
                    {" "}
                    Sign up{" "}
                  </Link>{" "}
                </div>{" "}
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </div>
    </div>
  );
}
