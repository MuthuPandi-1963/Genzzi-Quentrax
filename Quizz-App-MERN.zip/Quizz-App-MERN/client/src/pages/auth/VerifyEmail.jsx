import { Atom } from 'react-loading-indicators';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { useAuth } from '../../hooks/useAuth';
import { useDispatch } from 'react-redux';
import { setUser } from '../../store/slices';

function VerifyEmail() {
  const [searchParams] = useSearchParams();
  const token = searchParams.get('token');
  const nav = useNavigate();
  console.log(token);
  const {useVerifyEmail} = useAuth()
  const dispatch = useDispatch()

  const {data,isLoading,isSuccess,isError} = useVerifyEmail(token)
  
  


  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <Atom color="blue" size="large" text="Verifying..." textColor="black" />
      </div>
    );
  }
  if(isSuccess){
    console.log(data?.data);
    
    dispatch(setUser(data?.data?.data))
    nav("/")
  }
  if(isError){
    nav("/login")
  }
}

export default VerifyEmail;
