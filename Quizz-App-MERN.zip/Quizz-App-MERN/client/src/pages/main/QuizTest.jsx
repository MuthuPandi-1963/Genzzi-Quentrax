import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import { motion, AnimatePresence } from 'framer-motion';
import { createPortal } from 'react-dom';

const QuizTest = ({ quiz, onExit, onSubmit }) => {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedOption, setSelectedOption] = useState(null);
  const [textAnswer, setTextAnswer] = useState('');
  const [answers, setAnswers] = useState([]);
  const [showExitConfirm, setShowExitConfirm] = useState(false);
  // fullscreen state removed (not required in UI)
  const [timeLeft, setTimeLeft] = useState(quiz?.timeLimit * 60 || 1800);

  const questions = quiz?.questions || [];

  // Enter fullscreen when component mounts
  useEffect(() => {
    enterFullscreen();
    document.body.style.overflow = 'hidden';
    
    return () => {
      exitFullscreen();
      document.body.style.overflow = 'unset';
    };
  }, []);

  // Timer effect
  useEffect(() => {
    if (timeLeft <= 0) {
      handleSubmit();
      return;
    }

    const timer = setInterval(() => {
      setTimeLeft(timeLeft - 1);
    }, 1000);

    return () => clearInterval(timer);
  }, [timeLeft]);

  // Reset answer state when question changes
  useEffect(() => {
    const currentAnswer = answers[currentQuestion];
    if (currentAnswer !== undefined) {
      if (isTextInputQuestion(questions[currentQuestion])) {
        setTextAnswer(currentAnswer || '');
      } else {
        setSelectedOption(currentAnswer);
      }
    } else {
      setSelectedOption(null);
      setTextAnswer('');
    }
  }, [currentQuestion, answers, questions]);

  const enterFullscreen = () => {
    const element = document.documentElement;
    if (element.requestFullscreen) {
      element.requestFullscreen();
    } else {
      // no-op when fullscreen API not available
    }
  };

  const exitFullscreen = () => {
    if (document.exitFullscreen) {
      document.exitFullscreen();
    }
  };

  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  // Helper functions to determine question type


  const isTrueFalseQuestion = (question) => {
    return question.options && question.options.length === 2 && 
           question.options.some(opt => opt.text.toLowerCase() === 'true') &&
           question.options.some(opt => opt.text.toLowerCase() === 'false');
  };

  const isTextInputQuestion = (question) => {
    return question.options && question.options.length === 1 && 
           question.options[0].isCorrect;
  };

  const getQuestionType = (question) => {
    if (isTextInputQuestion(question)) return 'fill_in_blank';
    if (isTrueFalseQuestion(question)) return 'true_false';
    return 'mcq';
  };

  const handleOptionSelect = (optionIndex) => {
    setSelectedOption(optionIndex);
    
    // Auto-save answer
    const newAnswers = [...answers];
    newAnswers[currentQuestion] = optionIndex;
    setAnswers(newAnswers);
  };

  const handleTextAnswerChange = (value) => {
    setTextAnswer(value);
    
    // Auto-save answer
    const newAnswers = [...answers];
    newAnswers[currentQuestion] = value;
    setAnswers(newAnswers);
  };

  const handleNext = () => {
    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
    }
  };

  const handlePrevious = () => {
    if (currentQuestion > 0) {
      setCurrentQuestion(currentQuestion - 1);
    }
  };

  const handleSubmit = () => {
    const results = questions.map((question, index) => {
      const userAnswer = answers[index];
      
      if (isTextInputQuestion(question)) {
        // For fill in the blank - compare text answer (case insensitive, trim whitespace)
        const correctAnswer = question.options[0].text.toLowerCase().trim();
        const userAnswerText = (userAnswer || '').toString().toLowerCase().trim();
        return {
          questionId: question.id,
          userAnswer: userAnswer,
          isCorrect: userAnswerText === correctAnswer,
          correctAnswer: correctAnswer
        };
      } else {
        // For MCQ and True/False - check selected option
        const isCorrect = userAnswer !== undefined ? 
          question.options[userAnswer]?.isCorrect : false;
        return {
          questionId: question.id,
          selectedOption: userAnswer,
          isCorrect: isCorrect,
          correctAnswer: question.options.findIndex(opt => opt.isCorrect)
        };
      }
    });
    
    onSubmit(results);
    exitFullscreen();
  };

  const handleExit = () => {
    setShowExitConfirm(true);
  };

  const confirmExit = () => {
    exitFullscreen();
    onExit();
  };

  const cancelExit = () => {
    setShowExitConfirm(false);
  };

  if (!questions || questions.length === 0) {
    return (
      <div className="fixed inset-0 bg-white z-50 flex items-center justify-center">
        <div className="text-center">
          <p className="text-xl text-gray-600">No questions available</p>
          <button 
            onClick={onExit}
            className="mt-4 px-6 py-2 bg-blue-500 text-white rounded-lg"
          >
            Exit
          </button>
        </div>
      </div>
    );
  }

  const currentQ = questions[currentQuestion];
  const progress = ((currentQuestion + 1) / questions.length) * 100;
  const questionType = getQuestionType(currentQ);

  // Check if current question has an answer
  const hasAnswer = answers[currentQuestion] !== undefined && 
                   (questionType === 'fill_in_blank' ? textAnswer.trim() !== '' : true);

  return createPortal(
    <div className="fixed inset-0 bg-white z-50 flex flex-col">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-600 to-purple-600 text-white p-4 shadow-lg">
        <div className="flex justify-between items-center mb-4">
          <div>
            <h1 className="text-xl font-bold">{quiz?.title || 'Quiz'}</h1>
            <p className="text-blue-100 text-sm">{currentQ?.topic?.name || quiz?.topic?.name}</p>
            <span className="inline-block mt-1 px-2 py-1 bg-blue-500 rounded text-xs">
              {questionType === 'mcq' ? 'Multiple Choice' : 
               questionType === 'true_false' ? 'True/False' : 'Fill in the Blank'}
            </span>
          </div>
          <div className="text-right">
            <div className="text-2xl font-mono font-bold">{formatTime(timeLeft)}</div>
            <div className="text-blue-100 text-sm">Time Remaining</div>
          </div>
        </div>
        
        {/* Progress Bar */}
        <div className="w-full bg-blue-400 rounded-full h-2">
          <motion.div 
            className="bg-white h-2 rounded-full"
            initial={{ width: 0 }}
            animate={{ width: `${progress}%` }}
            transition={{ duration: 0.3 }}
          />
        </div>
        
        <div className="flex justify-between items-center mt-2">
          <span className="text-sm">
            Question {currentQuestion + 1} of {questions.length}
          </span>
          <span className="text-sm">
            {currentQ?.points || 1} point{currentQ?.points !== 1 ? 's' : ''}
          </span>
        </div>
      </div>

      {/* Question Content */}
      <div className="flex-1 overflow-y-auto p-6">
        <motion.div
          key={currentQuestion}
          initial={{ opacity: 0, x: 50 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -50 }}
          transition={{ duration: 0.3 }}
          className="max-w-2xl mx-auto w-full"
        >
          {/* Question */}
          <div className="bg-gray-50 rounded-xl p-6 mb-6 shadow-sm">
            <h2 className="text-lg font-semibold text-gray-800 mb-4">
              {currentQ.questionText}
            </h2>
            
            {currentQ.difficulty && (
              <span className={`inline-flex items-center px-3 py-1 rounded-full text-xs font-medium ${
                currentQ.difficulty === 'easy' ? 'bg-green-100 text-green-800' :
                currentQ.difficulty === 'medium' ? 'bg-yellow-100 text-yellow-800' :
                'bg-red-100 text-red-800'
              }`}>
                {currentQ.difficulty.charAt(0).toUpperCase() + currentQ.difficulty.slice(1)}
              </span>
            )}
          </div>

          {/* Answer Section - Conditionally rendered based on question type */}
          {questionType === 'fill_in_blank' ? (
            // Fill in the Blank Input
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3 }}
              className="bg-white rounded-xl p-6 border-2 border-gray-200"
            >
              <label className="block text-sm font-medium text-gray-700 mb-3">
                Your Answer:
              </label>
              <input
                type="text"
                value={textAnswer}
                onChange={(e) => handleTextAnswerChange(e.target.value)}
                placeholder="Type your answer here..."
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                autoFocus
              />
            </motion.div>
          ) : (
            // MCQ or True/False Options
            <div className="space-y-3">
              {currentQ.options.map((option, index) => (
                <motion.button
                  key={index}
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={() => handleOptionSelect(index)}
                  className={`w-full p-4 rounded-xl text-left transition-all duration-200 border-2 ${
                    selectedOption === index
                      ? 'border-blue-500 bg-blue-50 shadow-md'
                      : 'border-gray-200 bg-white hover:border-gray-300'
                  }`}
                >
                  <div className="flex items-center">
                    <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center mr-3 ${
                      selectedOption === index
                        ? 'border-blue-500 bg-blue-500'
                        : 'border-gray-300'
                    }`}>
                      {selectedOption === index && (
                        <div className="w-2 h-2 rounded-full bg-white" />
                      )}
                    </div>
                    <span className="font-medium text-gray-800">{option.text}</span>
                  </div>
                </motion.button>
              ))}
            </div>
          )}

          {/* Hints */}
          {currentQ.hints && currentQ.hints.length > 0 && (
            <div className="mt-6 bg-yellow-50 border border-yellow-200 rounded-xl p-4">
              <h3 className="font-medium text-yellow-800 mb-2">💡 Hint</h3>
              <p className="text-yellow-700 text-sm">
                {currentQ.hints[Math.min(currentQuestion, currentQ.hints.length - 1)]}
              </p>
            </div>
          )}
        </motion.div>
      </div>

      {/* Navigation Footer */}
      <div className="border-t bg-white p-4 shadow-lg">
        <div className="max-w-2xl mx-auto flex justify-between items-center">
          <button
            onClick={handleExit}
            className="px-6 py-3 border border-red-500 text-red-500 rounded-lg font-medium hover:bg-red-50 transition-colors"
          >
            Exit Quiz
          </button>

          <div className="flex space-x-3">
            {currentQuestion > 0 && (
              <button
                onClick={handlePrevious}
                className="px-6 py-3 border border-gray-300 text-gray-700 rounded-lg font-medium hover:bg-gray-50 transition-colors"
              >
                Previous
              </button>
            )}
            
            <button
              onClick={currentQuestion === questions.length - 1 ? handleSubmit : handleNext}
              disabled={!hasAnswer}
              className={`px-6 py-3 rounded-lg font-medium transition-colors ${
                !hasAnswer
                  ? 'bg-gray-300 text-gray-500 cursor-not-allowed'
                  : 'bg-blue-500 text-white hover:bg-blue-600'
              }`}
            >
              {currentQuestion === questions.length - 1 ? 'Submit Quiz' : 'Next'}
            </button>
          </div>
        </div>
      </div>

      {/* Exit Confirmation Modal */}
      <AnimatePresence>
        {showExitConfirm && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-60"
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-white rounded-xl p-6 max-w-sm mx-4"
            >
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                Exit Quiz?
              </h3>
              <p className="text-gray-600 mb-6">
                Your progress will be lost. Are you sure you want to exit?
              </p>
              <div className="flex space-x-3">
                <button
                  onClick={cancelExit}
                  className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50"
                >
                  Cancel
                </button>
                <button
                  onClick={confirmExit}
                  className="flex-1 px-4 py-2 bg-red-500 text-white rounded-lg hover:bg-red-600"
                >
                  Exit Quiz
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Prevent right-click and text selection */}
      <style>{`
        body {
          overflow: hidden !important;
          user-select: none;
          -webkit-user-select: none;
          -moz-user-select: none;
          -ms-user-select: none;
        }
        
        /* Prevent zoom on mobile */
        @media screen and (max-width: 768px) {
          body {
            touch-action: pan-x pan-y;
          }
        }
      `}</style>
    </div>,
    document.body
  );
};

// Updated usage component with example data
const QuizContainer = ({ quizData, onQuizComplete, onQuizExit }) => {
  const [showQuiz, setShowQuiz] = useState(false);

  // Example quiz data with different question types
  const exampleQuizData = {
    title: "Mixed Questions Quiz",
    timeLimit: 30,
    questions: [
      {
        id: 1,
        questionText: "What is the capital of France?",
        type: "mcq",
        points: 2,
        difficulty: "easy",
        options: [
          { text: "London", isCorrect: false },
          { text: "Berlin", isCorrect: false },
          { text: "Paris", isCorrect: true },
          { text: "Madrid", isCorrect: false }
        ],
        hints: ["It's known as the City of Light"]
      },
      {
        id: 2,
        questionText: "The Earth is flat.",
        type: "true_false",
        points: 1,
        difficulty: "easy",
        options: [
          { text: "True", isCorrect: false },
          { text: "False", isCorrect: true }
        ]
      },
      {
        id: 3,
        questionText: "The chemical symbol for water is ______.",
        type: "fill_in_blank",
        points: 3,
        difficulty: "medium",
        options: [
          { text: "H2O", isCorrect: true }
        ],
        hints: ["It contains hydrogen and oxygen"]
      }
    ]
  };

  const handleQuizSubmit = (results) => {
    console.log('Quiz results:', results);
    setShowQuiz(false);
    onQuizComplete?.(results);
  };

  const handleQuizExit = () => {
    setShowQuiz(false);
    onQuizExit?.();
  };

  if (!showQuiz) {
    return (
      <button 
        onClick={() => setShowQuiz(true)}
        className="px-6 py-3 bg-blue-500 text-white rounded-lg"
      >
        Start Quiz
      </button>
    );
  }

  return (
    <QuizTest
      quiz={quizData || exampleQuizData}
      onExit={handleQuizExit}
      onSubmit={handleQuizSubmit}
    />
  );
};

export default QuizTest;
export { QuizContainer };

QuizTest.propTypes = {
  quiz: PropTypes.object,
  onExit: PropTypes.func,
  onSubmit: PropTypes.func,
};

QuizContainer.propTypes = {
  quizData: PropTypes.object,
  onQuizComplete: PropTypes.func,
  onQuizExit: PropTypes.func,
};