import  React,{ useState, useEffect, useRef } from "react";
import { motion } from "framer-motion";
import { useTopics } from "../../hooks/useTopics";
import { useQuizzesByTopic } from "../../hooks/useQuizzes";
import QuizTest from "./QuizTest";
import { useNavigate, useParams } from "react-router-dom";

const TopicsSlider = () => {
  const { id } = useParams();
  const [topics, setTopics] = useState([]);
  const [selectedTopicId, setSelectedTopicId] = useState(id ? id : null);
  const [selectedQuiz, setSelectedQuiz] = useState(null);
  const [showQuiz, setShowQuiz] = useState(false);
  const [showQuizDialog, setShowQuizDialog] = useState(false);
  const [pendingQuiz, setPendingQuiz] = useState(null);

  const topicsSliderRef = useRef(null);
  const quizzesSliderRef = useRef(null);

  const [topicsConstraints, setTopicsConstraints] = useState({ left: 0, right: 0 });

  const { topics: { data: topicsData = [] }, isLoading: topicsLoading } = useTopics();
  const { data: quizzesData, isLoading: quizzesLoading } = useQuizzesByTopic(selectedTopicId, {
    enabled: !!selectedTopicId,
  });
  
  const navigate = useNavigate();

  /** Sync topics when fetched */
  useEffect(() => {
    if (topicsData.length > 0) {
      setTopics(topicsData);
      if (!selectedTopicId) setSelectedTopicId(topicsData[0].id);
    }
  }, [topicsData]);

  /** Calculate drag constraints for topics slider */
  useEffect(() => {
    if (topicsSliderRef.current && topics.length > 0) {
      const scrollWidth = topicsSliderRef.current.scrollWidth;
      const clientWidth = topicsSliderRef.current.clientWidth;
      setTopicsConstraints({ left: -(scrollWidth - clientWidth), right: 0 });
    }
  }, [topics.length]);

  /** Handlers */
  const handleTopicSelect = (topicId) => setSelectedTopicId(topicId);

  const handleStartQuiz = (quiz) => {
    setPendingQuiz(quiz);
    setShowQuizDialog(true);
  };

  const handleConfirmQuiz = () => {
    setSelectedQuiz(pendingQuiz);
    setShowQuiz(true);
    setShowQuizDialog(false);
    setPendingQuiz(null);
  };

  const handleCancelQuiz = () => {
    setShowQuizDialog(false);
    setPendingQuiz(null);
  };

  const handleQuizExit = () => {
    setShowQuiz(false);
    setSelectedQuiz(null);
  };

  const handleQuizSubmit = (results) => {
    navigate("/results", { state: { results, quiz: selectedQuiz } });
    setShowQuiz(false);
    setSelectedQuiz(null);
  };

  /** Animation Variants */
  const sliderItemVariants = {
    hidden: { x: -20, opacity: 0 },
    visible: { x: 0, opacity: 1 },
  };

  const cardVariants = {
    hidden: { scale: 0.9, opacity: 0 },
    visible: {
      scale: 1,
      opacity: 1,
      transition: { type: "spring", stiffness: 300, damping: 24 },
    },
    hover: {
      scale: 1.05,
      y: -5,
      transition: { type: "spring", stiffness: 400, damping: 17 },
    },
  };

  const dialogVariants = {
    hidden: { opacity: 0, scale: 0.8 },
    visible: { 
      opacity: 1, 
      scale: 1,
      transition: { type: "spring", stiffness: 300, damping: 30 }
    },
    exit: { 
      opacity: 0, 
      scale: 0.8,
      transition: { duration: 0.2 }
    }
  };

  const overlayVariants = {
    hidden: { opacity: 0 },
    visible: { opacity: 1 },
    exit: { opacity: 0 }
  };

  /** If quiz is active, show quiz test screen */
  if (showQuiz && selectedQuiz) {
    return (
      <QuizTest
        quiz={selectedQuiz}
        onExit={handleQuizExit}
        onSubmit={handleQuizSubmit}
      />
    );
  }
  console.log(pendingQuiz);
  
  return (
    <div className="min-h-screen bg-background py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <h1 className="text-4xl font-bold text-foreground text-center mb-6">Explore Topics</h1>

        {/* Topics Slider */}
        {topicsLoading ? (
          <div className="flex justify-center py-12">
            <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-primary"></div>
          </div>
        ) : (
          <motion.div
            ref={topicsSliderRef}
            className="relative overflow-x-auto scrollbar-hide mb-8"
            initial="hidden"
            animate="visible"
          >
            <motion.div
              className="flex space-x-4 pb-4"
              drag="x"
              dragConstraints={topicsConstraints}
              whileTap={{ cursor: "grabbing" }}
            >
              {topics.map((topic) => (
                <motion.button
                  key={topic.id}
                  className={`flex flex-col items-center p-4 rounded-2xl min-w-[200px] transition-all duration-300 ${
                    selectedTopicId === topic.id
                      ? "bg-gradient-to-r from-blue-500 to-purple-600 text-white shadow-lg"
                      : "bg-white text-gray-700 hover:bg-gray-50 shadow-md"
                  }`}
                  whileHover="hover"
                  onClick={() => handleTopicSelect(topic.id)}
                  variants={sliderItemVariants}
                >
                  <img
                    src={topic.imageUrl}
                    alt={topic.name}
                    className="w-16 h-16 rounded-xl object-cover mb-3"
                  />
                  <span className="font-semibold text-sm text-center mb-1">{topic.name}</span>
                  <span className="text-xs text-center opacity-80 line-clamp-2 w-60">
                    {topic.description}
                  </span>
                </motion.button>
              ))}
            </motion.div>
          </motion.div>
        )}

        {/* Quizzes Section */}
        <h2 className="text-xl font-bold text-gray-900 mb-4">
          {selectedTopicId
            ? `Quizzes for ${topics.find((t) => t.id === selectedTopicId)?.name || "Topic"}`
            : "Select a topic to view quizzes"}
        </h2>

        {quizzesLoading ? (
          <div className="flex justify-center py-12">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500"></div>
          </div>
        ) : quizzesData?.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {quizzesData.map((quiz) => (
              <motion.div
                key={quiz.id}
                className="bg-white rounded-xl shadow-md p-6 border border-gray-100"
                variants={cardVariants}
                initial="hidden"
                animate="visible"
                whileHover="hover"
              >
                <img
                  src={quiz.imageUrl}
                  alt={quiz.title}
                  className="rounded-xl h-48 object-cover w-full mb-4"
                />
                <div className="flex justify-between items-start gap-4 mb-4">
  <div className="flex-1 min-w-0">
    <h3 className="text-xl font-semibold text-gray-900 mb-2 leading-tight">
      {quiz.title}
    </h3>
    <p className="text-gray-600 text-sm leading-relaxed line-clamp-2">
      {quiz.description}
    </p>
    <p className=" px-4 py-2 rounded-xl bg-sky-300 w-fit text-gray-800 font-semibold mt-4">{quiz?.status}</p>
  </div>
  
  <div className="flex-shrink-0 bg-gradient-to-br from-blue-50 to-purple-50 rounded-xl p-4 border border-blue-100 min-w-[140px]">
    <div className="space-y-2 text-center">
      <div className="flex items-center justify-center gap-1">
        <svg className="w-4 h-4 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
        </svg>
        <span className="text-sm font-semibold text-blue-700">
          {quiz.questions.length} Qn
        </span>
      </div>
      
      <div className="flex items-center justify-center gap-1">
        <svg className="w-4 h-4 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
        </svg>
        <span className="text-sm font-medium text-gray-700">
          {quiz.timeLimit} min
        </span>
      </div>
      
      <div className="flex items-center justify-center gap-1">
        <svg className="w-4 h-4 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
        </svg>
        <span className="text-sm font-medium text-gray-700">
          {quiz.totalPoints} pts
        </span>
      </div>
    </div>
  </div>
</div>
                <button
                  onClick={() => handleStartQuiz(quiz)}
                  className="w-full px-6 py-3 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full text-white font-semibold shadow-lg hover:from-blue-600 hover:to-purple-700 transition-all duration-300"
                >
                  Start Quiz
                </button>
              </motion.div>
            ))}
          </div>
        ) : (
          <div className="text-center py-12 bg-white rounded-xl shadow-md">
            <p className="text-gray-500 text-lg">
              {selectedTopicId
                ? "No quizzes available for this topic."
                : "Please select a topic."}
            </p>
          </div>
        )}
      </div>

      {/* Quiz Confirmation Dialog */}
      {showQuizDialog && pendingQuiz && (
        <motion.div
          className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50"
          variants={overlayVariants}
          initial="hidden"
          animate="visible"
          exit="exit"
        >
          <motion.div
            className="bg-white rounded-2xl shadow-2xl max-w-md w-full p-6"
            variants={dialogVariants}
            initial="hidden"
            animate="visible"
            exit="exit"
          >
            <div className="text-center mb-6">
              <h2 className="text-2xl font-bold text-gray-900 mb-2">Start Quiz</h2>
              <p className="text-gray-600">Are you ready to begin this quiz?</p>
            </div>

            {/* Quiz Information */}
            <div className="bg-gray-50 rounded-xl p-4 mb-6">
              <div className="flex items-center mb-4">
                <img
                  src={pendingQuiz.imageUrl}
                  alt={pendingQuiz.title}
                  className="w-16 h-16 rounded-lg object-cover mr-4"
                />
                <div>
                  <h3 className="text-lg font-semibold text-gray-900">{pendingQuiz.title}</h3>
                  <p className="text-sm text-gray-600">{pendingQuiz.description}</p>
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div className="text-center p-3 bg-white rounded-lg">
                  <div className="font-semibold text-gray-900">{pendingQuiz.questions?.length || 0}</div>
                  <div className="text-gray-600">Questions</div>
                </div>
                <div className="text-center p-3 bg-white rounded-lg">
                  <div className="font-semibold text-gray-900">{pendingQuiz.totalPoints || 100}</div>
                  <div className="text-gray-600">Total Points</div>
                </div>
                <div className="text-center p-3 bg-white rounded-lg">
                  <div className="font-semibold text-gray-900">{pendingQuiz.timeLimit || 30}</div>
                  <div className="text-gray-600">Minutes</div>
                </div>
                <div className="text-center p-3 bg-white rounded-lg">
                  <div className="font-semibold text-gray-900">{pendingQuiz.creator?.name || "System"}</div>
                  <div className="text-gray-600">Creator</div>
                </div>
              </div>
            </div>

            {/* Warning Message */}
            <div className="bg-yellow-50 border border-yellow-200 rounded-xl p-4 mb-6">
              <div className="flex items-start">
                <div className="flex-shrink-0">
                  <svg className="w-5 h-5 text-yellow-600" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
                  </svg>
                </div>
                <div className="ml-3">
                  <h4 className="text-sm font-semibold text-yellow-800">Important Notes</h4>
                  <div className="mt-1 text-sm text-yellow-700">
                    <ul className="list-disc list-inside space-y-1">
                      <li>Make sure you have stable internet connection</li>
                      <li>Quiz cannot be paused once started</li>
                      <li>Answers are final and cannot be changed after submission</li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex space-x-3">
              <button
                onClick={handleCancelQuiz}
                className="flex-1 px-4 py-3 border border-gray-300 text-gray-700 font-semibold rounded-xl hover:bg-gray-50 transition-all duration-300"
              >
                Cancel
              </button>
              <button
                onClick={handleConfirmQuiz}
                className="flex-1 px-4 py-3 bg-gradient-to-r from-blue-500 to-purple-600 text-white font-semibold rounded-xl shadow-lg hover:from-blue-600 hover:to-purple-700 transition-all duration-300"
              >
                Start Quiz Now
              </button>
            </div>
          </motion.div>
        </motion.div>
      )}

      {/* Custom CSS */}
      <style jsx>{`
        .scrollbar-hide {
          -ms-overflow-style: none;
          scrollbar-width: none;
        }
        .scrollbar-hide::-webkit-scrollbar {
          display: none;
        }
        .line-clamp-2 {
          display: -webkit-box;
          -webkit-line-clamp: 2;
          -webkit-box-orient: vertical;
          overflow: hidden;
        }
      `}</style>
    </div>
  );
};

export default TopicsSlider;