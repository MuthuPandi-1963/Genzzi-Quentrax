import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  Menu, 
  X, 
  BookOpen, 
  Coins, 
  Activity, 
  Trophy, 
  Star, 
  ChevronRight,
  Award,
  Users,
  TrendingUp,
  CheckCircle
} from 'lucide-react';
import { 
  FaTwitter, 
  FaFacebook, 
  FaInstagram, 
  FaLinkedin,
  FaUserFriends
} from 'react-icons/fa';
import { Link, Outlet, useLocation } from 'react-router-dom';
import RoleNavbar from '../../components/custom/RoleNavbar';


// Animation variants
const fadeIn = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.5 } }
};

const staggerContainer = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.2
    }
  }
};

// Navbar Component


// Feature Card Component
const FeatureCard = ({ icon, title, description, delay }) => (
  <motion.div
    variants={fadeIn}
    initial="hidden"
    whileInView="visible"
    viewport={{ once: true }}
    transition={{ delay }}
    className="bg-card rounded-2xl shadow-sm p-6 hover:shadow-md transition-shadow duration-300"
  >
    <div className="flex justify-center">
      <div className="flex items-center justify-center h-12 w-12 rounded-md bg-primary/20 text-primary">
        {icon}
      </div>
    </div>
    <h3 className="mt-4 text-lg font-medium text-foreground text-center">{title}</h3>
    <p className="mt-2 text-muted-foreground text-center">{description}</p>
  </motion.div>
);

// Leaderboard Card Component
const LeaderboardCard = ({ rank, name, coins, avatarColor }) => (
  <motion.div 
    variants={fadeIn}
    initial="hidden"
    whileInView="visible"
    viewport={{ once: true }}
    className="bg-card rounded-2xl shadow-sm p-6 flex items-center space-x-4"
  >
    <div className={`flex-shrink-0 h-12 w-12 rounded-full flex items-center justify-center text-white ${avatarColor}`}>
      {rank}
    </div>
    <div className="flex-1 min-w-0">
      <p className="text-sm font-medium text-foreground truncate">{name}</p>
      <p className="text-sm text-muted-foreground truncate">{coins} coins</p>
    </div>
    <div className="flex items-center text-accent">
      <Coins className="h-5 w-5" />
    </div>
  </motion.div>
);

// Testimonial Card Component
const TestimonialCard = ({ name, role, content, rating, avatarColor }) => (
  <motion.div
    variants={fadeIn}
    initial="hidden"
    whileInView="visible"
    viewport={{ once: true }}
    className="bg-card rounded-2xl shadow-sm p-6"
  >
    <div className="flex items-center mb-4">
      <div className={`flex-shrink-0 h-10 w-10 rounded-full flex items-center justify-center text-white ${avatarColor}`}>
        {name.charAt(0)}
      </div>
      <div className="ml-3">
        <p className="text-sm font-medium text-foreground">{name}</p>
        <p className="text-sm text-muted-foreground">{role}</p>
      </div>
    </div>
    <div className="flex items-center mb-3">
      {[...Array(5)].map((_, i) => (
        <Star 
          key={i} 
          className={`h-4 w-4 ${i < rating ? 'text-accent fill-accent' : 'text-muted-foreground'}`} 
        />
      ))}
    </div>
    <p className="text-muted-foreground italic">"{content}"</p>
  </motion.div>
);

// Step Component for How It Works
const Step = ({ number, title, description, icon, isLast }) => (
  <div className="flex flex-col md:flex-row items-center">
    <div className="flex flex-col items-center">
      <div className="flex items-center justify-center h-12 w-12 rounded-full bg-primary/20 text-primary text-lg font-bold">
        {number}
      </div>
      <div className="h-16 w-1 bg-primary/20 my-2 md:h-1 md:w-16 md:my-0"></div>
    </div>
    <div className="md:ml-4 text-center md:text-left flex-1">
      <div className="flex justify-center md:justify-start text-primary mb-2">
        {icon}
      </div>
      <h3 className="text-lg font-medium text-foreground">{title}</h3>
      <p className="mt-2 text-muted-foreground">{description}</p>
    </div>
    {!isLast && (
      <div className="hidden md:flex items-center mx-4">
        <ChevronRight className="h-6 w-6 text-muted-foreground" />
      </div>
    )}
  </div>
);

// Footer Component
const Footer = () => (
  <footer className="bg-secondary text-foreground">
    <div className="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
      <div className="flex flex-col md:flex-row justify-between items-center">
        <div className="flex items-center mb-6 md:mb-0">
          <Award className="h-8 w-8 text-primary" />
          <span className="ml-2 text-xl font-bold">Quentrax</span>
        </div>
        <div className="flex space-x-6 mb-6 md:mb-0">
          <a href="#" className="text-muted-foreground hover:text-foreground">Privacy Policy</a>
          <a href="#" className="text-muted-foreground hover:text-foreground">Terms of Service</a>
          <a href="#" className="text-muted-foreground hover:text-foreground">Contact Us</a>
        </div>
        <div className="flex space-x-4">
          <a href="#" className="text-muted-foreground hover:text-foreground">
            <FaTwitter className="h-6 w-6" />
          </a>
          <a href="#" className="text-muted-foreground hover:text-foreground">
            <FaFacebook className="h-6 w-6" />
          </a>
          <a href="#" className="text-muted-foreground hover:text-foreground">
            <FaInstagram className="h-6 w-6" />
          </a>
          <a href="#" className="text-muted-foreground hover:text-foreground">
            <FaLinkedin className="h-6 w-6" />
          </a>
        </div>
      </div>
      <div className="mt-8 text-center text-muted-foreground text-sm">
        <p>© {new Date().getFullYear()} quentrax. All rights reserved.</p>
      </div>
    </div>
  </footer>
);

export const MainPage = ()=>{
  const features = [
    {
      icon: <BookOpen className="h-6 w-6" />,
      title: "Categories & Topics",
      description: "Explore hundreds of quizzes across diverse categories and topics."
    },
    {
      icon: <Coins className="h-6 w-6" />,
      title: "Earn Coins & Rewards",
      description: "Answer correctly to earn coins and unlock special rewards."
    },
    {
      icon: <Activity className="h-6 w-6" />,
      title: "Track Progress",
      description: "Monitor your learning journey with detailed analytics and insights."
    },
    {
      icon: <Trophy className="h-6 w-6" />,
      title: "Compete with Friends",
      description: "Challenge friends and climb the leaderboards together."
    }
  ];

  const leaderboardData = [
    { rank: 1, name: "Alex Johnson", coins: 2450, avatarColor: "bg-yellow-500" },
    { rank: 2, name: "Sarah Miller", coins: 2120, avatarColor: "bg-gray-400" },
    { rank: 3, name: "Michael Chen", coins: 1980, avatarColor: "bg-yellow-700" }
  ];

  const steps = [
    {
      number: 1,
      title: "Choose a Category",
      description: "Select from our wide range of topics that interest you the most.",
      icon: <BookOpen className="h-6 w-6" />
    },
    {
      number: 2,
      title: "Take Quizzes",
      description: "Test your knowledge with fun, interactive quizzes of varying difficulty.",
      icon: <TrendingUp className="h-6 w-6" />
    },
    {
      number: 3,
      title: "Earn Coins & Rank Up",
      description: "Earn rewards for correct answers and watch your rank improve over time.",
      icon: <Trophy className="h-6 w-6" />
    }
  ];

  const testimonials = [
    {
      name: "Emily Rodriguez",
      role: "College Student",
content: "Quentrax makes studying for my exams feel futuristic and premium. I love competing with my friends!", 
      rating: 5,
      avatarColor: "bg-pink-500"
    },
    {
      name: "David Kim",
      role: "Teacher",
content: "I use Quentrax with my students and their test scores improve significantly. Highly recommend!", 
      rating: 5,
      avatarColor: "bg-blue-500"
    },
    {
      name: "Jessica Taylor",
      role: "Lifelong Learner",
      content: "The variety of topics keeps me coming back. I've learned so much while having fun!",
      rating: 4,
      avatarColor: "bg-green-500"
    }
  ];
  return (
    <main className="">
        <section className=" mx-auto px-4 sm:px-6 lg:px-8 md:pt-10 pb-16 text-center md:flex grid bg-card">
        
          <div className="self-center order-1 md:order-1 ">
            <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7 }}
            className="max-w-3xl mx-auto"
          >
            <h1 className="text-4xl sm:text-5xl font-extrabold text-foreground">
              Master Your Skills With <span className="text-primary">Fun Quizzes!</span>
            </h1>
            <p className="mt-4 text-xl text-muted-foreground">
              Interactive quizzes, track your progress, earn coins, and compete with others.
            </p>
            <div className="mt-10 flex flex-col sm:flex-row justify-center gap-3">
              <a
                href="#"
                className="px-6 py-3 border border-transparent text-base font-medium rounded-md shadow-sm text-white bg-primary hover:bg-primary/90 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary"
              >
                Start Now
              </a>
              <a
                href="#"
                className="px-6 py-3 border border-border text-base font-medium rounded-md text-foreground bg-card hover:bg-muted focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary"
              >
                View Categories
              </a>
            </div>
          </motion.div>
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.7, delay: 0.3 }}
            className="mt-12 flex justify-center"
          >
            <div className="bg-card rounded-2xl shadow-lg p-6 max-w-4xl mx-auto">
              <div className="flex flex-wrap justify-center gap-6">
                <div className="flex items-center justify-center h-16 w-16 rounded-lg bg-primary/20 text-primary">
                  <BookOpen className="h-8 w-8" />
                </div>
                <div className="flex items-center justify-center h-16 w-16 rounded-lg bg-accent/20 text-accent">
                  <Coins className="h-8 w-8" />
                </div>
                <div className="flex items-center justify-center h-16 w-16 rounded-lg bg-chart-2/20 text-chart-2">
                  <Activity className="h-8 w-8" />
                </div>
                <div className="flex items-center justify-center h-16 w-16 rounded-lg bg-destructive/20 text-destructive">
                  <Trophy className="h-8 w-8" />
                </div>
                <div className="flex items-center justify-center h-16 w-16 rounded-lg bg-chart-4/20 text-chart-4">
                  <FaUserFriends className="h-8 w-8" />
                </div>
              </div>
            </div>
          </motion.div>
          </div>
            <div className="">
            <img src="https://i.pinimg.com/1200x/29/92/72/299272600f6458cf34a1331199675f16.jpg" alt="" />
          </div>
        </section>

        {/* Features Section */}
        <section className="py-16 bg-background">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              variants={fadeIn}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
              className="text-center"
            >
      <h2 className="text-3xl font-extrabold text-foreground">Why Choose Quentrax?</h2>
              <p className="mt-4 max-w-2xl mx-auto text-muted-foreground">
                Our platform offers everything you need to make learning engaging and effective.
              </p>
            </motion.div>
            <motion.div
              variants={staggerContainer}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
              className="mt-12 grid gap-6 md:grid-cols-2 lg:grid-cols-4"
            >
              {features.map((feature, index) => (
                <FeatureCard
                  key={index}
                  icon={feature.icon}
                  title={feature.title}
                  description={feature.description}
                  delay={index * 0.1}
                />
              ))}
            </motion.div>
          </div>
        </section>

        {/* Leaderboard Preview */}
        <section className="py-16 bg-background">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              variants={fadeIn}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
              className="text-center"
            >
              <h2 className="text-3xl font-extrabold text-foreground">Top Learners</h2>
              <p className="mt-4 max-w-2xl mx-auto text-muted-foreground">
                See who's leading the pack this week and get inspired to climb the ranks!
              </p>
            </motion.div>
            <motion.div
              variants={staggerContainer}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
              className="mt-12 max-w-md mx-auto grid gap-6 lg:grid-cols-3 lg:max-w-full"
            >
              {leaderboardData.map((player, index) => (
                <LeaderboardCard
                  key={index}
                  rank={player.rank}
                  name={player.name}
                  coins={player.coins}
                  avatarColor={player.avatarColor}
                />
              ))}
            </motion.div>
            <motion.div
              variants={fadeIn}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
              className="mt-10 text-center"
            >
              <a href="#" className="text-primary hover:text-primary/80 font-medium">
                View full leaderboard <span aria-hidden="true">&rarr;</span>
              </a>
            </motion.div>
          </div>
        </section>

        {/* How It Works Section */}
        <section className="py-16 bg-card">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              variants={fadeIn}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
              className="text-center"
            >
<h2 className="text-3xl font-extrabold text-foreground">How Quentrax Works</h2>
              <p className="mt-4 max-w-2xl mx-auto text-muted-foreground">
                Getting started is easy! Follow these simple steps to begin your learning journey.
              </p>
            </motion.div>
            <motion.div
              variants={staggerContainer}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
              className="mt-12 grid gap-8 md:grid-cols-3"
            >
              {steps.map((step, index) => (
                <Step
                  key={index}
                  number={step.number}
                  title={step.title}
                  description={step.description}
                  icon={step.icon}
                  isLast={index === steps.length - 1}
                />
              ))}
            </motion.div>
          </div>
        </section>

        {/* Testimonials Section */}
        <section className="py-16 bg-background">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              variants={fadeIn}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
              className="text-center"
            >
              <h2 className="text-3xl font-extrabold text-foreground">What Our Users Say</h2>
              <p className="mt-4 max-w-2xl mx-auto text-muted-foreground">
                Don't just take our word for it. Here's what our community has to say about QuizPro.
              </p>
            </motion.div>
            <motion.div
              variants={staggerContainer}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
              className="mt-12 grid gap-8 md:grid-cols-3"
            >
              {testimonials.map((testimonial, index) => (
                <TestimonialCard
                  key={index}
                  name={testimonial.name}
                  role={testimonial.role}
                  content={testimonial.content}
                  rating={testimonial.rating}
                  avatarColor={testimonial.avatarColor}
                />
              ))}
            </motion.div>
          </div>
        </section>

        {/* CTA Section */}
        {/* <section className="py-16 bg-indigo-700">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <motion.div
              variants={fadeIn}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
            >
              <h2 className="text-3xl font-extrabold text-white sm:text-4xl">
                Start Your Learning Journey Today!
              </h2>
              <p className="mt-4 text-lg text-indigo-200">
                Join thousands of learners who are already expanding their knowledge with QuizPro.
              </p>
              <div className="mt-8">
                <a
                  href="#"
                  className="px-6 py-3 border border-transparent text-base font-medium rounded-md shadow-sm text-indigo-700 bg-white hover:bg-indigo-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-white"
                >
                  Sign Up Now
                </a>
              </div>
            </motion.div>
          </div>
        </section> */}
      </main>
  )
}

// Main Landing Page Component
const LandingPage = () => {
  const location = useLocation();
  const isAdminArea = location.pathname.startsWith("/admin");

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {!isAdminArea && <RoleNavbar />}
      {/* Hero Section */}
      <div className="md:pt-16 pt-10 flex-1">
        <Outlet />
      </div>
      {!isAdminArea && <Footer />}
    </div>
  );
};


export default LandingPage;