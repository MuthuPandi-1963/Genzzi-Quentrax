import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { 
  User, 
  Edit, 
  BookOpen, 
  Coins, 
  Trophy, 
  Calendar,
  Award,
  BarChart3,
  Settings,
  Mail,
  Globe,
  CheckCircle,
  X,
  Camera
} from 'lucide-react';
import { useParams, useNavigate } from 'react-router-dom';
import { useSelector } from 'react-redux';
import { getUsersById, useAuth } from '../../hooks/useAuth';
import {Button} from '../../components/ui/button'
// Animation variants
const fadeIn = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.5 } }
};

const staggerContainer = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1
    }
  }
};

// Profile Stats Card
const StatCard = ({ icon, label, value, color = "primary" }) => (
  <motion.div
    variants={fadeIn}
    className={`bg-card rounded-2xl shadow-sm p-6 border-l-4 border-primary`}
  >
    <div className="flex items-center justify-between">
      <div>
        <p className="text-sm font-medium text-muted-foreground">{label}</p>
        <p className="text-2xl font-bold text-foreground mt-1">{value}</p>
      </div>
      <div className={`p-3 rounded-full bg-primary/20 text-primary`}>
        {icon}
      </div>
    </div>
  </motion.div>
);

// Quiz History Item
const QuizHistoryItem = ({ quiz, score, completedAt }) => (
  <motion.div
    variants={fadeIn}
    className="bg-card rounded-xl shadow-sm p-4 hover:shadow-md transition-shadow duration-300"
  >
    <div className="flex items-center justify-between">
      <div className="flex-1">
        <h4 className="font-medium text-foreground">{quiz?.title}</h4>
        <p className="text-sm text-muted-foreground mt-1">{quiz?.description}</p>
        <div className="flex items-center mt-2 space-x-4">
          <div className="flex items-center text-sm text-muted-foreground">
            <Trophy className="h-4 w-4 mr-1 text-accent" />
            Score: {score}
          </div>
          <div className="flex items-center text-sm text-muted-foreground">
            <Calendar className="h-4 w-4 mr-1" />
            {new Date(completedAt).toLocaleDateString()}
          </div>
        </div>
      </div>
      <div className="ml-4">
        <div className={`px-3 py-1 rounded-full text-sm font-medium ${
          score >= 80 ? 'bg-chart-2/20 text-chart-2' : 
          score >= 60 ? 'bg-accent/20 text-accent' : 
          'bg-destructive/20 text-destructive'
        }`}>
          {score}%
        </div>
      </div>
    </div>
  </motion.div>
);

// Created Quiz Item
const CreatedQuizItem = ({ quiz }) => (
  <motion.div
    variants={fadeIn}
    className="bg-card rounded-xl shadow-sm p-4 hover:shadow-md transition-shadow duration-300"
  >
    <div className="flex items-center justify-between">
      <div className="flex-1">
        <h4 className="font-medium text-foreground">{quiz?.title}</h4>
        <p className="text-sm text-muted-foreground mt-1">{quiz?.description}</p>
        <div className="flex items-center mt-2 space-x-4">
          <div className="flex items-center text-sm text-muted-foreground">
            <BookOpen className="h-4 w-4 mr-1" />
            {quiz?.questions?.length || 0} questions
          </div>
          <div className="flex items-center text-sm text-muted-foreground">
            <BarChart3 className="h-4 w-4 mr-1" />
            {quiz?.history?.length || 0} attempts
          </div>
          <div className="flex items-center text-sm text-muted-foreground">
            <Coins className="h-4 w-4 mr-1 text-accent" />
            {quiz?.totalPoints} points
          </div>
        </div>
      </div>
      <div className="ml-4">
        <span className={`px-3 py-1 rounded-full text-sm font-medium ${
          quiz?.status === 'active' ? 'bg-chart-2/20 text-chart-2' : 'bg-muted text-muted-foreground'
        }`}>
          {quiz?.status}
        </span>
      </div>
    </div>
  </motion.div>
);

// Edit Profile Modal
const EditProfileModal = ({ user, isOpen, onClose, onSave }) => {
  const [formData, setFormData] = useState({
    name: user?.name || '',
    email: user?.email || '',
    bio: user?.bio || '',
    countryId: user?.countryId || ''
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    onSave(formData);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="bg-card rounded-2xl shadow-xl max-w-md w-full"
      >
        {/* <div className="flex items-center justify-between p-6 border-b">
          <h3 className="text-lg font-semibold text-foreground">Edit Profile</h3>
          <button onClick={onClose} className="text-muted-foreground hover:text-foreground">
            <X className="h-6 w-6" />
          </button>
        </div> */}
        
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div>
            <label className="block text-sm font-medium text-foreground mb-2">
              Name
            </label>
            <input
              type="text"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              className="w-full px-3 py-2 border border-border rounded-lg focus:ring-2 focus:ring-primary focus:border-primary bg-background text-foreground"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-foreground mb-2">
              Email
            </label>
            <input
              type="email"
              value={formData.email}
              onChange={(e) => setFormData({ ...formData, email: e.target.value })}
              className="w-full px-3 py-2 border border-border rounded-lg focus:ring-2 focus:ring-primary focus:border-primary bg-background text-foreground"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-foreground mb-2">
              Bio
            </label>
            <textarea
              value={formData.bio}
              onChange={(e) => setFormData({ ...formData, bio: e.target.value })}
              rows="3"
              className="w-full px-3 py-2 border border-border rounded-lg focus:ring-2 focus:ring-primary focus:border-primary bg-background text-foreground"
              placeholder="Tell us about yourself..."
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-foreground mb-2">
              Country
            </label>
            <input
              type="text"
              value={formData.countryId}
              onChange={(e) => setFormData({ ...formData, countryId: e.target.value })}
              className="w-full px-3 py-2 border border-border rounded-lg focus:ring-2 focus:ring-primary focus:border-primary bg-background text-foreground"
              placeholder="Your country"
            />
          </div>
          
          <div className="flex justify-end space-x-3 pt-4">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-sm font-medium text-foreground bg-card border border-border rounded-lg hover:bg-muted"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 text-sm font-medium text-white bg-primary rounded-lg hover:bg-primary/90"
            >
              Save Changes
            </button>
          </div>
        </form>
      </motion.div>
    </div>
  );
};

const ProfilePage = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('overview');
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const {user:u} = useSelector((state) => state.user);
  const {data ,isLoading} = getUsersById(u?.id || "")
  const {useLogout} = useAuth(); 
  // Mock data - replace with actual API call
  useEffect(() => {
        setUser(data?.user);
  }, [isLoading]);

  const handleLogout = async () => {
    try {
      await useLogout.mutateAsync();
      // Clear any user-related state here if needed
      navigate('/login');
      window.location.reload()
    } catch (error) {
      console.error('Logout failed:', error);
    }
  }
  const handleSaveProfile = (updatedData) => {
    // In a real app, you would make an API call here
    setUser(prev => ({ ...prev, ...updatedData }));
    setIsEditModalOpen(false);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  const tabs = [
    { id: 'overview', label: 'Overview', icon: <BarChart3 className="h-4 w-4" /> },
    { id: 'quizzes', label: 'My Quizzes', icon: <BookOpen className="h-4 w-4" /> },
    { id: 'history', label: 'Quiz History', icon: <Award className="h-4 w-4" /> },
    // { id: 'coins', label: 'Coins History', icon: <Coins className="h-4 w-4" /> },
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="bg-card shadow-sm border-b border-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-6">
            <div>
              <h1 className="text-2xl font-bold text-foreground">Profile</h1>
              <p className="text-muted-foreground mt-1">Manage your account and track your progress</p>
            </div>
            <button
              onClick={() => setIsEditModalOpen(true)}
              className="flex items-center px-4 py-2 text-sm font-medium text-primary bg-background border border-primary rounded-lg hover:bg-primary/10"
            >
              <Edit className="h-4 w-4 mr-2" />
              Edit Profile
            </button>
          </div>
        </div>
      </div>

      {user && <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Sidebar */}
          <div className="lg:col-span-1">
            <motion.div
              variants={fadeIn}
              className="bg-card rounded-2xl shadow-sm p-6 sticky top-8"
            >
              {/* Profile Summary */}
              <div className="text-center mb-6">
                <div className="relative inline-block">
                  <div className="h-24 w-24 rounded-full bg-primary/20 flex items-center justify-center mx-auto mb-4">
                    {user?.avatar ? (
                      <img 
                        src={user.avatar} 
                        alt={user.name}
                        className="h-24 w-24 rounded-full object-cover"
                      />
                    ) : (
                      <User className="h-12 w-12 text-primary" />
                    )}
                  </div>
                  <button className="absolute bottom-2 right-2 p-1 bg-primary text-white rounded-full hover:bg-primary/90">
                    <Camera className="h-3 w-3" />
                  </button>
                </div>
                <h2 className="text-xl font-bold text-foreground">{user.name}</h2>
                <div className="flex items-center justify-center mt-1 space-x-2">
                  <span className="text-sm text-muted-foreground capitalize">{user.role.toLowerCase()}</span>
                  {user.isVerified && (
                    <CheckCircle className="h-4 w-4 text-chart-2" />
                  )}
                </div>
                <p className="text-sm text-muted-foreground mt-2">{user.bio}</p>
              </div>

              {/* User Info */}
              <div className="space-y-3 border-t border-border pt-6">
                <div className="flex items-center text-sm text-muted-foreground">
                  <Mail className="h-4 w-4 mr-3 text-muted-foreground/50" />
                  {user?.email}
                </div>
                {user.countryId && (
                  <div className="flex items-center text-sm text-muted-foreground">
                    <Globe className="h-4 w-4 mr-3 text-muted-foreground/50" />
                    {user?.countryId}
                  </div>
                )}
                <div className="flex items-center text-sm text-muted-foreground">
                  <Calendar className="h-4 w-4 mr-3 text-muted-foreground/50" />
                  Joined {new Date(user?.createdAt).toLocaleDateString()}
                </div>
              </div>

              {/* Coins Balance */}
              <div className="mt-6 p-4 bg-accent/10 rounded-lg border border-accent/20">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium text-accent">Coin Balance</span>
                  <Coins className="h-4 w-4 text-accent" />
                </div>
                <p className="text-2xl font-bold text-accent mt-1">
                  {user.coins?.balance.toLocaleString()}
                </p>
              </div>
            <div className="">
              <Button variant="destructive" onClick={handleLogout} className='w-full my-4'>Logout</Button>
            </div>
            </motion.div>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-3">
            {/* Tabs */}
            <motion.div
              variants={fadeIn}
              className="bg-card rounded-2xl shadow-sm mb-6"
            >
              <div className="border-b border-border">
                <nav className="flex space-x-8 px-6">
                  {tabs.map((tab) => (
                    <button
                      key={tab.id}
                      onClick={() => setActiveTab(tab.id)}
                      className={`flex items-center py-4 px-1 border-b-2 font-medium text-sm ${
                        activeTab === tab.id
                          ? 'border-primary text-primary'
                          : 'border-transparent text-muted-foreground hover:text-foreground hover:border-border'
                      }`}
                    >
                      {tab.icon}
                      <span className="ml-2">{tab.label}</span>
                    </button>
                  ))}
                </nav>
              </div>
            </motion.div>

            {/* Tab Content */}
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3 }}
            >
              {activeTab === 'overview' && (
                <div className="space-y-6">
                  {/* Stats Grid */}
                  <motion.div
                    variants={staggerContainer}
                    initial="hidden"
                    animate="visible"
                    className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
                  >
                    <StatCard
                      icon={<BookOpen className="h-6 w-6" />}
                      label="Quizzes Created"
                      value={user.createdQuizzes?.length || 0}
                      color="blue"
                    />
                    <StatCard
                      icon={<Award className="h-6 w-6" />}
                      label="Quizzes Taken"
                      value={user.quizHistory?.length || 0}
                      color="green"
                    />
                    <StatCard
                      icon={<Trophy className="h-6 w-6" />}
                      label="Average Score"
                      value={`${Math.round(
                        user.quizHistory?.reduce((acc, curr) => acc + curr.score, 0) / 
                        (user.quizHistory?.length || 1)
                      )}%`}
                      color="purple"
                    />
                  </motion.div>

                  {/* Recent Activity */}
                  <motion.div variants={fadeIn} className="bg-white rounded-2xl shadow-sm p-6">
                    <h3 className="text-lg font-semibold text-gray-900 mb-4">Recent Activity</h3>
                    <div className="space-y-4">
                      {user.quizHistory?.slice(0, 3).map((history, index) => (
                        <QuizHistoryItem key={history.id} {...history} score={history.score*7}  />
                      ))}
                    </div>
                  </motion.div>
                </div>
              )}

              {activeTab === 'quizzes' && (
                <motion.div
                  variants={staggerContainer}
                  initial="hidden"
                  animate="visible"
                  className="space-y-4"
                >
                  {user.createdQuizzes?.map((quiz) => (
                    <CreatedQuizItem key={quiz.id} quiz={quiz} />
                  ))}
                  {(!user.createdQuizzes || user.createdQuizzes.length === 0) && (
                    <div className="text-center py-12 bg-white rounded-2xl shadow-sm">
                      <BookOpen className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                      <h3 className="text-lg font-medium text-gray-900 mb-2">No quizzes created yet</h3>
                      <p className="text-gray-500 mb-4">Start creating your first quiz to share with others!</p>
                      <button className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700">
                        Create Quiz
                      </button>
                    </div>
                  )}
                </motion.div>
              )}

              {activeTab === 'history' && (
                <motion.div
                  variants={staggerContainer}
                  initial="hidden"
                  animate="visible"
                  className="space-y-4"
                >
                  {user.quizHistory?.map((history) => (
                    <QuizHistoryItem key={history.id} {...history} score={history.score*7}/>
                  ))}
                  {(!user.quizHistory || user.quizHistory.length === 0) && (
                    <div className="text-center py-12 bg-white rounded-2xl shadow-sm">
                      <Award className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                      <h3 className="text-lg font-medium text-gray-900 mb-2">No quiz history yet</h3>
                      <p className="text-gray-500">Take your first quiz to start tracking your progress!</p>
                    </div>
                  )}
                </motion.div>
              )}

              {activeTab === 'coins' && (
                <motion.div
                  variants={staggerContainer}
                  initial="hidden"
                  animate="visible"
                  className="bg-white rounded-2xl shadow-sm overflow-hidden"
                >
                  <div className="px-6 py-4 border-b border-gray-200">
                    <h3 className="text-lg font-semibold text-gray-900">Coins History</h3>
                  </div>
                  <div className="divide-y divide-gray-200">
                    {user.coinsHistory?.map((transaction) => (
                      <motion.div
                        key={transaction.id}
                        variants={fadeIn}
                        className="px-6 py-4 flex items-center justify-between hover:bg-gray-50"
                      >
                        <div>
                          <p className="font-medium text-gray-900">{transaction.reason}</p>
                          <p className="text-sm text-gray-500">
                            {new Date(transaction.createdAt).toLocaleDateString()}
                          </p>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Coins className="h-4 w-4 text-yellow-500" />
                          <span className={`font-medium ${
                            transaction.coins > 0 ? 'text-green-600' : 'text-red-600'
                          }`}>
                            {transaction.coins > 0 ? '+' : ''}{transaction.coins}
                          </span>
                        </div>
                      </motion.div>
                    ))}
                    {(!user.coinsHistory || user.coinsHistory.length === 0) && (
                      <div className="text-center py-12">
                        <Coins className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                        <h3 className="text-lg font-medium text-gray-900 mb-2">No coin transactions yet</h3>
                        <p className="text-gray-500">Complete quizzes to start earning coins!</p>
                      </div>
                    )}
                  </div>
                </motion.div>
              )}
            </motion.div>
          </div>
        </div>
      </div>}

      {/* Edit Profile Modal */}
      <EditProfileModal
        user={user}
        isOpen={isEditModalOpen}
        onClose={() => setIsEditModalOpen(false)}
        onSave={handleSaveProfile}
      />
    </div>
  );
};

export default ProfilePage;