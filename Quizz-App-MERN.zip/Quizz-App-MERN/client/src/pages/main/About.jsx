import React from 'react';
import { motion } from 'framer-motion';
import { Users, Award, Activity, Trophy, Star } from 'lucide-react';

// Animation variants
const fadeIn = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.5 } }
};

const staggerContainer = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.2 }
  }
};

// Team Member Card
const TeamCard = ({ name, role, avatarColor }) => (
  <motion.div
    variants={fadeIn}
    initial="hidden"
    whileInView="visible"
    viewport={{ once: true }}
    className="bg-card rounded-2xl shadow-sm p-6 text-center"
  >
    <div className={`h-20 w-20 rounded-full flex items-center justify-center mx-auto text-white text-2xl font-bold ${avatarColor}`}>
      {name.charAt(0)}
    </div>
    <h3 className="mt-4 text-lg font-medium text-foreground">{name}</h3>
    <p className="text-muted-foreground">{role}</p>
  </motion.div>
);

export const AboutUsPage = () => {
  const teamMembers = [
    { name: 'Alice Johnson', role: 'Founder & CEO', avatarColor: 'bg-indigo-500' },
    { name: 'Brian Smith', role: 'Lead Developer', avatarColor: 'bg-green-500' },
    { name: 'Carla Ruiz', role: 'UX Designer', avatarColor: 'bg-yellow-500' },
    { name: 'David Kim', role: 'Marketing Head', avatarColor: 'bg-red-500' },
  ];

  const values = [
    {
      icon: <Award className="h-6 w-6" />,
      title: 'Excellence',
      description: 'We strive for the highest quality in every quiz and learning tool we create.'
    },
    {
      icon: <Users className="h-6 w-6" />,
      title: 'Community',
      description: 'Building a supportive, engaging community of learners is at our core.'
    },
    {
      icon: <Activity className="h-6 w-6" />,
      title: 'Growth',
      description: 'We empower learners to track their progress and achieve personal growth.'
    },
    {
      icon: <Trophy className="h-6 w-6" />,
      title: 'Achievement',
      description: 'Rewarding effort and progress motivates our users to aim higher every day.'
    }
  ];

  return (
    <main className="bg-background min-h-screen">
      {/* Hero Section */}
      <section className="bg-card py-16 text-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7 }}
          className="max-w-3xl mx-auto"
        >
          <h1 className="text-4xl sm:text-5xl font-extrabold text-foreground">
            About <span className="text-primary">Quentrax</span>
          </h1>
          <p className="mt-4 text-xl text-muted-foreground">
            Our mission is to make assessment creation engaging, intelligent, and enterprise-ready. From smart quizzes to performance tracking, Quentrax is designed to help teams evaluate with confidence.
          </p>
        </motion.div>
      </section>

      {/* Our Values Section */}
      <section className="py-16 bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            variants={staggerContainer}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            className="grid gap-8 md:grid-cols-4"
          >
            {values.map((value, index) => (
              <motion.div
                key={index}
                variants={fadeIn}
                className="bg-card rounded-2xl shadow-sm p-6 text-center"
              >
                <div className="flex items-center justify-center h-12 w-12 rounded-md bg-primary/20 text-primary mx-auto">
                  {value.icon}
                </div>
                <h3 className="mt-4 text-lg font-medium text-foreground">{value.title}</h3>
                <p className="mt-2 text-muted-foreground">{value.description}</p>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Team Section */}
      <section className="py-16 bg-card">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
          >
            <h2 className="text-3xl font-extrabold text-foreground">Meet Our Team</h2>
            <p className="mt-4 text-muted-foreground max-w-2xl mx-auto">
              A passionate team committed to transforming learning into an engaging and rewarding experience.
            </p>
          </motion.div>
          <motion.div
            variants={staggerContainer}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            className="mt-12 grid gap-8 md:grid-cols-4"
          >
            {teamMembers.map((member, index) => (
              <TeamCard
                key={index}
                name={member.name}
                role={member.role}
                avatarColor={member.avatarColor}
              />
            ))}
          </motion.div>
        </div>
      </section>

      {/* Our Story Section */}
      <section className="py-16 bg-card">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
          >
            <h2 className="text-3xl font-extrabold text-foreground">Our Story</h2>
            <p className="mt-4 text-muted-foreground text-lg">
              Quentrax started with a simple idea: evaluation should be exciting, intelligent, and measurable. We combine assessment workflows, performance analytics, and candidate insights to help organizations achieve better outcomes.
            </p>
            <p className="mt-4 text-muted-foreground text-lg">
              From our humble beginnings to a thriving platform with thousands of active users, we continue to innovate and expand the way people learn.
            </p>
          </motion.div>
        </div>
      </section>
    </main>
  );
};

export default AboutUsPage;
