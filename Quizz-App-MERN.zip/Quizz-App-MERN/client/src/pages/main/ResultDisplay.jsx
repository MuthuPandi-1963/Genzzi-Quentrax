import React, { useEffect } from "react";
import { useSelector } from "react-redux";
import { useLocation, useNavigate } from "react-router-dom";
import { useQuizHistory } from "../../hooks/useQuizHistory";

const ResultsDisplay = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const { user } = useSelector((state) => state.user);
    const { createQuiz } = useQuizHistory();
  const { results, quiz } = location.state || {};

  // Redirect if results are missing
  useEffect(() => {
    if (!results || !quiz) navigate("/topics");
  }, [results, quiz, navigate]);

  if (!results || !quiz) return null;

  // Filter correct answers once
  const correctAnswersData = results.filter((r) => r.isCorrect);
  const correctAnswers = correctAnswersData.length;

  // Calculate total score
  const yourScore = quiz.questions.reduce(
    (prev, curr) =>
      prev + (correctAnswersData.some((val) => val.questionId === curr.id) ? curr.points : 0),
    0
  );

  const percentage = ((correctAnswers / results.length) * 100).toFixed(2);
  const scoreColor =
    percentage >= 80 ? "text-green-600" : percentage >= 60 ? "text-yellow-600" : "text-red-600";

  // Save quiz attempt
  useEffect(() => {
    createQuiz.mutate({
      userId: user.id,
      quizId: quiz.id,
      answers: results,
      score: yourScore,
    });
  }, [user.id, quiz.id, results, yourScore]);

  // Format date utility
  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString("en-US", {
      year: "numeric",
      month: "long",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background to-card py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto">
        {/* Main Results Card */}
        <div className="bg-card rounded-2xl shadow-xl overflow-hidden mb-8">
          {/* Header Section */}
          <div className="bg-gradient-to-r from-primary to-primary/80 p-6 text-foreground">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
              <div>
                <h1 className="text-3xl font-bold mb-2 text-white">{quiz.title}</h1>
                <p className="text-white/80 text-lg">{quiz.description}</p>
              </div>
              <div
                className={`text-5xl font-bold ${scoreColor} bg-white/10 rounded-xl px-4 py-2`}
              >
                {percentage}%
              </div>
            </div>
          </div>

          {/* Score Summary */}
          <div className="p-6 border-b border-border">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="text-center p-4 bg-chart-2/10 rounded-xl border border-chart-2/20">
                <div className="text-2xl font-bold text-chart-2">{correctAnswers}</div>
                <div className="text-chart-2 font-medium">Correct Answers</div>
              </div>
              <div className="text-center p-4 bg-primary/10 rounded-xl border border-primary/20">
                <div className="text-2xl font-bold text-primary">{results.length}</div>
                <div className="text-primary font-medium">Total Questions</div>
              </div>
              <div className="text-center p-4 bg-accent/10 rounded-xl border border-accent/20">
                <div className="text-2xl font-bold text-accent">
                  {yourScore}/{quiz.totalPoints}
                </div>
                <div className="text-accent font-medium">Total Points</div>
              </div>
            </div>
          </div>

          {/* Quiz Details */}
          <div className="p-6">
            <h2 className="text-xl font-semibold text-foreground mb-4">Quiz Details</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <div className="flex justify-between items-center py-2 border-b border-border">
                  <span className="text-muted-foreground font-medium">Time Limit</span>
                  <span className="text-foreground font-semibold">{quiz.timeLimit} minutes</span>
                </div>
                <div className="flex justify-between items-center py-2 border-b border-border">
                  <span className="text-muted-foreground font-medium">Difficulty</span>
                  <span className="text-foreground font-semibold capitalize">
                    {quiz.difficulty || "Medium"}
                  </span>
                </div>
                <div className="flex justify-between items-center py-2 border-b border-border">
                  <span className="text-muted-foreground font-medium">Created By</span>
                  <span className="text-foreground font-semibold">{quiz.creator.name}</span>
                </div>
              </div>

              <div className="space-y-4">
                <div className="flex justify-between items-center py-2 border-b border-border">
                  <span className="text-muted-foreground font-medium">Created Date</span>
                  <span className="text-foreground font-semibold text-sm">
                    {formatDate(quiz.createdAt)}
                  </span>
                </div>
                <div className="flex justify-between items-center py-2 border-b border-border">
                  <span className="text-muted-foreground font-medium">Last Updated</span>
                  <span className="text-foreground font-semibold text-sm">
                    {formatDate(quiz.updatedAt)}
                  </span>
                </div>
                <div className="flex justify-between items-center py-2 border-b border-border">
                  <span className="text-muted-foreground font-medium">Topic</span>
                  <span className="text-foreground font-semibold">{quiz.topic.name}</span>
                </div>
              </div>
            </div>

            {/* Tags */}
            {quiz.tags && quiz.tags.length > 0 && (
              <div className="mt-6">
                <h3 className="text-lg font-medium text-foreground mb-3">Tags</h3>
                <div className="flex flex-wrap gap-2">
                  {quiz.tags.map((tag, index) => (
                    <span
                      key={index}
                      className="px-3 py-1 bg-primary/20 text-primary rounded-full text-sm font-medium"
                    >
                      #{tag}
                    </span>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Performance Breakdown */}
        <div className="bg-white rounded-2xl shadow-xl p-6 mb-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">Performance Breakdown</h2>

          {/* Progress Bar */}
          <div className="mb-6">
            <div className="flex justify-between items-center mb-2">
              <span className="text-sm font-medium text-gray-700">Your Score</span>
              <span className="text-sm font-semibold text-gray-900">
                {correctAnswers} / {results.length} ({percentage}%)
              </span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-4">
              <div
                className={`h-4 rounded-full transition-all duration-1000 ease-out ${
                  percentage >= 80
                    ? "bg-green-500"
                    : percentage >= 60
                    ? "bg-yellow-500"
                    : "bg-red-500"
                }`}
                style={{ width: `${percentage}%` }}
              ></div>
            </div>
          </div>

          {/* Performance Message */}
          <div
            className={`p-4 rounded-xl border-2 ${
              percentage >= 80
                ? "bg-green-50 border-green-200 text-green-800"
                : percentage >= 60
                ? "bg-yellow-50 border-yellow-200 text-yellow-800"
                : "bg-red-50 border-red-200 text-red-800"
            }`}
          >
            <div className="flex items-center">
              <div className="flex-shrink-0">
                {percentage >= 80 ? (
                  <span className="text-2xl">🎉</span>
                ) : percentage >= 60 ? (
                  <span className="text-2xl">👍</span>
                ) : (
                  <span className="text-2xl">💪</span>
                )}
              </div>
              <div className="ml-3">
                <h3 className="font-semibold">
                  {percentage >= 80
                    ? "Excellent Work!"
                    : percentage >= 60
                    ? "Good Job!"
                    : "Keep Practicing!"}
                </h3>
                <p className="text-sm mt-1">
                  {percentage >= 80
                    ? "You've mastered this topic! Ready for the next challenge?"
                    : percentage >= 60
                    ? "You're on the right track! A little more practice will make you perfect."
                    : "Don't worry! Review the material and try again. You'll get better!"}
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <button
            onClick={() => navigate("/topics")}
            className="px-8 py-3 bg-gradient-to-r from-blue-500 to-purple-600 text-white font-semibold rounded-xl shadow-lg hover:from-blue-600 hover:to-purple-700 transition-all duration-300 transform hover:-translate-y-1"
          >
            Back to Topics
          </button>
          <button
            onClick={() => window.location.reload()}
            className="px-8 py-3 border-2 border-blue-500 text-blue-600 font-semibold rounded-xl hover:bg-blue-50 transition-all duration-300"
          >
            Try Again
          </button>
        </div>
      </div>
    </div>
  );
};

export default ResultsDisplay;
