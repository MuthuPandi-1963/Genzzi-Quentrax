import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useCategories } from '../../hooks/useCategories';
import { useTopics } from '../../hooks/useTopics';
import {useNavigate} from 'react-router-dom'
const CategorySlider = () => {
  const [activeCategory, setActiveCategory] = useState("");
  const [selectedTopicId, setSelectedTopicId] = useState(null);
  const [constraints, setConstraints] = useState({ left: 0, right: 0 });
  const sliderRef = useRef(null);
  const navigate = useNavigate()

  /** Fetch categories */
  const { categories: { data: categories = [] } } = useCategories();

  /** Fetch topics */
  const { topics: { data: topicsData = [] } } = useTopics();

  /** Fetch quizzes for selected topic (not used here) */

  /** Filter topics by category */
  const filteredTopics = activeCategory
    ? topicsData.filter(topic => topic.categoryId === activeCategory)
    : topicsData;

  /** Calculate slider drag constraints dynamically */
  useEffect(() => {
    if (sliderRef.current && categories.length > 0) {
      const scrollWidth = sliderRef.current.scrollWidth;
      const clientWidth = sliderRef.current.clientWidth;
      setConstraints({ left: -(scrollWidth - clientWidth), right: 0 });
    }
  }, [categories.length]);

  const handleQuizzes = (id) => {
    navigate(`/topics/${id}`)
    setSelectedTopicId(id);
  };

  /** Animation Variants */
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: { opacity: 1, transition: { staggerChildren: 0.1 } },
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: { y: 0, opacity: 1 },
  };

  const cardVariants = {
    hidden: { scale: 0.9, opacity: 0 },
    visible: {
      scale: 1,
      opacity: 1,
      transition: { type: 'spring', stiffness: 300, damping: 24 },
    },
    hover: {
      scale: 1.05,
      y: -5,
      boxShadow:
        '0 20px 25px -5px rgba(0,0,0,0.1), 0 10px 10px -5px rgba(0,0,0,0.04)',
      transition: { type: 'spring', stiffness: 400, damping: 17 },
    },
  };

  return (
    <div className="h-screen min-h-fit bg-gray-50 py-8 px-4 sm:px-6 lg:px-8">
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="max-w-7xl mx-auto"
      >
        {/* Header */}
        <div className="text-center mb-12">
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="text-4xl font-bold text-gray-900 mb-4"
          >
            Explore by Category
          </motion.h1>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="text-lg text-gray-600 max-w-2xl mx-auto"
          >
            Discover courses and topics that match your interests and career goals
          </motion.p>
        </div>

        {/* Category Slider */}
        <motion.div
          ref={sliderRef}
          className="relative mb-4 overflow-x-auto scrollbar-hide"
          initial="hidden"
          animate="visible"
          variants={containerVariants}
        >
          <motion.div
            className="flex space-x-3 pb-4"
            drag="x"
            dragConstraints={constraints}
            whileTap={{ cursor: 'grabbing' }}
          >
            {/* "All" Category */}
            <motion.button
              className={`flex items-center px-6 py-3 rounded-2xl text-sm font-medium whitespace-nowrap transition-all duration-300 ${
                activeCategory === ''
                  ? 'bg-gradient-to-r from-primary to-primary text-foreground shadow-lg'
                  : 'bg-card text-foreground hover:bg-muted shadow-md'
              }`}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => setActiveCategory('')}
              variants={itemVariants}
            >
              <img
                src="https://i.pinimg.com/1200x/24/86/4f/24864fa604c48845ee9e64ebc6441c3c.jpg"
                alt="All"
                className="mr-4 w-10 h-10 rounded-xl object-cover"
              />
              <div className="grid gap-y-2 px-4">
                <span className="text-left">All</span>
                <span className="w-40 text-left truncate text-muted-foreground font-medium">
                  Explore all Topics
                </span>
              </div>
            </motion.button>

            {/* Dynamic Categories */}
            {categories.map((category) => (
              <motion.button
                key={category.id}
                className={`flex items-center px-6 py-3 rounded-2xl text-sm font-medium whitespace-nowrap transition-all duration-300 ${
                  activeCategory === category.id
                    ? 'bg-gradient-to-r from-primary to-primary text-foreground shadow-lg'
                    : 'bg-card text-foreground hover:bg-muted shadow-md'
                }`}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => setActiveCategory(category.id)}
                variants={itemVariants}
              >
                <img
                  src={category.imageUrl}
                  alt={category.name}
                  className="mr-4 w-10 h-10 rounded-xl object-cover"
                />
                <div className="grid gap-y-2 px-4">
                  <span className="text-left">{category.name}</span>
                  <span className="w-40 truncate text-gray-500 font-medium">
                    {category.description}
                  </span>
                </div>
              </motion.button>
            ))}
          </motion.div>
        </motion.div>

        {/* Topics Section */}
        <div className="text-left">
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="text-xl font-bold text-gray-900 mb-4"
          >
            Explore by Topics
          </motion.h1>
        </div>

        {/* Topics Grid */}
        <motion.div
          key={activeCategory || 'all'}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6"
        >
          <AnimatePresence>
            {filteredTopics.map((topic, index) => (
              <motion.div
                key={topic.id}
                variants={cardVariants}
                initial="hidden"
                animate="visible"
                whileHover="hover"
                custom={index}
                className="bg-card rounded-xl shadow-md overflow-hidden border border-border"
              >
                <div className="p-6">
                  <img
                    src={topic.imageUrl}
                    alt={topic.name}
                    className="rounded-xl h-60 object-cover w-full"
                  />
                  <h3 className="text-xl font-semibold text-foreground mb-2">
                    {topic.name}
                  </h3>
                  <p className="text-muted-foreground text-sm leading-relaxed mb-6 line-clamp-2 ">
                    {topic.description}
                  </p>
                  <div className="flex justify-end">
                    <motion.button
                      onClick={() => handleQuizzes(topic.id)}
                      whileHover={{ scale: 1.1 }}
                      whileTap={{ scale: 0.9 }}
                      className="pl-10 pr-4 py-2 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full flex items-center justify-center text-white shadow-lg"
                    >
                      Explore Topics
                      <svg
                        className="w-5 h-5 ml-2"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={2}
                          d="M9 5l7 7-7 7"
                        />
                      </svg>
                    </motion.button>
                  </div>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </motion.div>
      </motion.div>

      {/* Hide scrollbar */}
      <style>{`
        .scrollbar-hide {
          -ms-overflow-style: none;
          scrollbar-width: none;
        }
        .scrollbar-hide::-webkit-scrollbar {
          display: none;
        }
      `}</style>
    </div>
  );
};

export default CategorySlider;
