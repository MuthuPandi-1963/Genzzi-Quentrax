import { Mail, MapPin, Phone } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { toast } from "react-hot-toast";

const contactItems = [
  { icon: Mail, title: "Email", value: "support@genzzi.in" },
  { icon: Phone, title: "Phone", value: "+1 (555) 123-4567" },
  { icon: MapPin, title: "Campus", value: "Learning Center, Block A" },
];

export default function Contact() {
  const handleSubmit = (e) => {
    e.preventDefault();
    toast.success("Message sent! We'll get back to you soon.");
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-24">
      <h1 className="text-3xl font-bold mb-2 text-foreground">Contact Us</h1>
      <p className="text-muted-foreground mb-8">
        Have questions about quizzes or assessments? Reach out to our team.
      </p>

      <div className="grid md:grid-cols-2 gap-8">
        <Card>
          <CardHeader>
            <CardTitle>Send a message</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label>Name</Label>
                <Input required placeholder="Your name" />
              </div>
              <div>
                <Label>Email</Label>
                <Input type="email" required placeholder="you@school.edu" />
              </div>
              <div>
                <Label>Message</Label>
                <Textarea required rows={4} placeholder="How can we help?" />
              </div>
              <Button type="submit" className="w-full">
                Submit
              </Button>
            </form>
          </CardContent>
        </Card>

        <div className="space-y-4">
          {contactItems.map(({ icon: Icon, title, value }) => (
            <Card key={title}>
              <CardContent className="pt-6 flex gap-3">
                <Icon className="h-5 w-5 text-primary shrink-0" />
                <div>
                  <p className="font-medium text-foreground">{title}</p>
                  <p className="text-sm text-muted-foreground">{value}</p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}
