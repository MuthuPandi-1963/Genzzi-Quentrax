import { QueryClient } from '@tanstack/react-query'

// Global error handler
const handleQueryError = (error) => {
  if (error.response) {
    // Server responded with a status outside 2xx
    console.error('Server Error:', error.response.data)
  } else if (error.request) {
    // Request made but no response
    console.error('Network Error:', error.message)
  } else {
    console.error('Unknown Error:', error.message)
  }
}

// Create a QueryClient instance
const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      // Retry failed requests 2 times
      retry: 2,
      
      // Refetch on window focus (true, false, or function)
      refetchOnWindowFocus: true,
      
      // Polling interval (ms) or false to disable
      refetchInterval: false,
      
      // Cache time before garbage collection
      cacheTime: 1000 * 60 * 5, // 5 minutes
      
      // Stale time before refetching
      staleTime: 1000 * 60, // 1 minute

      // On error handler for all queries
      onError: handleQueryError,
      
      // On success hook (optional, useful for logging)
      onSuccess: (data) => {
        // console.log('Query succeeded:', data)
      },
    },

    mutations: {
      retry: 1,
      onError: handleQueryError,
    },
  },
})

export default queryClient
