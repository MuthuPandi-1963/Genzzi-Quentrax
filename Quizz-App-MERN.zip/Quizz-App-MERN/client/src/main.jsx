import { createRoot } from "react-dom/client";
import "./index.css";
import App from "./App.jsx";
import { Provider } from "react-redux";
import { store } from "./store/store.js";
import { BrowserRouter } from "react-router-dom";
import { QueryClientProvider } from "@tanstack/react-query";
import queryClient from "./config/query.js";
import {Toaster} from 'react-hot-toast'

createRoot(document.getElementById("root")).render(
  <Provider store={store}>
    <>
    <BrowserRouter>
      <QueryClientProvider client={queryClient}>
        <App />
        <Toaster
        position="top-right"
        reverseOrder={false}
        />
      </QueryClientProvider>
    </BrowserRouter>
        </>
  </Provider>
);
