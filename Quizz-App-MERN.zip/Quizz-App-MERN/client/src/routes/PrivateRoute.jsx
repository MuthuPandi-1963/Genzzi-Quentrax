import { useSelector } from "react-redux";
import { Navigate, Outlet, useLocation } from "react-router-dom";
import { getRoleHomePath, isStaffOrAdmin } from "@/utils/roleRedirect";

/** Require authentication */
export const PrivateRoutes = () => {
  const { user, isAuthenticated } = useSelector((state) => state.user);
  const { pathname } = useLocation();

  if (!isAuthenticated) {
    return <Navigate to="/login" replace state={{ from: pathname }} />;
  }

  if (pathname.includes("/login") || pathname.includes("/signup")) {
    return <Navigate to={getRoleHomePath(user?.role)} replace />;
  }

  return <Outlet />;
};

/** Student-only routes */
export const StudentRoutes = () => {
  const { user, isAuthenticated } = useSelector((state) => state.user);
  if (!isAuthenticated) return <Navigate to="/login" replace />;
  if (user?.role !== "STUDENT") {
    return <Navigate to={getRoleHomePath(user?.role)} replace />;
  }
  return <Outlet />;
};

/** Staff + Admin panel routes */
export const StaffAdminRoutes = () => {
  const { user, isAuthenticated } = useSelector((state) => state.user);
  if (!isAuthenticated) return <Navigate to="/login" replace />;
  if (!isStaffOrAdmin(user?.role)) {
    return <Navigate to={getRoleHomePath(user?.role)} replace />;
  }
  return <Outlet />;
};

/** Admin-only routes */
export const AdminOnlyRoutes = () => {
  const { user, isAuthenticated } = useSelector((state) => state.user);
  if (!isAuthenticated) return <Navigate to="/login" replace />;
  if (user?.role !== "ADMIN") {
    return <Navigate to={getRoleHomePath(user?.role)} replace />;
  }
  return <Outlet />;
};
