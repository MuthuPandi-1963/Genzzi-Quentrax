import { Route } from "react-router-dom";
import Dashboard from "../layouts/admin/Dashboard";
import AdminLayout from "../layouts/admin/AdminLayout";
import UserManagement from "../pages/admin/UserManagement";
import CategoryManagement from "../pages/admin/CategoryManagement";
import TopicManagement from "../pages/admin/TopicsManagement";
import QuestionManagement from "../pages/admin/QuestionsManagement";
import QuizManagement from "../pages/admin/QuizManagement";
import QuizHistory from "../pages/admin/QuizHistory";
import AssessmentManagement from "../pages/admin/AssessmentManagement";
import ReportsPage from "../pages/admin/ReportsPage";
import AnalyticsPage from "../pages/admin/AnalyticsPage";
const AdminRoutes = (
  <Route path="admin/" element={<AdminLayout />}>
    <Route index element={<Dashboard />} />
    <Route path="users" element={<UserManagement />} />
    <Route path="categories" element={<CategoryManagement />} />
    <Route path="topics" element={<TopicManagement />} />
    <Route path="questions" element={<QuestionManagement />} />
    <Route path="quizzes" element={<QuizManagement />} />
    <Route path="quiz/history" element={<QuizHistory />} />
    <Route path="assessments" element={<AssessmentManagement />} />
    <Route path="reports" element={<ReportsPage />} />
    <Route path="analytics" element={<AnalyticsPage />} />
  </Route>
);

export default AdminRoutes;
