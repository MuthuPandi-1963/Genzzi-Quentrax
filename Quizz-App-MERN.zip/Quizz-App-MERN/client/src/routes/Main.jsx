import { Route } from "react-router-dom";
import LandingPage, { MainPage } from "../pages/main/Page";
import CategorySlider from "../pages/main/CategorySlider";
import TopicsSlider from "../pages/main/TopicsSlider";
import { QuizContainer } from "../pages/main/QuizTest";
import ResultsDisplay from "../pages/main/ResultDisplay";
import Login from "../pages/auth/Login";
import Signup from "../pages/auth/Signup";
import VerifyEmail from "../pages/auth/VerifyEmail";
import Profile from "../pages/main/Profile";
import AboutUsPage from "../pages/main/About";
import Contact from "../pages/main/Contact";
import { PrivateRoutes, StudentRoutes } from "./PrivateRoute";
import StudentDashboard from "../pages/student/StudentDashboard";
import StudentAssessments from "../pages/student/StudentAssessments";

// Fix route path casing mismatch: component is under StudentAssessments

import StudentResults from "../pages/student/StudentResults";

export const ProtectedRoutes = (
  <>
    <Route path="topics" element={<TopicsSlider />} />
    <Route path="topics/:id" element={<TopicsSlider />} />
    <Route path="quiz_test" element={<QuizContainer />} />
    <Route path="results" element={<ResultsDisplay />} />
    <Route path="profile" element={<Profile />} />
  </>
);

export const StudentRouteTree = (
  <Route element={<StudentRoutes />}>
    <Route path="student" element={<StudentDashboard />} />
    <Route path="student/assessments" element={<StudentAssessments />} />
    <Route path="student/results" element={<StudentResults />} />
  </Route>
);

export const PublicRoutes = (
  <>
    <Route index element={<MainPage />} />
    <Route path="categories" element={<CategorySlider />} />
    <Route path="about" element={<AboutUsPage />} />
    <Route path="contact" element={<Contact />} />
    <Route path="login" element={<Login />} />
    <Route path="signup" element={<Signup />} />
    <Route path="verify-email" element={<VerifyEmail />} />
  </>
);

export const MainRoutes = (
  <Route path="/" element={<LandingPage />}>
    {PublicRoutes}
    <Route element={<PrivateRoutes />}>
      {ProtectedRoutes}
      {StudentRouteTree}
    </Route>
  </Route>
);
