/** Default home path after login by role */
export const getRoleHomePath = (role) => {
  switch (role) {
    case "ADMIN":
      return "/admin";
    case "STAFF":
      return "/admin";
    case "STUDENT":
      return "/student";
    default:
      return "/";
  }
};

export const isStaffOrAdmin = (role) => role === "ADMIN" || role === "STAFF";
