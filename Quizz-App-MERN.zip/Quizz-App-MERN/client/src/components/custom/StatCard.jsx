import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"; // shadcn UI
import { motion } from "framer-motion";
import { cn } from "@/lib/utils"; // helper to combine Tailwind classes

/**
 * StatCard Component
 * @param {string} title - Title of the stat (e.g., "Total Users")
 * @param {string|number} value - Main value to display
 * @param {string} icon: Lucide icon component
 * @param {string} trend - Optional: percentage or text trend info
 * @param {string} trendType - "positive" | "negative" (for color coding)
 */
const StatCard = ({ title, value, icon: Icon, trend, trendType = "positive" }) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
    >
      <Card className="shadow-sm rounded-2xl border border-gray-200 dark:border-gray-800 hover:shadow-lg transition-all">
        <CardHeader className="flex flex-row items-center justify-between pb-2">
          <CardTitle className="text-sm font-medium text-gray-500 dark:text-gray-400">
            {title}
          </CardTitle>
          {Icon && <Icon className="h-5 w-5 text-gray-400" />}
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold text-gray-900 dark:text-white">
            {value}
          </div>
          {trend && (
            <p
              className={cn(
                "text-xs mt-1",
                trendType === "positive" ? "text-green-600" : "text-red-600"
              )}
            >
              {trendType === "positive" ? "↑ " : "↓ "}
              {trend}
            </p>
          )}
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default StatCard;
