import { Menu, X, LogOut } from "lucide-react";
import React from "react";
import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useSelector, useDispatch } from "react-redux";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/useAuth";
import { logout } from "@/store/slices";
import { toast } from "react-hot-toast";
import { getRoleHomePath, isStaffOrAdmin } from "@/utils/roleRedirect";
import logo from "@/assets/logo.png";
const guestLinks = [
  { to: "/", label: "Home" },
  { to: "/about", label: "About" },
  { to: "/login", label: "Login" },
  { to: "/signup", label: "Register" },
  { to: "/contact", label: "Contact" },
];

const studentLinks = [
  { to: "/student", label: "Dashboard" },
  { to: "/categories", label: "Categories" },
  { to: "/topics", label: "Topics" },
  { to: "/student/assessments", label: "Assessments" },
  { to: "/student/results", label: "Results" },
  { to: "/profile", label: "Profile" },
];

const staffAdminLinks = [
  { to: "/admin", label: "Dashboard" },
  { to: "/admin/quizzes", label: "Quiz Management" },
  { to: "/admin/categories", label: "Categories" },
  { to: "/admin/topics", label: "Topics" },
  { to: "/admin/assessments", label: "Assessments" },
  { to: "/admin/users", label: "Student Management" },
  { to: "/admin/reports", label: "Reports" },
  { to: "/admin/analytics", label: "Analytics" },
  { to: "/profile", label: "Profile" },
];

export default function RoleNavbar() {
  const [isOpen, setIsOpen] = useState(false);
  const { user, isAuthenticated } = useSelector((s) => s.user);
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { useLogout } = useAuth();

  const links = !isAuthenticated
    ? guestLinks
    : user?.role === "STUDENT"
      ? studentLinks
      : isStaffOrAdmin(user?.role)
        ? staffAdminLinks
        : guestLinks;

  const handleLogout = () => {
    useLogout.mutate(undefined, {
      onSuccess: () => {
        dispatch(logout());
        toast.success("Logged out");
        navigate("/login");
      },
    });
  };

  const dashPath = user ? getRoleHomePath(user.role) : "/";

  return (
    <nav className="bg-white shadow-md fixed justify-between w-full z-50">
      <div className="max-w-7xl sm:px-6 lg:px-8">
        <div className="flex justify-between h-16 items-center">
          <div className="flex items-center gap-6">
            <Link to={isAuthenticated ? dashPath : "/"} className="flex items-center shrink-0">
             <img src={logo} alt="quentrax Logo" width={100}/>
            </Link>
            <div className="hidden md:flex md:gap-5">
              {links.map((l) => (
                <Link
                  key={`${l.to}-${l.label}`}
                  to={l.to}
                  className="text-sm font-medium text-gray-600 hover:text-indigo-600"
                >
                  {l.label}
                </Link>
              ))}
            </div>
          </div>

          <div className="hidden md:flex items-center gap-2">
            {isAuthenticated ? (
              <>
                <Link to="/profile">
                  <img
                    src={user?.avatar}
                    alt=""
                    className="w-9 h-9 rounded-full object-cover border"
                  />
                </Link>
                <Button variant="ghost" size="sm" onClick={handleLogout}>
                  <LogOut className="h-4 w-4 mr-1" /> Logout
                </Button>
              </>
            ) : (
              <>
                <Link to="/login">
                  <Button variant="outline">Login</Button>
                </Link>
                <Link to="/signup">
                  <Button>Get Started</Button>
                </Link>
              </>
            )}
          </div>

          <button type="button" className="md:hidden p-2" onClick={() => setIsOpen(!isOpen)}>
            {isOpen ? <X /> : <Menu />}
          </button>
        </div>
      </div>

      {isOpen && (
        <div className="md:hidden border-t px-4 py-3 space-y-2 bg-white">
          {links.map((l) => (
            <Link
              key={`${l.to}-${l.label}-m`}
              to={l.to}
              className="block py-2 text-gray-700"
              onClick={() => setIsOpen(false)}
            >
              {l.label}
            </Link>
          ))}
          {isAuthenticated && (
            <Button variant="outline" className="w-full" onClick={handleLogout}>
              Logout
            </Button>
          )}
        </div>
      )}
    </nav>
  );
}
