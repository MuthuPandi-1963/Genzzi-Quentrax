import { Award, Menu, X } from "lucide-react";
import React,{ useState } from "react";
import { Link } from "react-router-dom";
import {useSelector} from 'react-redux'
import {Button} from '@/components/ui/button'
const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);
  const {user,isAuthenticated} = useSelector(state=>state.user)
  console.log(user);
  

  return (
    <nav className="bg-white shadow-md fixed w-full z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex items-center">
              <Link to={"/"}>
              
              </Link>
            <div className="hidden md:ml-6 md:flex md:space-x-8">
              <Link to="/" className="text-gray-900 inline-flex items-center px-1 pt-1  text-sm font-medium">
                Home
              </Link>
              <Link to="/categories" className="text-gray-500 hover:text-gray-900 inline-flex items-center px-1 pt-1 border-b-2 border-transparent hover:border-gray-300 text-sm font-medium">
                Categories
              </Link>
              <Link to="/topics" className="text-gray-500 hover:text-gray-900 inline-flex items-center px-1 pt-1 border-b-2 border-transparent hover:border-gray-300 text-sm font-medium">
                Topics
              </Link>
              {/* <Link to={"/"} className="text-gray-500 hover:text-gray-900 inline-flex items-center px-1 pt-1 border-b-2 border-transparent hover:border-gray-300 text-sm font-medium">
                Leaderboard
              </Link> */}
              <Link to={"/about"} className="text-gray-500 hover:text-gray-900 inline-flex items-center px-1 pt-1 border-b-2 border-transparent hover:border-gray-300 text-sm font-medium">
                About Us
              </Link>
            </div>
          </div>
          <div className="hidden md:flex gap-x-2">
            {isAuthenticated ? 
            
            <div className="flex items-center ">
              {user.role == "ADMIN" && (
                <Button className="mx-4">

                <Link to={"/admin"} className="">
                  Admin Dashboard
                </Link>
                </Button>
              )}
              <Link to={"/profile"}>
              <img src={user?.avatar} alt=""  className="w-10 h-10"/>
              </Link>
              {/* <span className="text-md font-semibold">{user.name}</span> */}
            </div> 
            :
            <div className="flex items-center">
            <Link to="/login" className="text-gray-500  hover:text-gray-900 px-3 py-2 rounded-md text-sm font-medium">
              Login
            </Link>
            <Link to={"/signup"} className="ml-4 px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700">
              Get Started
            </Link>
            </div>
        }
          </div>
          <div className="md:hidden flex items-center">
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="inline-flex items-center justify-center p-2 rounded-md text-gray-400 hover:text-gray-500 hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-indigo-500"
            >
              {isOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      {isOpen && (
        <div className="md:hidden">
          <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
            <Link to="/" className="bg-gray-100 text-gray-900 block px-3 py-2 rounded-md text-base font-medium">
              Home
            </Link>
            <Link to="/categories" className="text-gray-500 hover:text-gray-900 block px-3 py-2 rounded-md text-base font-medium">
              Categories
            </Link>
            <Link to="/topics" className="text-gray-500 hover:text-gray-900 block px-3 py-2 rounded-md text-base font-medium">
              Topics
            </Link>
            <Link to="/about" className="text-gray-500 hover:text-gray-900 block px-3 py-2 rounded-md text-base font-medium">
              About Us
            </Link>
            <div className="pt-4 pb-3 border-t border-gray-200">
              {isAuthenticated ? 
            
            <Link to={"/profile"} className="flex items-center gap-x-2">
              <img src={user?.avatar} alt=""  className="w-10 h-10"/>
              <span className="text-md font-semibold">{user.name}</span>
            </Link> 
            :<>
              <Link to="/" className="text-gray-500 hover:text-gray-900 block px-3 py-2 rounded-md text-base font-medium">
                Login
              </Link>
              <Link to="/" className="mt-2 block px-3 py-2 rounded-md text-base font-medium text-white bg-indigo-600 hover:bg-indigo-700">
                Get Started
              </Link>
              </>
}
            </div>
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar