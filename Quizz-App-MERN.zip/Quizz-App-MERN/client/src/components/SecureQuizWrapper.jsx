import React, { useEffect, useMemo, useRef, useState } from "react";
import PropTypes from "prop-types";

const EVENT_MAP = {
  TAB_SWITCH: "TAB_SWITCH",
  WINDOW_BLUR: "WINDOW_BLUR",
  FULLSCREEN_EXIT: "FULLSCREEN_EXIT",
  PAGE_HIDDEN: "PAGE_HIDDEN",
  OTHER: "OTHER",
};

function useLatest(value) {
  const r = useRef(value);
  r.current = value;
  return r;
}

export default function SecureQuizWrapper({
  children,
  attemptId,
  quizId,
  userId,
}) {

  const mountedRef = useRef(true);
  const submitInFlightRef = useRef(false);
  const autoSubmitDoneRef = useRef(false);
  const timerIntervalRef = useRef(null);

  const [serverRemainingMs, setServerRemainingMs] = useState(null);

  const userIdRef = useLatest(userId);
  const attemptIdRef = useLatest(attemptId);

  useEffect(() => {
    mountedRef.current = true;
    return () => {
      mountedRef.current = false;
      if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
    };
  }, []);

  const postMonitoringEvent = async (eventType, metadata) => {
    // Silent collection only; never trigger submit.
    const aId = attemptIdRef.current;
    const uId = userIdRef.current;
    if (!aId || !uId) return;

    // Best-effort; no UI, no throws.
    try {
      await fetch("/api/track-monitoring-event", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          attemptId: aId,
          userId: uId,
          quizId,
          eventType: EVENT_MAP[eventType] || "OTHER",
          timestamp: new Date().toISOString(),
          metadata,
        }),
      });
    } catch {
      // swallow
    }
  };

  useEffect(() => {
    if (!attemptId) return;

    const onVisibility = () => {
      if (document.visibilityState === "hidden") {
        postMonitoringEvent("PAGE_HIDDEN");
      }
      if (document.hidden) {
        postMonitoringEvent("TAB_SWITCH");
      }
    };

    const onBlur = () => postMonitoringEvent("WINDOW_BLUR");

    const onFullscreenChange = () => {
      // If fullscreen was exited during an active attempt, log silently.
      if (!document.fullscreenElement) postMonitoringEvent("FULLSCREEN_EXIT");
    };

    window.addEventListener("blur", onBlur);
    document.addEventListener("visibilitychange", onVisibility);
    document.addEventListener("fullscreenchange", onFullscreenChange);

    return () => {
      window.removeEventListener("blur", onBlur);
      document.removeEventListener("visibilitychange", onVisibility);
      document.removeEventListener("fullscreenchange", onFullscreenChange);
    };
  }, [attemptId]);

  // Timer sync: server-authoritative remaining time should come from an endpoint.
  // If endpoint is not yet implemented, this wrapper won’t break UI.
  useEffect(() => {
    if (!attemptId) return;

    let cancelled = false;

    const sync = async () => {
      try {
        const r = await fetch(`/api/attempts/${attemptId}/state`, {
          method: "GET",
          headers: { "Content-Type": "application/json" },
        });
        if (!r.ok) return;
        const data = await r.json();
        // Expect { remainingMs }
        if (cancelled || !mountedRef.current) return;
        if (typeof data?.data?.remainingMs === "number") {
          setServerRemainingMs(data.data.remainingMs);
        }
      } catch {
        // ignore
      }
    };

    sync();
    if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
    timerIntervalRef.current = setInterval(sync, 10_000);

    return () => {
      cancelled = true;
      if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
      timerIntervalRef.current = null;
    };
  }, [attemptId]);

  const autoSubmit = async () => {
    if (!attemptId) return;
    if (autoSubmitDoneRef.current) return;
    if (submitInFlightRef.current) return;

    autoSubmitDoneRef.current = true;
    submitInFlightRef.current = true;

    try {
      const r = await fetch("/api/attempts/submit", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          attemptId,
          mode: "TIMER",
        }),
      });
      // no UI interruption
      if (r.ok) {
        // Let the quiz page handle navigation based on its own state.
      }
    } catch {
      // swallow
    } finally {
      submitInFlightRef.current = false;
    }
  };

  // Timer expiry submit must be server-driven and idempotent.
  useEffect(() => {
    if (serverRemainingMs === null) return;
    if (serverRemainingMs > 0) return;
    autoSubmit();
  }, [serverRemainingMs]);

  // Debounced autosave/recovery is implemented inside quiz pages in this repo currently.
  // Wrapper is kept non-breaking and production-safe; once server endpoints for
  // autosave/state exist, move logic here.

  const wrapperClassName = useMemo(() => "relative min-h-screen", []);

  return (
    <div className={wrapperClassName}>
      {children}
    </div>
  );
}


SecureQuizWrapper.propTypes = {
  children: PropTypes.node,
  attemptId: PropTypes.string,
  quizId: PropTypes.string,
  userId: PropTypes.string,
};


