import React, { useState, useEffect, useMemo, useCallback } from "react";
import PropTypes from "prop-types";

import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Search, User, Users, X, Calendar, RefreshCw } from "lucide-react";
import { toast } from "react-hot-toast";
import { AssessmentsAPI } from "@/api/assessments.api";
import { useAssignableUsers } from "@/hooks/useAssignableUsers";

const UserAssignmentModal = ({
  assessmentId,
  open,
  onOpenChange,
  onAssigned,
}) => {
  const [selectedUsers, setSelectedUsers] = useState(new Set());
  const [searchTerm, setSearchTerm] = useState("");
  const [roleFilter, setRoleFilter] = useState("all");
  const [dueDate, setDueDate] = useState("");
  const [assigning, setAssigning] = useState(false);

  const {
    users: assignableUsers,
    loading: usersLoading,
    error: usersError,
    refetch: refetchUsers,
  } = useAssignableUsers();

  const [assignedUsers, setAssignedUsers] = useState([]);
  const [fetchingAssigned, setFetchingAssigned] = useState(false);

  const fetchAssignedUsers = async () => {
    if (!assessmentId) return;
    setFetchingAssigned(true);
    try {
      const response = await AssessmentsAPI.getAssignedUsers(assessmentId);
      if (response.data?.success) {
        setAssignedUsers(response.data.data || []);
      }
    } catch (error) {
      console.error("Error fetching assigned users:", error);
      toast.error("Failed to load assigned users");
    } finally {
      setFetchingAssigned(false);
    }
  };

  useEffect(() => {
    if (open) {
      fetchAssignedUsers();
    }
  }, [open, assessmentId]);


  const filteredUsers = useMemo(() => {
    return (assignableUsers || []).filter((user) => {
      const matchesSearch =
        user.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        user.email?.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesRole = roleFilter === "all" || user.role === roleFilter;
      const notAlreadyAssigned =
        !assignedUsers.find((a) => a.userId === user.id);
      return matchesSearch && matchesRole && notAlreadyAssigned;
    });
  }, [assignableUsers, searchTerm, roleFilter, assignedUsers]);

  const toggleUser = useCallback((userId) => {
    setSelectedUsers((prev) => {
      const newSet = new Set(prev);
      if (newSet.has(userId)) newSet.delete(userId);
      else newSet.add(userId);
      return newSet;
    });
  }, []);

  const toggleAll = useCallback(() => {
    if (filteredUsers.length === 0) return;
    if (selectedUsers.size === filteredUsers.length) setSelectedUsers(new Set());
    else setSelectedUsers(new Set(filteredUsers.map((u) => u.id)));
  }, [filteredUsers, selectedUsers.size]);

  const handleAssign = async () => {
    if (!assessmentId) return;
    if (selectedUsers.size === 0) {
      toast.error("Please select at least one user");
      return;
    }

    setAssigning(true);
    try {
      const response = await AssessmentsAPI.assignUsers(assessmentId, {
        userIds: Array.from(selectedUsers),
        dueDate: dueDate || null,
      });

      if (response.data?.success) {
        toast.success(`${response.data.count} users assigned successfully`);
        setSelectedUsers(new Set());
        setDueDate("");
        fetchAssignedUsers();
        refetchUsers();
        if (onAssigned) onAssigned();
        onOpenChange(false);
      }
    } catch (error) {
      toast.error(error.response?.data?.message || "Failed to assign users");
    } finally {
      setAssigning(false);
    }
  };

  const removeAssignedUser = async (userId) => {
    if (!assessmentId) return;
    try {
      await AssessmentsAPI.unassignUser(assessmentId, userId);
      toast.success("User removed from assessment");
      fetchAssignedUsers();
      refetchUsers();
      if (onAssigned) onAssigned();
    } catch (error) {
      toast.error("Failed to remove user");
    }
  };

  const getRoleBadgeColor = (role) => {
    switch (role) {
      case "ADMIN":
        return "bg-red-100 text-red-800";
      case "STAFF":
        return "bg-blue-100 text-blue-800";
      case "STUDENT":
        return "bg-green-100 text-green-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const getAssignmentStatusColor = (status) => {
    switch (status) {
      case "PENDING":
        return "bg-yellow-100 text-yellow-800";
      case "IN_PROGRESS":
        return "bg-blue-100 text-blue-800";
      case "COMPLETED":
        return "bg-green-100 text-green-800";
      case "EXEMPTED":
        return "bg-gray-100 text-gray-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  useEffect(() => {
    if (!open) {
      setSelectedUsers(new Set());
      setSearchTerm("");
      setRoleFilter("all");
      setDueDate("");
    }
  }, [open]);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[80vh] overflow-hidden flex flex-col">
        <DialogHeader>
          <DialogTitle>Assign Users to Assessment</DialogTitle>
        </DialogHeader>

        <div className="flex-1 overflow-y-auto py-4">
          {assignedUsers.length > 0 && (
            <div className="mb-6">
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-sm font-semibold flex items-center gap-2">
                  <Users className="w-4 h-4" />
                  Already Assigned ({assignedUsers.length})
                </h3>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={fetchAssignedUsers}
                  disabled={fetchingAssigned}
                >
                  <RefreshCw
                    className={`w-4 h-4 ${fetchingAssigned ? "animate-spin" : ""}`}
                  />
                </Button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                {assignedUsers.map((assignment) => (
                  <div
                    key={assignment.id}
                    className="flex items-center justify-between p-3 bg-gray-50 rounded-lg border"
                  >
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center">
                        <User className="w-4 h-4 text-blue-600" />
                      </div>
                      <div>
                        <p className="text-sm font-medium">{assignment.user.name}</p>
                        <p className="text-xs text-gray-500">{assignment.user.email}</p>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <Badge
                        className={getAssignmentStatusColor(assignment.status)}
                        variant="outline"
                      >
                        {assignment.status}
                      </Badge>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => removeAssignedUser(assignment.userId)}
                      >
                        <X className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          <div>
            <h3 className="text-sm font-semibold mb-3 flex items-center gap-2">
              <User className="w-4 h-4" />
              Select Users to Assign
            </h3>

            {usersLoading && (
              <div className="flex items-center justify-center py-8">
                <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-blue-600"></div>
                <span className="ml-2 text-sm text-gray-500">Loading users...</span>
              </div>
            )}

            {usersError && (
              <div className="p-4 bg-red-50 border border-red-200 rounded-lg">
                <p className="text-sm text-red-600">Failed to load users</p>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => refetchUsers()}
                  className="mt-2"
                >
                  Retry
                </Button>
              </div>
            )}

            {!usersLoading && !usersError && (
              <>
                <div className="flex gap-3 mb-4">
                  <div className="relative flex-1">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                    <Input
                      placeholder="Search by name or email..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                  <select
                    value={roleFilter}
                    onChange={(e) => setRoleFilter(e.target.value)}
                    className="px-3 py-2 border rounded-md"
                  >
                    <option value="all">All Roles</option>
                    <option value="STUDENT">Students</option>
                    <option value="STAFF">Staff</option>
                  </select>
                </div>

                <div className="mb-4">
                  <Label className="flex items-center gap-2">
                    <Calendar className="w-4 h-4" />
                    Due Date (optional)
                  </Label>
                  <Input
                    type="date"
                    value={dueDate}
                    onChange={(e) => setDueDate(e.target.value)}
                    className="mt-1"
                    min={new Date().toISOString().split("T")[0]}
                  />
                </div>

                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <input
                      type="checkbox"
                      checked={
                        selectedUsers.size === filteredUsers.length &&
                        filteredUsers.length > 0
                      }
                      onChange={toggleAll}
                      className="h-4 w-4 rounded border-gray-300"
                    />
                    <span className="text-sm text-gray-600">
                      Select All ({filteredUsers.length} available)
                    </span>
                  </div>
                  {selectedUsers.size > 0 && (
                    <Badge variant="secondary">{selectedUsers.size} selected</Badge>
                  )}
                </div>

                <div className="border rounded-lg max-h-64 overflow-y-auto">
                  {filteredUsers.length === 0 ? (
                    <div className="p-8 text-center text-gray-500">
                      {assignableUsers.length === 0
                        ? "No assignable users found"
                        : "No users found matching your criteria"}
                    </div>
                  ) : (
                    filteredUsers.map((user) => (
                      <div
                        key={user.id}
                        onClick={() => toggleUser(user.id)}
                        className={`flex items-center justify-between p-3 border-b last:border-b-0 cursor-pointer hover:bg-gray-50 ${
                          selectedUsers.has(user.id) ? "bg-blue-50" : ""
                        }`}
                      >
                        <div className="flex items-center gap-3">
                          <input
                            type="checkbox"
                            checked={selectedUsers.has(user.id)}
                            onChange={() => {}}
                            className="h-4 w-4 rounded border-gray-300"
                          />
                          <div className="w-8 h-8 rounded-full bg-gray-200 flex items-center justify-center">
                            <User className="w-4 h-4 text-gray-600" />
                          </div>
                          <div>
                            <p className="text-sm font-medium">{user.name}</p>
                            <p className="text-xs text-gray-500">{user.email}</p>
                          </div>
                        </div>

                        <Badge
                          className={getRoleBadgeColor(user.role)}
                          variant="outline"
                        >
                          {user.role}
                        </Badge>
                      </div>
                    ))
                  )}
                </div>
              </>
            )}
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button
            onClick={handleAssign}
            disabled={assigning || selectedUsers.size === 0}
          >
            {assigning
              ? "Assigning..."
              : `Assign ${selectedUsers.size} User${
                  selectedUsers.size !== 1 ? "s" : ""
                }`}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

UserAssignmentModal.propTypes = {
  assessmentId: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),

  open: PropTypes.bool.isRequired,
  onOpenChange: PropTypes.func.isRequired,
  onAssigned: PropTypes.func,
};

export default UserAssignmentModal;


