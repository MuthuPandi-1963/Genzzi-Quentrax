import React,{ useState, useEffect } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Search,
  FileText,
  Clock,
  TrendingUp,
  Filter,
  ChevronDown,
  ChevronUp,
} from "lucide-react";
import { AssessmentsAPI } from "@/api/assessments.api";

const QuestionViewerModal = ({ assessmentId, open, onOpenChange }) => {
  const [questions, setQuestions] = useState([]);
  const [stats, setStats] = useState(null);
  const [quiz, setQuiz] = useState(null);
  const [loading, setLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [typeFilter, setTypeFilter] = useState("all");
  const [difficultyFilter, setDifficultyFilter] = useState("all");
  const [expandedQuestion, setExpandedQuestion] = useState(null);

  useEffect(() => {
    if (open && assessmentId) {
      fetchQuestions();
    }
  }, [open, assessmentId]);

  const fetchQuestions = async () => {
    setLoading(true);
    try {
      const response = await AssessmentsAPI.getQuestions(assessmentId);
      if (response.data.success) {
        setQuestions(response.data.data || []);
        setStats(response.data.stats || null);
        setQuiz(response.data.quiz || null);
      }
    } catch (error) {
      console.error("Error fetching questions:", error);
    } finally {
      setLoading(false);
    }
  };

  const filteredQuestions = questions.filter((q) => {
    const matchesSearch = q.questionText.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesType = typeFilter === "all" || q.questionType === typeFilter;
    const matchesDifficulty = difficultyFilter === "all" || q.difficulty === difficultyFilter;
    return matchesSearch && matchesType && matchesDifficulty;
  });

  const getDifficultyColor = (difficulty) => {
    switch (difficulty) {
      case "easy":
        return "bg-green-100 text-green-800";
      case "medium":
        return "bg-yellow-100 text-yellow-800";
      case "hard":
        return "bg-red-100 text-red-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const getTypeLabel = (type) => {
    switch (type) {
      case "MCQ":
        return "Multiple Choice";
      case "TRUE_FALSE":
        return "True/False";
      case "FILL_BLANK":
        return "Fill in the Blank";
      default:
        return type;
    }
  };

  if (loading) {
    return (
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent>
          <div className="flex items-center justify-center py-12">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-5xl max-h-[80vh] overflow-hidden flex flex-col">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <FileText className="w-5 h-5" />
            Assessment Questions
          </DialogTitle>
        </DialogHeader>

        <div className="flex-1 overflow-y-auto py-4">
          {/* Quiz Info */}
          {quiz && (
            <Card className="mb-6">
              <CardHeader className="pb-3">
                <CardTitle className="text-lg">{quiz.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-gray-600 mb-2">{quiz.description}</p>
                <div className="flex gap-4 text-sm text-gray-500">
                  <span>Total Points: {stats?.totalPoints || 0}</span>
                  <span>Total Questions: {stats?.total || 0}</span>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Statistics */}
          {stats && stats.total > 0 && (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
              <div className="bg-blue-50 p-3 rounded-lg">
                <p className="text-sm text-gray-600">Total Questions</p>
                <p className="text-2xl font-bold text-blue-600">{stats.total}</p>
              </div>
              <div className="bg-green-50 p-3 rounded-lg">
                <p className="text-sm text-gray-600">Total Points</p>
                <p className="text-2xl font-bold text-green-600">{stats.totalPoints}</p>
              </div>
              <div className="bg-purple-50 p-3 rounded-lg">
                <p className="text-sm text-gray-600">By Type</p>
                <div className="text-sm mt-1">
                  {Object.entries(stats.byType).map(([type, count]) => (
                    <div key={type} className="flex justify-between">
                      <span>{getTypeLabel(type)}:</span>
                      <span className="font-medium">{count}</span>
                    </div>
                  ))}
                </div>
              </div>
              <div className="bg-orange-50 p-3 rounded-lg">
                <p className="text-sm text-gray-600">By Difficulty</p>
                <div className="text-sm mt-1">
                  {Object.entries(stats.byDifficulty).map(([diff, count]) => (
                    <div key={diff} className="flex justify-between">
                      <span className="capitalize">{diff}:</span>
                      <span className="font-medium">{count}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* Filters */}
          <div className="flex gap-3 mb-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
              <Input
                placeholder="Search questions..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <select
              value={typeFilter}
              onChange={(e) => setTypeFilter(e.target.value)}
              className="px-3 py-2 border rounded-md"
            >
              <option value="all">All Types</option>
              <option value="MCQ">Multiple Choice</option>
              <option value="TRUE_FALSE">True/False</option>
              <option value="FILL_BLANK">Fill in Blank</option>
            </select>
            <select
              value={difficultyFilter}
              onChange={(e) => setDifficultyFilter(e.target.value)}
              className="px-3 py-2 border rounded-md"
            >
              <option value="all">All Difficulties</option>
              <option value="easy">Easy</option>
              <option value="medium">Medium</option>
              <option value="hard">Hard</option>
            </select>
          </div>

          {/* Questions List */}
          {filteredQuestions.length === 0 ? (
            <div className="text-center py-12 text-gray-500">
              {questions.length === 0
                ? "No questions found in this assessment"
                : "No questions match your filters"}
            </div>
          ) : (
            <div className="space-y-3">
              {filteredQuestions.map((question, index) => (
                <div
                  key={question.id}
                  className="border rounded-lg overflow-hidden"
                >
                  <div
                    className="p-4 bg-gray-50 cursor-pointer hover:bg-gray-100"
                    onClick={() => setExpandedQuestion(expandedQuestion === question.id ? null : question.id)}
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <span className="text-sm font-semibold text-blue-600">
                            Q{index + 1}
                          </span>
                          <Badge variant="outline" className="text-xs">
                            {getTypeLabel(question.questionType)}
                          </Badge>
                          <Badge className={`text-xs ${getDifficultyColor(question.difficulty)}`}>
                            {question.difficulty}
                          </Badge>
                          <span className="text-xs text-gray-500">
                            {question.points} pts
                          </span>
                        </div>
                        <p className="text-sm font-medium text-gray-900">
                          {question.questionText}
                        </p>
                      </div>
                      {expandedQuestion === question.id ? (
                        <ChevronUp className="w-5 h-5 text-gray-400" />
                      ) : (
                        <ChevronDown className="w-5 h-5 text-gray-400" />
                      )}
                    </div>
                  </div>

                  {expandedQuestion === question.id && (
                    <div className="p-4 border-t">
                      {/* Question Details */}
                      <div className="grid grid-cols-2 gap-4 mb-4">
                        <div>
                          <p className="text-xs text-gray-500">Topic</p>
                          <p className="text-sm font-medium">
                            {question.topic?.name || "N/A"}
                          </p>
                        </div>
                        <div>
                          <p className="text-xs text-gray-500">Category</p>
                          <p className="text-sm font-medium">
                            {question.topic?.category?.name || "N/A"}
                          </p>
                        </div>
                      </div>

                      {/* Options for MCQ */}
                      {question.questionType === "MCQ" && question.options && (
                        <div className="mb-4">
                          <p className="text-xs text-gray-500 mb-2">Options:</p>
                          <div className="space-y-2">
                            {question.options.map((option, idx) => (
                              <div
                                key={idx}
                                className={`p-2 rounded ${
                                  option.isCorrect ? "bg-green-50 border border-green-200" : "bg-gray-50"
                                }`}
                              >
                                <span className="text-sm">{option.text}</span>
                                {option.isCorrect && (
                                  <span className="ml-2 text-green-600 text-xs font-medium">
                                    ✓ Correct
                                  </span>
                                )}
                              </div>
                            ))}
                          </div>
                        </div>
                      )}

                      {/* Explanation */}
                      {question.explanation && (
                        <div className="bg-blue-50 p-3 rounded">
                          <p className="text-xs text-blue-600 font-medium mb-1">
                            Explanation:
                          </p>
                          <p className="text-sm text-gray-700">
                            {question.explanation}
                          </p>
                        </div>
                      )}

                      {/* Tags */}
                      {question.tags && question.tags.length > 0 && (
                        <div className="mt-3">
                          <div className="flex flex-wrap gap-1">
                            {question.tags.map((tag, idx) => (
                              <Badge key={idx} variant="secondary" className="text-xs">
                                {tag}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default QuestionViewerModal;