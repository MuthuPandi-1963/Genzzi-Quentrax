import React, { useState, useEffect } from "react";
import { Upload, X, Loader2 } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "../ui/dialog";
import { Button } from "../ui/button";
import { Input } from "../ui/input";
import { Label } from "../ui/label";
import { Textarea } from "../ui/textarea";
import { useCategories } from "../../hooks/useCategories";
import toast from "react-hot-toast";

const CLOUDINARY_UPLOAD_PRESET = import.meta.env.VITE_CLOUD_PRESET;
const CLOUDINARY_CLOUD_NAME = import.meta.env.VITE_CLOUD_NAME;
const CLOUDINARY_API_URL = `https://api.cloudinary.com/v1_1/${CLOUDINARY_CLOUD_NAME}/upload`;

const CategoryForm = ({ open, onOpenChange, category, onSuccess }) => {
  const isEditing = Boolean(category);

  const [previewImage, setPreviewImage] = useState(category?.imageUrl || "");
  const [isUploading, setIsUploading] = useState(false);

  const { createCategory, updateCategory } = useCategories();

  const isSubmitting = isEditing
    ? updateCategory.isPending
    : createCategory.isPending;

  const [formData, setFormData] = useState({
    name: category?.name || "",
    description: category?.description || "",
  });

  useEffect(() => {
    if (category) {
      setFormData({
        name: category.name || "",
        description: category.description || "",
      });
      setPreviewImage(category.imageUrl || "");
    } else {
      setFormData({ name: "", description: "" });
      setPreviewImage("");
    }
  }, [category]);

  const handleChange = (e) => {
    const { id, value } = e.target;
    setFormData({ ...formData, [id]: value });
  };

  const handleImageUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsUploading(true);

    try {
      const formDataCloud = new FormData();
      formDataCloud.append("file", file);
      formDataCloud.append("upload_preset", CLOUDINARY_UPLOAD_PRESET);

      const res = await fetch(CLOUDINARY_API_URL, {
        method: "POST",
        body: formDataCloud,
      });

      const data = await res.json();
      setPreviewImage(data.secure_url);
      toast.success("Image uploaded successfully!");
    } catch (err) {
      console.error(err);
      toast.error("Image upload failed!");
    } finally {
      setIsUploading(false);
    }
  };

  const onSubmit = (e) => {
    e.preventDefault();

    if (!formData.name.trim()) {
      toast.error("Category name is required");
      return;
    }

    const payload = {
      ...formData,
      imageUrl: previewImage,
    };

    if (isEditing) {
      updateCategory.mutate(
        { id: category.id, data: payload },
        {
          onSuccess: () => {
            toast.success("Category updated successfully!");
            onSuccess?.();
            onOpenChange(false);
          },
          onError: (err) =>
            toast.error(err.response?.data?.message || "Update failed!"),
        }
      );
    } else {
      createCategory.mutate(payload, {
        onSuccess: () => {
          toast.success("Category created successfully!");
          onSuccess?.();
          onOpenChange(false);
        },
        onError: (err) =>
          toast.error(err.response?.data?.message || "Create failed!"),
      });
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>
            {isEditing ? "Edit Category" : "Add New Category"}
          </DialogTitle>
          <DialogDescription>
            {isEditing
              ? "Update category information"
              : "Create a new quiz category"}
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={onSubmit} className="space-y-6">
          {/* Image Upload */}
          <div>
            <Label>Category Image</Label>
            <div className="mt-2 flex items-center gap-4">
              <div className="h-20 w-20 rounded-lg border-2 border-dashed border-muted-foreground/25 flex items-center justify-center">
                {previewImage ? (
                  <div className="relative">
                    <img
                      src={previewImage}
                      alt="Preview"
                      className="h-16 w-16 rounded object-cover"
                    />
                    <Button
                      type="button"
                      variant="destructive"
                      size="icon"
                      className="absolute -top-2 -right-2 h-5 w-5 rounded-full"
                      onClick={() => setPreviewImage("")}
                      disabled={isSubmitting}
                    >
                      <X className="h-3 w-3" />
                    </Button>
                  </div>
                ) : (
                  <Upload className="h-8 w-8 text-muted-foreground" />
                )}
              </div>

              <div>
                <Input
                  type="file"
                  accept="image/*"
                  onChange={handleImageUpload}
                  className="hidden"
                  id="upload"
                  disabled={isSubmitting}
                />
                <Button
                  type="button"
                  variant="outline"
                  disabled={isUploading || isSubmitting}
                >
                  <Label htmlFor="upload" className="cursor-pointer">
                    {isUploading ? "Uploading..." : "Upload Image"}
                  </Label>
                </Button>
                <p className="text-sm text-muted-foreground mt-1">
                  PNG, JPG up to 2MB
                </p>
              </div>
            </div>
          </div>

          {/* Category Name */}
          <div className="grid gap-y-2">
            <Label htmlFor="name">Category Name</Label>
            <Input
              id="name"
              placeholder="Enter a category name"
              value={formData.name}
              onChange={handleChange}
              disabled={isSubmitting}
            />
          </div>

          {/* Category Description */}
          <div className="grid gap-y-2">
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              rows={4}
              placeholder="Enter a category description"
              value={formData.description}
              onChange={handleChange}
              disabled={isSubmitting}
            />
          </div>

          {/* Actions */}
          <div className="flex justify-end gap-2">
            <Button
              type="button"
              variant="outline"
              onClick={() => onOpenChange(false)}
              disabled={isSubmitting}
            >
              Cancel
            </Button>

            <Button
              type="submit"
              disabled={isUploading || isSubmitting}
            >
              {isSubmitting && (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              )}
              {isSubmitting
                ? isEditing
                  ? "Updating..."
                  : "Creating..."
                : isEditing
                ? "Update Category"
                : "Create Category"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default CategoryForm;
