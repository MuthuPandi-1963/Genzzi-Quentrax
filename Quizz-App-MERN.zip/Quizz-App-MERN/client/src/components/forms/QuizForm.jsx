
import React, { useState, useEffect } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectTrigger,
  SelectValue,
  SelectContent,
  SelectItem,
} from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Loader2 } from "lucide-react";
import { useQuizzes } from "../../hooks/useQuizzes";
import { useTopics } from "../../hooks/useTopics";
import { useSelector } from "react-redux";
import toast from "react-hot-toast";

const QuizForm = ({ quiz, onClose }) => {
  const { createQuiz, updateQuiz } = useQuizzes();
  const { topics } = useTopics();
  const { user } = useSelector((state) => state.user);

  const isEditing = Boolean(quiz?.id);

  const isSubmitting = isEditing
    ? updateQuiz.isPending
    : createQuiz.isPending;

  const [form, setForm] = useState({
    title: "",
    description: "",
    totalPoints: 0,
    status: "active",
    tags: [],
    timeLimit: 10,
    imageUrl: "",
    creatorId: user.id,
    topicId: "",
  });

  useEffect(() => {
    if (quiz) {
      setForm({
        title: quiz.title || "",
        description: quiz.description || "",
        totalPoints: quiz.totalPoints || 0,
        status: quiz.status || "active",
        tags: quiz.tags || [],
        timeLimit: quiz.timeLimit || 10,
        imageUrl: quiz.imageUrl || "",
        creatorId: quiz.creatorId,
        topicId: quiz.topicId || "",
      });
    }
  }, [quiz]);

  const handleTagChange = (e) =>
    setForm({
      ...form,
      tags: e.target.value.split(",").map((tag) => tag.trim()),
    });

  const handleSubmit = () => {
    if (!form.title.trim()) {
      toast.error("Quiz title is required");
      return;
    }
    if (!form.topicId) {
      toast.error("Please select a topic");
      return;
    }

    const payload = {
      ...form,
      totalPoints: Number(form.totalPoints),
      timeLimit: Number(form.timeLimit),
    };

    if (isEditing) {
      updateQuiz.mutate(
        { id: quiz.id, payload },
        {
          onSuccess: (res) => {
            toast.success(res?.data?.message || "Quiz updated successfully");
            onClose();
          },
          onError: () => {
            toast.error("Failed to update quiz");
          },
        }
      );
    } else {
      createQuiz.mutate(payload, {
        onSuccess: (res) => {
          toast.success(res?.data?.message || "Quiz created successfully");
          onClose();
        },
        onError: () => {
          toast.error("Failed to create quiz");
        },
      });
    }
  };

  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md max-h-[90vh] overflow-y-auto bg-white text-gray-800">
        <DialogHeader className="pb-2">
          <DialogTitle className="text-lg font-semibold">
            {isEditing ? "Edit Quiz" : "Create Quiz"}
          </DialogTitle>
        </DialogHeader>

        <div className="grid gap-3 text-sm">
          <div>
            <Label className="text-gray-900 font-medium">Title</Label>
            <Input
              className="h-9 mt-1"
              placeholder="Enter quiz title"
              value={form.title}
              onChange={(e) =>
                setForm({ ...form, title: e.target.value })
              }
              disabled={isSubmitting}
            />
          </div>

          <div>
            <Label className="text-gray-900 font-medium">Description</Label>
            <Textarea
              className="min-h-[60px] mt-1"
              placeholder="Enter description"
              value={form.description}
              onChange={(e) =>
                setForm({ ...form, description: e.target.value })
              }
              disabled={isSubmitting}
            />
          </div>

          <div>
            <Label className="text-gray-900 font-medium">Topic</Label>
            <Select
              value={form.topicId}
              onValueChange={(value) =>
                setForm({ ...form, topicId: value })
              }
              disabled={isSubmitting}
            >
              <SelectTrigger className="h-9 mt-1">
                <SelectValue placeholder="Select topic" />
              </SelectTrigger>
              <SelectContent>
                {topics.data?.map((t) => (
                  <SelectItem key={t.id} value={t.id}>
                    {t.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label className="text-gray-900 font-medium">Time (mins)</Label>
              <Input
                type="number"
                className="h-9 mt-1"
                value={form.timeLimit}
                onChange={(e) =>
                  setForm({
                    ...form,
                    timeLimit: parseInt(e.target.value) || 0,
                  })
                }
                disabled={isSubmitting}
              />
            </div>
            <div>
              <Label className="text-gray-900 font-medium">Points</Label>
              <Input
                type="number"
                className="h-9 mt-1"
                value={form.totalPoints}
                onChange={(e) =>
                  setForm({
                    ...form,
                    totalPoints: parseInt(e.target.value) || 0,
                  })
                }
                disabled={isSubmitting}
              />
            </div>
          </div>

          <div>
            <Label className="text-gray-900 font-medium">Tags</Label>
            <Input
              className="h-9 mt-1"
              placeholder="math, algebra, easy"
              value={form.tags.join(", ")}
              onChange={handleTagChange}
              disabled={isSubmitting}
            />
          </div>

          <div>
            <Label className="text-gray-900 font-medium">Image URL</Label>
            <Input
              type="url"
              className="h-9 mt-1"
              placeholder="https://example.com/image.png"
              value={form.imageUrl}
              onChange={(e) =>
                setForm({ ...form, imageUrl: e.target.value })
              }
              disabled={isSubmitting}
            />
          </div>

          <div>
            <Label className="text-gray-900 font-medium">Status</Label>
            <Select
              value={form.status}
              onValueChange={(value) =>
                setForm({ ...form, status: value })
              }
              disabled={isSubmitting}
            >
              <SelectTrigger className="h-9 mt-1">
                <SelectValue placeholder="Select status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="active">Active</SelectItem>
                <SelectItem value="inactive">Inactive</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <DialogFooter className="pt-3">
          <Button
            variant="outline"
            className="h-9 text-gray-900 border-gray-300"
            onClick={onClose}
            disabled={isSubmitting}
          >
            Cancel
          </Button>

          <Button
            className="h-9 bg-blue-600 hover:bg-blue-700 text-white"
            onClick={handleSubmit}
            disabled={isSubmitting}
          >
            {isSubmitting && (
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            )}
            {isSubmitting
              ? isEditing
                ? "Updating..."
                : "Creating..."
              : isEditing
              ? "Update"
              : "Create"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default QuizForm;
