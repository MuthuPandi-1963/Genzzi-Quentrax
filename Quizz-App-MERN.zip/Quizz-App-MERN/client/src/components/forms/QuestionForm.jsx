// pages/QuestionForm.tsx
import React, { useState, useEffect } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectTrigger,
  SelectValue,
  SelectContent,
  SelectItem,
} from "@/components/ui/select";
import { Plus, Minus, Loader2 } from "lucide-react";
import { useQuestions } from "../../hooks/useQuestions";
import { useTopics } from "../../hooks/useTopics";
import toast from "react-hot-toast";

const QuestionForm = ({ question, onClose }) => {
  const { createQuestion, updateQuestion } = useQuestions();
  const { topics: { data: topics = [] } = {} } = useTopics();

  const isEditing = Boolean(question?.id);

  const isSubmitting = isEditing
    ? updateQuestion.isPending
    : createQuestion.isPending;

  const [form, setForm] = useState({
    questionText: "",
    questionType: "MCQ",
    difficulty: "easy",
    points: 1,
    topicId: "",
    status: "active",
    options: [{ text: "", isCorrect: true }],
    correctAnswer: "",
    tags: [],
    hints: [],
    explanation: "",
  });

  useEffect(() => {
    if (question?.questionText) {
      setForm({
        questionText: question.questionText,
        questionType: question.questionType,
        difficulty: question.difficulty,
        points: question.points,
        topicId: question.topicId,
        status: question.status,
        options: question.options || [{ text: "", isCorrect: true }],
        correctAnswer: question.correctAnswer || "",
        tags: question.tags || [],
        hints: question.hints || [],
        explanation: question.explanation || "",
      });
    }
  }, [question]);

  const handleAddOption = () => {
    if (form.options.length < 4) {
      setForm({
        ...form,
        options: [...form.options, { text: "", isCorrect: false }],
      });
    }
  };

  const handleRemoveOption = (idx) => {
    if (form.options.length > 2) {
      const newOptions = [...form.options];
      newOptions.splice(idx, 1);
      setForm({ ...form, options: newOptions });
    }
  };

  const handleOptionChange = (idx, value) => {
    const newOptions = [...form.options];
    newOptions[idx].text = value;
    setForm({ ...form, options: newOptions });
  };

  const handleCorrectOption = (idx) => {
    const newOptions = form.options.map((opt, i) => ({
      ...opt,
      isCorrect: i === idx,
    }));
    setForm({ ...form, options: newOptions });
  };

  const handleSubmit = () => {
    if (!form.topicId) {
      toast.error("Please choose a Topic name");
      return;
    }

    const payload = {
      questionText: form.questionText,
      questionType: form.questionType,
      difficulty: form.difficulty,
      points: form.points,
      topicId: form.topicId,
      status: form.status,
      options:
        form.questionType !== "FILL_BLANK" ? form.options : undefined,
      correctAnswer:
        form.questionType === "FILL_BLANK"
          ? form.correctAnswer
          : undefined,
      tags: form.tags,
      hints: form.hints,
      explanation: form.explanation,
    };

    if (isEditing) {
      updateQuestion.mutate(
        { id: question.id, payload },
        {
          onSuccess: (res) => {
            toast.success(res?.data?.message || "Question updated successfully");
            onClose();
          },
          onError: () => {
            toast.error("Something occurred, please try again");
          },
        }
      );
    } else {
      createQuestion.mutate(payload, {
        onSuccess: (res) => {
          toast.success(res?.data?.message || "Question added successfully");
          onClose();
        },
        onError: () => {
          toast.error("Something occurred, please try again");
        },
      });
    }
  };

  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent className="sm:max-w-lg max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>
            {isEditing ? "Edit Question" : "Add Question"}
          </DialogTitle>
        </DialogHeader>

        <div className="grid gap-3 py-4">
          <Input
            placeholder="Question Text"
            value={form.questionText}
            onChange={(e) =>
              setForm({ ...form, questionText: e.target.value })
            }
            disabled={isSubmitting}
          />

          <div className="flex gap-2 flex-wrap">
            <Select
              value={form.questionType}
              onValueChange={(value) =>
                setForm({ ...form, questionType: value })
              }
              disabled={isSubmitting}
            >
              <SelectTrigger className="min-w-[120px]">
                <SelectValue placeholder="Type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="MCQ">MCQ</SelectItem>
                <SelectItem value="TRUE_FALSE">True/False</SelectItem>
                <SelectItem value="FILL_BLANK">Fill Blank</SelectItem>
              </SelectContent>
            </Select>

            <Select
              value={form.difficulty}
              onValueChange={(value) =>
                setForm({ ...form, difficulty: value })
              }
              disabled={isSubmitting}
            >
              <SelectTrigger className="min-w-[120px]">
                <SelectValue placeholder="Difficulty" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="easy">Beginner</SelectItem>
                <SelectItem value="medium">Intermediate</SelectItem>
                <SelectItem value="hard">Advanced</SelectItem>
              </SelectContent>
            </Select>

            <Select
              value={form.topicId}
              onValueChange={(value) =>
                setForm({ ...form, topicId: value })
              }
              disabled={isSubmitting}
            >
              <SelectTrigger className="min-w-[150px]">
                <SelectValue placeholder="Topic" />
              </SelectTrigger>
              <SelectContent>
                {topics.map((t) => (
                  <SelectItem key={t.id} value={t.id}>
                    {t.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <Input
            type="number"
            placeholder="Points"
            value={form.points}
            onChange={(e) =>
              setForm({ ...form, points: parseInt(e.target.value) || 0 })
            }
            disabled={isSubmitting}
          />

          {/* Options */}
          {form.questionType !== "FILL_BLANK" && (
            <div>
              <label className="font-medium mb-1 block">Options</label>
              {form.options.map((opt, idx) => (
                <div key={idx} className="flex gap-2 items-center mb-2">
                  <input
                    type="text"
                    placeholder={`Option ${idx + 1}`}
                    value={opt.text}
                    onChange={(e) =>
                      handleOptionChange(idx, e.target.value)
                    }
                    className="flex-1 border rounded px-2 py-1"
                    disabled={isSubmitting || form.questionType === "TRUE_FALSE"}
                  />
                  <input
                    type="radio"
                    checked={opt.isCorrect}
                    onChange={() => handleCorrectOption(idx)}
                    disabled={isSubmitting}
                  />
                  {form.questionType === "MCQ" && (
                    <>
                      <button
                        type="button"
                        onClick={() => handleRemoveOption(idx)}
                        disabled={
                          isSubmitting || form.options.length <= 2
                        }
                        className="text-red-500 disabled:opacity-50"
                      >
                        <Minus />
                      </button>
                      {idx === form.options.length - 1 &&
                        form.options.length < 4 && (
                          <button
                            type="button"
                            onClick={handleAddOption}
                            disabled={isSubmitting}
                            className="text-green-500"
                          >
                            <Plus />
                          </button>
                        )}
                    </>
                  )}
                </div>
              ))}
            </div>
          )}

          {form.questionType === "FILL_BLANK" && (
            <Input
              placeholder="Correct Answer"
              value={form.correctAnswer}
              onChange={(e) =>
                setForm({ ...form, correctAnswer: e.target.value })
              }
              disabled={isSubmitting}
            />
          )}

          <Textarea
            placeholder="Explanation"
            value={form.explanation}
            onChange={(e) =>
              setForm({ ...form, explanation: e.target.value })
            }
            disabled={isSubmitting}
          />

          <Textarea
            placeholder="Tags (comma separated)"
            value={form.tags.join(", ")}
            onChange={(e) =>
              setForm({
                ...form,
                tags: e.target.value.split(",").map((t) => t.trim()),
              })
            }
            disabled={isSubmitting}
          />

          <Textarea
            placeholder="Hints (comma separated)"
            value={form.hints.join(", ")}
            onChange={(e) =>
              setForm({
                ...form,
                hints: e.target.value.split(",").map((t) => t.trim()),
              })
            }
            disabled={isSubmitting}
          />
        </div>

        <DialogFooter className="flex justify-end gap-2">
          <Button variant="outline" onClick={onClose} disabled={isSubmitting}>
            Cancel
          </Button>
          <Button onClick={handleSubmit} disabled={isSubmitting}>
            {isSubmitting && (
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            )}
            {isSubmitting
              ? isEditing
                ? "Updating..."
                : "Creating..."
              : isEditing
              ? "Update"
              : "Create"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default QuestionForm;
