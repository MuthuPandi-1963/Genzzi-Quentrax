import React, { useState, useEffect } from "react";
import { Upload, X, Loader2 } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "../ui/dialog";
import { Button } from "../ui/button";
import { Input } from "../ui/input";
import { Label } from "../ui/label";
import { Textarea } from "../ui/textarea";
import { useCategories } from "../../hooks/useCategories";
import { useTopics } from "../../hooks/useTopics";
import toast from "react-hot-toast";

const CLOUDINARY_UPLOAD_PRESET = import.meta.env.VITE_CLOUD_PRESET;
const CLOUDINARY_CLOUD_NAME = import.meta.env.VITE_CLOUD_NAME;
const CLOUDINARY_API_URL = `https://api.cloudinary.com/v1_1/${CLOUDINARY_CLOUD_NAME}/upload`;

const TopicForm = ({ open, onOpenChange, topic, onSuccess }) => {
  const isEditing = !!topic;

  const [formData, setFormData] = useState({
    name: topic?.name || "",
    description: topic?.description || "",
    categoryId: topic?.categoryId || "",
    difficulty: topic?.difficulty || "medium",
    tags: topic?.tags?.join(",") || "",
  });

  const [previewImage, setPreviewImage] = useState(topic?.imageUrl || "");
  const [isUploading, setIsUploading] = useState(false);

  const { categories } = useCategories();
  const { createTopic, updateTopic } = useTopics();

  const isSubmitting = isEditing
    ? updateTopic.isPending
    : createTopic.isPending;

  useEffect(() => {
    if (topic) {
      setFormData({
        name: topic.name,
        description: topic.description || "",
        categoryId: topic.categoryId,
        difficulty: topic.difficulty || "medium",
        tags: topic.tags?.join(",") || "",
      });
      setPreviewImage(topic.imageUrl || "");
    }
  }, [topic]);

  const handleChange = (e) => {
    const { id, value } = e.target;
    setFormData({ ...formData, [id]: value });
  };

  const handleImageUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsUploading(true);

    try {
      const formDataCloud = new FormData();
      formDataCloud.append("file", file);
      formDataCloud.append("upload_preset", CLOUDINARY_UPLOAD_PRESET);

      const res = await fetch(CLOUDINARY_API_URL, {
        method: "POST",
        body: formDataCloud,
      });

      const data = await res.json();
      setPreviewImage(data.secure_url);
      toast.success("Image uploaded successfully!");
    } catch (err) {
      console.error(err);
      toast.error("Image upload failed!");
    } finally {
      setIsUploading(false);
    }
  };

  const onSubmit = (e) => {
    e.preventDefault();

    if (!formData.name.trim()) {
      toast.error("Topic name is required");
      return;
    }
    if (!formData.categoryId) {
      toast.error("Category is required");
      return;
    }

    const payload = {
      ...formData,
      imageUrl: previewImage,
      tags: formData.tags
        .split(",")
        .map((t) => t.trim())
        .filter(Boolean),
    };

    if (isEditing) {
      updateTopic.mutate(
        { id: topic.id, data: payload },
        {
          onSuccess: () => {
            toast.success("Topic updated successfully!");
            onSuccess?.();
            onOpenChange(false);
          },
          onError: (err) =>
            toast.error(err.response?.data?.message || "Update failed!"),
        }
      );
    } else {
      createTopic.mutate(payload, {
        onSuccess: () => {
          toast.success("Topic created successfully!");
          onSuccess?.();
          onOpenChange(false);
        },
        onError: (err) =>
          toast.error(err.response?.data?.message || "Create failed!"),
      });
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>{isEditing ? "Edit Topic" : "Add New Topic"}</DialogTitle>
          <DialogDescription>
            {isEditing ? "Update topic information" : "Create a new topic"}
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={onSubmit} className="space-y-6">
          {/* Image Upload */}
          <div>
            <Label>Topic Image</Label>
            <div className="mt-2 flex items-center gap-4">
              <div className="h-20 w-20 rounded-lg border-2 border-dashed border-muted-foreground/25 flex items-center justify-center">
                {previewImage ? (
                  <div className="relative">
                    <img
                      src={previewImage}
                      alt="Preview"
                      className="h-16 w-16 rounded object-cover"
                    />
                    <Button
                      type="button"
                      variant="destructive"
                      size="icon"
                      className="absolute -top-2 -right-2 h-5 w-5 rounded-full"
                      onClick={() => setPreviewImage("")}
                    >
                      <X className="h-3 w-3" />
                    </Button>
                  </div>
                ) : (
                  <Upload className="h-8 w-8 text-muted-foreground" />
                )}
              </div>

              <div>
                <Input
                  type="file"
                  accept="image/*"
                  onChange={handleImageUpload}
                  className="hidden"
                  id="upload"
                />
                <Button type="button" variant="outline" disabled={isUploading}>
                  <Label htmlFor="upload" className="cursor-pointer">
                    {isUploading ? "Uploading..." : "Upload Image"}
                  </Label>
                </Button>
                <p className="text-sm text-muted-foreground mt-1">
                  PNG, JPG up to 2MB
                </p>
              </div>
            </div>
          </div>

          {/* Topic Name */}
          <div className="grid gap-y-2">
            <Label htmlFor="name">Topic Name</Label>
            <Input
              id="name"
              placeholder="Enter topic name"
              value={formData.name}
              onChange={handleChange}
              disabled={isSubmitting}
            />
          </div>

          {/* Category */}
          <div className="grid gap-y-2">
            <Label htmlFor="categoryId">Category</Label>
            <select
              id="categoryId"
              className="p-2 border rounded"
              value={formData.categoryId}
              onChange={handleChange}
              disabled={isSubmitting}
            >
              <option value="">Select Category</option>
              {categories?.data?.map((cat) => (
                <option key={cat.id} value={cat.id}>
                  {cat.name}
                </option>
              ))}
            </select>
          </div>

          {/* Description */}
          <div className="grid gap-y-2">
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              rows={4}
              placeholder="Enter topic description"
              value={formData.description}
              onChange={handleChange}
              disabled={isSubmitting}
            />
          </div>

          {/* Difficulty */}
          <div className="grid gap-y-2">
            <Label htmlFor="difficulty">Difficulty</Label>
            <select
              id="difficulty"
              className="p-2 border rounded"
              value={formData.difficulty}
              onChange={handleChange}
              disabled={isSubmitting}
            >
              <option value="easy">Easy</option>
              <option value="medium">Medium</option>
              <option value="hard">Hard</option>
            </select>
          </div>

          {/* Tags */}
          <div className="grid gap-y-2">
            <Label htmlFor="tags">Tags (comma separated)</Label>
            <Input
              id="tags"
              placeholder="e.g. react, javascript, frontend"
              value={formData.tags}
              onChange={handleChange}
              disabled={isSubmitting}
            />
          </div>

          {/* Submit */}
          <div className="flex justify-end gap-2">
            <Button
              type="button"
              variant="outline"
              onClick={() => onOpenChange(false)}
              disabled={isSubmitting}
            >
              Cancel
            </Button>

            <Button
              type="submit"
              disabled={isUploading || isSubmitting}
            >
              {isSubmitting && (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              )}
              {isSubmitting
                ? isEditing
                  ? "Updating..."
                  : "Creating..."
                : isEditing
                ? "Update Topic"
                : "Create Topic"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default TopicForm;
