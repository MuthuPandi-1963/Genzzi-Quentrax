import React, { useState, useEffect } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { getQuestionByTopicId } from "../../hooks/useQuestions";
import { useAddQuestionsInQuiz } from "../../hooks/useQuizzes";
import toast from "react-hot-toast";

const QuizQuestionForm = ({ quiz, onClose }) => {
  const addQuestionsMutation = useAddQuestionsInQuiz(quiz?.id);

  // Fetch questions for this quiz's topic
  const { data, isLoading: loadingTopicQuestions } = getQuestionByTopicId(
    quiz?.topicId
  );
  const topicQuestions = data?.data?.data || [];

  const [selectedQuestions, setSelectedQuestions] = useState([]);

  // Initialize with existing quiz questions
  useEffect(() => {
    if (quiz?.questions) {
      setSelectedQuestions(quiz.questions);
    }
  }, [quiz]);

  // Toggle picking an existing question
  const toggleQuestion = (question) => {
    if (selectedQuestions.find((q) => q.id === question.id)) {
      setSelectedQuestions(
        selectedQuestions.filter((q) => q.id !== question.id)
      );
    } else {
      setSelectedQuestions([...selectedQuestions, question]);
    }
  };

  // Submit selected questions to backend
  const handleSubmit = () => {
    if (!quiz?.id || selectedQuestions.length === 0) return;

    const payload = selectedQuestions.map((q) => q.id);

    addQuestionsMutation.mutate(payload, {
      onSuccess: () => {
        toast.success("Questions added successfully!");
        onClose();
      },
      onError: (err) => {
        console.error("Error adding questions:", err);
        toast.error("Failed to add questions");
      },
    });
  };

  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent className="sm:max-w-lg max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Select Questions for: {quiz?.title}</DialogTitle>
        </DialogHeader>

        <div className="grid gap-4 py-4">
          {/* Existing Topic Questions */}
          <div className="border p-3 rounded">
            <p className="font-medium mb-2">Pick Existing Questions:</p>
            {loadingTopicQuestions ? (
              <p className="text-gray-500">Loading existing questions...</p>
            ) : topicQuestions.length === 0 ? (
              <p className="text-gray-500">
                No questions found for this topic.
              </p>
            ) : (
              topicQuestions.map((q) => (
                <div key={q.id} className="flex items-center gap-2 mb-1">
                  <input
                    type="checkbox"
                    checked={selectedQuestions.some((sq) => sq.id === q.id)}
                    onChange={() => toggleQuestion(q)}
                    disabled={addQuestionsMutation.isPending}
                  />
                  <span>{q.questionText}</span>
                </div>
              ))
            )}
          </div>
        </div>

        <DialogFooter className="flex gap-2">
          <Button
            variant="outline"
            onClick={onClose}
            disabled={addQuestionsMutation.isPending}
          >
            Close
          </Button>
          <Button
            onClick={handleSubmit}
            disabled={
              selectedQuestions.length === 0 || addQuestionsMutation.isPending
            }
          >
            {addQuestionsMutation.isPending ? "Adding..." : "Add Selected Questions"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default QuizQuestionForm;
