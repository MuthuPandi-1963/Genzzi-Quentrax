import path from "path"
import tailwindcss from "@tailwindcss/vite"
import react from "@vitejs/plugin-react"
import { defineConfig } from "vite"


export default defineConfig({
  base: "/",                 // ⭐ REQUIRED
  plugins: [react(), tailwindcss()],
  resolve: {
    alias: {
      "@": path.resolve(__dirname, "./src"),
    },
  },
  build: {
    outDir: "dist",           // ⭐ MUST be dist
    emptyOutDir: true,
  },

  server :{
    port : 5000,
    open : true,
    strictPort : true
  }
})
