# TODO

- [ ] Fix Vite error: missing `@/assets/signup.jpg` import used in `src/pages/auth/Login.jsx` and `src/pages/auth/Signup.jsx`.
- [ ] Update imports to point to an existing asset in `src/assets`.
- [ ] Restart Vite/dev server and verify login/signup pages compile.

