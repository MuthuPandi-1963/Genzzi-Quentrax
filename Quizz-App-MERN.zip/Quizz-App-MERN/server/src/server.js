import express from "express";
import dotenv from "dotenv";
import helmet from "helmet";
import cors from "cors";
import rateLimit from "express-rate-limit";
import cookieParser from "cookie-parser";

import httpLogger from "./middlewares/httpLogger.js";
import logger from "./utils/logger.js";
import { globalErrorHandler } from "./middlewares/globalErrorHandler.js";

import { connectDB } from "./config/prisma.js";

import categoryRoutes from "./routes/categories.routes.js";
import topicsRoutes from "./routes/topics.routes.js";
import questionsRoutes from "./routes/questions.routes.js";
import quizRoutes from "./routes/quiz.routes.js";
import userRoutes from "./routes/users.routes.js";
import quizHistoryRoutes from "./routes/quizHistory.routes.js";
import AuthRoutes from "./routes/user.routes.js";
import dashboardRoutes from "./routes/dashboard.routes.js";
import assessmentRoutes from "./routes/assessments.routes.js";
import assessmentAssignableRoutes from "./routes/assessmentAssignable.routes.js";
import assessmentAssignmentCompatRoutes from "./routes/assessmentAssignmentCompat.routes.js";
import monitoringRoutes from "./routes/monitoring.routes.js";

dotenv.config();



const app = express();

/* ---------------------------
   0. TRUST PROXY (VERY IMPORTANT)
---------------------------- */
app.set("trust proxy", 1);

/* ---------------------------
   1. SECURITY HEADERS
---------------------------- */
app.use(helmet());

/* ---------------------------
   2. CORS (BEFORE BODY & COOKIES)
---------------------------- */
app.use(
  cors({
    origin: [process.env.FRONTEND_URL, process.env.ADMIN_URL],
    credentials: true,
    methods: ["GET", "POST", "PUT", "PATCH", "DELETE"],
  })
);


app.use(express.urlencoded({ extended: true }));
app.use(express.json({ limit: "10kb" }));


app.use(cookieParser());

app.use(httpLogger);

const apiLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 100,
  standardHeaders: true,
  legacyHeaders: false,
  message: {
    success: false,
    message: "Too many requests, please try again later.",
  },
});
app.use("/api", apiLimiter);

/* ---------------------------
   7. ROUTES
---------------------------- */
app.get("/", (req, res) => {
  res.status(200).json({ message: "API is running..." });
});

app.use("/api/categories", categoryRoutes);
app.use("/api/topics", topicsRoutes);
app.use("/api/questions", questionsRoutes);
app.use("/api/quizzes", quizRoutes);
app.use("/api/quiz/history", quizHistoryRoutes);
app.use("/api/users", userRoutes);
app.use("/api/auth", AuthRoutes);
app.use("/api/dashboard", dashboardRoutes);
app.use("/api/assessments", assessmentRoutes);
app.use("/api/assessments", assessmentAssignableRoutes);
app.use("/api/assessments", assessmentAssignmentCompatRoutes);
app.use("/api", monitoringRoutes);

app.use(globalErrorHandler);


const PORT = process.env.PORT || 5000;

app.listen(PORT, async () => {
  logger.info(
    { port: PORT, env: process.env.NODE_ENV },
    "Server running"
  );
  await connectDB();
});

