import { PrismaClient } from "@prisma/client";
import logger from "../utils/logger.js";

const prisma = new PrismaClient();

/**
 * Connect to the Prisma database
 */
export const connectDB = async () => {
  try {
    await prisma.$connect();
    logger.info(" Database connected successfully");
  } catch (error) {
    logger.error({ error }, "❌ Database connection failed");
    process.exit(1); // Exit process if DB fails
  }
};

/**
 * Gracefully disconnect Prisma on shutdown
 */
export const disconnectDB = async () => {
  try {
    await prisma.$disconnect();
    logger.info(" Database disconnected successfully");
  } catch (error) {
    logger.error({ error }, "❌ Error disconnecting database");
  }
};

export { prisma};
