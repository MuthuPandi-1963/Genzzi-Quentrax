import { asyncHandler } from "../../middlewares/asyncHandler.js";
import { prisma } from "../../config/prisma.js";

const userSelect = { id: true, name: true, email: true, role: true, avatar: true };

export const getAdminDashboard = asyncHandler(async (req, res) => {
  const [
    totalStudents,
    totalStaff,
    totalQuizzes,
    activeAssessments,
    totalAttempts,
    recentAttempts,
    topPerformers,
  ] = await Promise.all([
    prisma.user.count({ where: { role: "STUDENT" } }),
    prisma.user.count({ where: { role: { in: ["STAFF", "ADMIN"] } } }),
    prisma.quiz.count(),
    prisma.assessment.count({ where: { status: "ACTIVE" } }),
    prisma.quizHistory.count(),
    prisma.quizHistory.findMany({
      take: 8,
      orderBy: { completedAt: "desc" },
      include: {
        user: { select: userSelect },
        quiz: { select: { id: true, title: true } },
      },
    }),
    prisma.quizHistory.groupBy({
      by: ["userId"],
      _avg: { score: true },
      _count: { score: true },
      orderBy: { _avg: { score: "desc" } },
      take: 5,
    }),
  ]);

  const topUserIds = topPerformers.map((t) => t.userId);
  const topUsers = await prisma.user.findMany({
    where: { id: { in: topUserIds } },
    select: userSelect,
  });

  const leaderboard = topPerformers.map((t) => ({
    user: topUsers.find((u) => u.id === t.userId),
    avgScore: Math.round(t._avg.score ?? 0),
    attempts: t._count.score,
  }));

  res.json({
    success: true,
    data: {
      totalStudents,
      totalStaff,
      totalQuizzes,
      activeAssessments,
      totalAttempts,
      completionRate:
        totalStudents > 0
          ? Math.round((totalAttempts / totalStudents) * 10) / 10
          : 0,
      recentAttempts,
      topPerformers: leaderboard,
    },
  });
});

export const getStaffDashboard = asyncHandler(async (req, res) => {
  const creatorId = req.user.id;
  const [myQuizzes, myAssessments, students, pendingAssignments] =
    await Promise.all([
      prisma.quiz.count({ where: { creatorId } }),
      prisma.assessment.count({ where: { creatorId } }),
      prisma.user.count({ where: { role: "STUDENT" } }),
      prisma.assessmentAssignment.count({
        where: {
          assessment: { creatorId, status: "ACTIVE" },
          user: { quizHistory: { none: {} } },
        },
      }),
    ]);

  const recentAttempts = await prisma.quizHistory.findMany({
    take: 6,
    orderBy: { completedAt: "desc" },
    include: {
      user: { select: userSelect },
      quiz: { select: { title: true } },
    },
  });

  res.json({
    success: true,
    data: {
      myQuizzes,
      myAssessments,
      totalStudents: students,
      pendingAssignments,
      recentAttempts,
    },
  });
});

export const getStudentDashboard = asyncHandler(async (req, res) => {
  const userId = req.user.id;
  const [history, assignedAssessments, rankData] = await Promise.all([
    prisma.quizHistory.findMany({
      where: { userId },
      orderBy: { completedAt: "desc" },
      take: 10,
      include: { quiz: { select: { title: true, topicId: true } } },
    }),
    prisma.assessmentAssignment.findMany({
      where: { userId },
      include: {
        assessment: {
          include: { quiz: { select: { title: true, timeLimit: true } } },
        },
      },
    }),
    prisma.quizHistory.groupBy({
      by: ["userId"],
      _avg: { score: true },
      orderBy: { _avg: { score: "desc" } },
    }),
  ]);

  const myRank =
    rankData.findIndex((r) => r.userId === userId) >= 0
      ? rankData.findIndex((r) => r.userId === userId) + 1
      : null;
  const avgScore =
    history.length > 0
      ? Math.round(history.reduce((s, h) => s + h.score, 0) / history.length)
      : 0;

  res.json({
    success: true,
    data: {
      recentAttempts: history,
      assignedAssessments,
      rank: myRank,
      totalAttempts: history.length,
      avgScore,
    },
  });
});

export const getAnalytics = asyncHandler(async (req, res) => {
  const role = req.user.role;
  const whereQuiz =
    role === "STAFF" ? { creatorId: req.user.id } : undefined;

  const [attemptsByDay, passFail, topicPerformance] = await Promise.all([
    prisma.quizHistory.findMany({
      where: whereQuiz
        ? { quiz: whereQuiz }
        : undefined,
      select: { score: true, completedAt: true },
      orderBy: { completedAt: "desc" },
      take: 100,
    }),
    prisma.quizHistory.groupBy({
      by: ["quizId"],
      _avg: { score: true },
      _count: { score: true },
    }),
    prisma.quizHistory.findMany({
      take: 50,
      include: {
        quiz: { include: { topic: { select: { name: true } } } },
      },
    }),
  ]);

  const passFailRatio = {
    pass: attemptsByDay.filter((a) => a.score >= 60).length,
    fail: attemptsByDay.filter((a) => a.score < 60).length,
  };

  const topicMap = {};
  topicPerformance.forEach((h) => {
    const name = h.quiz?.topic?.name || "General";
    if (!topicMap[name]) topicMap[name] = { total: 0, count: 0 };
    topicMap[name].total += h.score;
    topicMap[name].count += 1;
  });

  const topicStats = Object.entries(topicMap).map(([topic, v]) => ({
    topic,
    avgScore: Math.round(v.total / v.count),
  }));

  res.json({
    success: true,
    data: {
      passFailRatio,
      quizParticipation: passFail,
      topicPerformance: topicStats,
      recentScores: attemptsByDay.slice(0, 20).map((a) => ({
        score: a.score,
        date: a.completedAt,
      })),
    },
  });
});
