import { prisma } from "../../config/prisma.js";

/**
 * Record a user's quiz attempt (create QuizHistory)
 */
export const createQuizHistory = async (req, res) => {
  try {
    const userId = req.user?.id || req.body.userId;
    const { quizId, score, answers } = req.body;

    if (!userId || !quizId || score === undefined || !answers) {
      return res.status(400).json({
        success: false,
        message: "userId, quizId, score, and answers are required",
      });
    }

    const history = await prisma.quizHistory.create({
      data: {
        userId,
        quizId,
        score,
        answers: JSON.stringify(answers),
      },
    });

    return res.status(201).json({
      success: true,
      message: "Quiz attempt recorded successfully",
      data: history,
    });
  } catch (error) {
    console.error("QuizHistory creation error:", error);
    return res.status(500).json({
      success: false,
      message: "Internal server error",
      error: error.message,
    });
  }
};

/**
 * Fetch all quiz history for a user
 */
export const getUserQuizHistory = async (req, res) => {
  try {
    const { userId } = req.params;

    const history = await prisma.quizHistory.findMany({
      where: { userId },
      include: {
        quiz: {
          select: { id: true, title: true, description: true, totalPoints: true },
        },
      },
      orderBy: { completedAt: "desc" },
    });

    return res.status(200).json({
      success: true,
      message: "User quiz history fetched successfully",
      count: history.length,
      data: history,
    });
  } catch (error) {
    console.error("Fetch user quiz history error:", error);
    return res.status(500).json({
      success: false,
      message: "Internal server error",
      error: error.message,
    });
  }
};

/**
 * Fetch a specific quiz history by ID
 */
export const getQuizHistoryById = async (req, res) => {
  try {
    const { id } = req.params;

    const history = await prisma.quizHistory.findUnique({
      where: { id },
      include: {
        user: { select: { id: true, name: true, email: true } },
        quiz: { select: { id: true, title: true, description: true } },
      },
    });

    if (!history) {
      return res.status(404).json({
        success: false,
        message: "Quiz history not found",
      });
    }

    return res.status(200).json({
      success: true,
      message: "Quiz history fetched successfully",
      data: history,
    });
  } catch (error) {
    console.error("Fetch quiz history by ID error:", error);
    return res.status(500).json({
      success: false,
      message: "Internal server error",
      error: error.message,
    });
  }
};


export const getAllQuizHistory = async (req, res) => {
  try {

    const history = await prisma.quizHistory.findMany({
      include: {
        quiz: {
          select: { id: true, title: true, description: true, totalPoints: true },
        },
        user : {
          select : {
            id : true,
            name : true ,
            email : true,
            role : true
          }
        }
      },
      orderBy: { completedAt: "desc" },
    });

    return res.status(200).json({
      success: true,
      message: "User quiz history fetched successfully",
      count: history.length,
      data: history,
    });
  } catch (error) {
    console.error("Fetch user quiz history error:", error);
    return res.status(500).json({
      success: false,
      message: "Internal server error",
      error: error.message,
    });
  }
};