import { asyncHandler } from "../../middlewares/asyncHandler.js";
import AppError from "../../utils/AppError.js";
import logger from "../../utils/logger.js";
import {prisma} from "../../config/prisma.js";

/**
 * @desc Get all categories
 * @route GET /api/categories
 * @access Public
 */
export const getCategories = asyncHandler(async (req, res, next) => {
  const categories = await prisma.category.findMany({
    orderBy: { createdAt: "desc" },
  });

  if (!categories.length) {
    logger.warn("No categories found");
    return next(new AppError("No categories found", 404));
  }

  logger.info({ count: categories.length }, "Categories fetched successfully");

  res.status(200).json({
    success: true,
    message: "Categories fetched successfully",
    count: categories.length,
    data: categories,
  });
});

/**
 * @desc Get category by ID
 * @route GET /api/categories/:id
 * @access Public
 */
export const getCategoryById = asyncHandler(async (req, res, next) => {
  const { id } = req.params;

  const category = await prisma.category.findUnique({
    where: { id },
    // include: { topics: true },
  });

  if (!category) {
    logger.warn({ id }, "Category not found");
    return next(new AppError("Category not found", 404));
  }

  logger.info({ id }, "Category fetched successfully");

  res.status(200).json({
    success: true,
    message: "Category fetched successfully",
    data: category,
  });
});

/**
 * @desc Create single category
 * @route POST /api/categories
 * @access Admin
 */
export const createCategory = asyncHandler(async (req, res, next) => {
  const { name, description, imageUrl } = req.body;

  if (!name || name.trim() === "") {
    return next(new AppError("Category name is required", 400));
  }

  try {
    const category = await prisma.category.create({
      data: {
        name: name.trim(),
        description: description || null,
        imageUrl: imageUrl || null,
      },
    });

    logger.info({ id: category.id }, "Category created successfully");

    res.status(201).json({
      success: true,
      message: "Category created successfully",
      data: category,
    });
  } catch (error) {
    if (error.code === "P2002") {
      // Prisma duplicate error
      return next(new AppError("Category with this name already exists", 400));
    }
    logger.error({ error }, "Error creating category");
    return next(new AppError("An error occurred while creating category", 500));
  }
});

/**
 * @desc Create multiple categories (bulk)
 * @route POST /api/categories/bulk
 * @access Admin
 */
export const createManyCategories = asyncHandler(async (req, res, next) => {
  const { categories } = req.body;

  if (!Array.isArray(categories) || categories.length === 0) {
    logger.warn("Invalid bulk create payload");
    return next(
      new AppError("Categories array is required and cannot be empty", 400)
    );
  }

  const invalidCategory = categories.find(
    (cat) => !cat.name || cat.name.trim() === ""
  );
  if (invalidCategory) {
    return next(new AppError("Each category must have a valid name", 400));
  }

  try {
    const created = await prisma.category.createMany({
      data: categories.map((cat) => ({
        name: cat.name.trim(),
        description: cat.description || null,
        imageUrl: cat.imageUrl || null,
      })),
      skipDuplicates: true,
    });

    if (created.count === 0) {
      logger.warn("No new categories were created - duplicates found");
      return next(
        new AppError("No new categories were created, they may already exist", 409)
      );
    }

    logger.info({ createdCount: created.count }, "Categories created successfully");

    res.status(201).json({
      success: true,
      message: "Categories created successfully",
      count: created.count,
    });
  } catch (error) {
    logger.error({ error }, "Error creating categories");
    return next(new AppError("An error occurred while creating categories", 500));
  }
});

/**
 * @desc Update category
 * @route PUT /api/categories/:id
 * @access Admin
 */
export const updateCategory = asyncHandler(async (req, res, next) => {
  const { id } = req.params;
  const { name, description, imageUrl } = req.body;

  try {
    const updatedCategory = await prisma.category.update({
      where: { id },
      data: {
        ...(name && { name: name.trim() }),
        description: description ?? undefined,
        imageUrl: imageUrl ?? undefined,
      },
    });

    logger.info({ id }, "Category updated successfully");

    res.status(200).json({
      success: true,
      message: "Category updated successfully",
      data: updatedCategory,
    });
  } catch (error) {
    if (error.code === "P2025") {
      // Record not found
      return next(new AppError("Category not found", 404));
    }
    if (error.code === "P2002") {
      return next(new AppError("Category with this name already exists", 400));
    }
    logger.error({ error }, "Error updating category");
    return next(new AppError("An error occurred while updating category", 500));
  }
});

/**
 * @desc Delete category
 * @route DELETE /api/categories/:id
 * @access Admin
 */
export const deleteCategory = asyncHandler(async (req, res, next) => {
  const { id } = req.params;

  try {
    await prisma.category.delete({
      where: { id },
    });

    logger.info({ id }, "Category deleted successfully");

    res.status(200).json({
      success: true,
      message: "Category deleted successfully",
    });
  } catch (error) {
    if (error.code === "P2025") {
      return next(new AppError("Category not found", 404));
    }
    logger.error({ error }, "Error deleting category");
    return next(new AppError("An error occurred while deleting category", 500));
  }
});
