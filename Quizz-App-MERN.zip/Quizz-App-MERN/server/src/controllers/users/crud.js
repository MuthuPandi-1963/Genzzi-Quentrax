import bcrypt from "bcrypt";
import { asyncHandler } from "../../middlewares/asyncHandler.js";
import AppError from "../../utils/AppError.js";
import { prisma } from "../../config/prisma.js";

const safeSelect = {
  id: true,
  name: true,
  email: true,
  role: true,
  avatar: true,
  bio: true,
  isBlocked: true,
  isVerified: true,
  createdAt: true,
  updatedAt: true,
};

export const createUser = asyncHandler(async (req, res, next) => {
  const { name, email, password, role = "STUDENT" } = req.body;
  if (!name || !email || !password) {
    return next(new AppError("Name, email and password are required", 400));
  }
  const exists = await prisma.user.findUnique({ where: { email } });
  if (exists) return next(new AppError("Email already registered", 400));

  const hashed = await bcrypt.hash(password, 10);
  const user = await prisma.user.create({
    data: {
      name,
      email,
      password: hashed,
      role,
      isVerified: true,
      avatar:
        req.body.avatar ||
        "https://i.pinimg.com/736x/9d/47/5a/9d475a44af4d774a980c658739b64e6a.jpg",
    },
    select: safeSelect,
  });

  await prisma.coins.create({ data: { userId: user.id, balance: 0 } });

  res.status(201).json({ success: true, data: user });
});

export const updateUser = asyncHandler(async (req, res, next) => {
  const { id } = req.params;
  const { name, email, role, bio, avatar, isBlocked } = req.body;

  const data = {};
  if (name) data.name = name;
  if (email) data.email = email;
  if (role && req.user.role === "ADMIN") data.role = role;
  if (bio !== undefined) data.bio = bio;
  if (avatar) data.avatar = avatar;
  if (typeof isBlocked === "boolean") data.isBlocked = isBlocked;
  if (req.body.password) {
    data.password = await bcrypt.hash(req.body.password, 10);
  }

  const user = await prisma.user.update({
    where: { id },
    data,
    select: safeSelect,
  });

  res.json({ success: true, data: user });
});

export const deleteUser = asyncHandler(async (req, res, next) => {
  const { id } = req.params;
  if (id === req.user.id) {
    return next(new AppError("Cannot delete your own account", 400));
  }
  await prisma.user.delete({ where: { id } });
  res.json({ success: true, message: "User deleted" });
});

export const updateProfile = asyncHandler(async (req, res) => {
  const { name, bio, avatar } = req.body;
  const data = {};
  if (name) data.name = name;
  if (bio !== undefined) data.bio = bio;
  if (avatar) data.avatar = avatar;

  const user = await prisma.user.update({
    where: { id: req.user.id },
    data,
    select: safeSelect,
  });

  res.json({ success: true, data: user });
});

export const changePassword = asyncHandler(async (req, res, next) => {
  const { currentPassword, newPassword } = req.body;
  if (!currentPassword || !newPassword || newPassword.length < 8) {
    return next(new AppError("Valid current and new password required", 400));
  }

  const user = await prisma.user.findUnique({ where: { id: req.user.id } });
  const match = await bcrypt.compare(currentPassword, user.password);
  if (!match) return next(new AppError("Current password is incorrect", 400));

  await prisma.user.update({
    where: { id: req.user.id },
    data: { password: await bcrypt.hash(newPassword, 10) },
  });

  res.json({ success: true, message: "Password updated" });
});
