import { asyncHandler } from "../../middlewares/asyncHandler.js";
import AppError from "../../utils/AppError.js";
import logger from "../../utils/logger.js";
import {prisma} from "../../config/prisma.js";

/**
 * @desc Get all users
 * @route GET /api/users
 * @access Public
 */
export const getUsers = asyncHandler(async (req, res) => {
  const { role, search } = req.query;
  const where = {};
  if (role) where.role = role.toUpperCase();
  if (search) {
    where.OR = [
      { name: { contains: search, mode: "insensitive" } },
      { email: { contains: search, mode: "insensitive" } },
    ];
  }

  const users = await prisma.user.findMany({
    where,
    select: {
      id: true,
      name: true,
      email: true,
      role: true,
      avatar: true,
      isBlocked: true,
      isVerified: true,
      createdAt: true,
      updatedAt: true,
      coins: { select: { balance: true } },
      _count: { select: { quizHistory: true } },
    },
    orderBy: { createdAt: "desc" },
  });

  logger.info({ count: users.length }, "users fetched successfully");

  res.status(200).json({
    success: true,
    message: "users fetched successfully",
    count: users.length,
    data: users,
  });
});


export const getUserById =asyncHandler( async (req, res) => {
  console.log(req);
  
  const { id } = req.params;

  if (!id) {
    return res.status(400).json({ message: "User ID is required" });
  }

  try {
    const user = await prisma.user.findUnique({
      where: { id },
      include: {
        createdQuizzes: {
          include: {
            questions: true,
            history: true,
            CoinsHistory: true,
          },
        },
        quizHistory: true,
        coins: true,
        coinsHistory: true,
      },
    });

    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    res.status(200).json({ user });
  } catch (error) {
    console.error("Error fetching user:", error);
    res.status(500).json({ message: "Internal server error", error: error.message });
  }
});

