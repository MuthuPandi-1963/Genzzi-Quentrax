import { prisma} from "../../config/prisma.js";
import { asyncHandler } from "../../middlewares/asyncHandler.js";
import AppError from "../../utils/AppError.js";
import logger from "../../utils/logger.js";

/**
 * Get all topics
 */
export const getTopics = asyncHandler(async (req, res, next) => {
  const topics = await prisma.topic.findMany({
    orderBy: { createdAt: "desc" },
    include: { category: true }, // include category info
  });

  if (!topics.length) return (
    res.status(200).json({
    success: true,
    message: "Topics fetched successfully",
    count: topics.length,
    data: [],
  })
  )

  res.status(200).json({
    success: true,
    message: "Topics fetched successfully",
    count: topics.length,
    data: topics,
  });
});

/**
 * Get topic by ID
 */
export const getTopicById = asyncHandler(async (req, res, next) => {
  const { id } = req.params;

  const topic = await prisma.topic.findUnique({
    where: { id },
    include: { category: true, questions: true },
  });

  if (!topic) return next(new AppError("Topic not found", 404));

  res.status(200).json({
    success: true,
    message: "Topic fetched successfully",
    data: topic,
  });
});

/**
 * Create a topic
 */
export const createTopic = asyncHandler(async (req, res, next) => {
  const { name, description, categoryId, difficulty, tags,imageUrl } = req.body;

  if (!name || !categoryId) {
    return next(new AppError("Name and categoryId are required", 400));
  }

  try {
    const topic = await prisma.topic.create({
      data: {
        name: name.trim(),
        description: description || null,
        categoryId,
        difficulty,
        tags: tags || [],
        imageUrl : imageUrl || ""
      },
      include: { category: true },
    });

    logger.info({ id: topic.id }, "Topic created successfully");

    res.status(201).json({
      success: true,
      message: "Topic created successfully",
      data: topic,
    });
  } catch (error) {
    if (error.code === "P2002") {
      return next(
        new AppError(
          "Topic with this name already exists in this category",
          400
        )
      );
    }
    logger.error({ error }, "Error creating topic");
    return next(new AppError("An error occurred while creating topic", 500));
  }
});

/**
 * Create multiple topics (bulk)
 */
export const createManyTopics = asyncHandler(async (req, res, next) => {
  const { topics } = req.body;

  if (!Array.isArray(topics) || topics.length === 0) {
    return next(new AppError("Topics array is required and cannot be empty", 400));
  }

  const invalidTopic = topics.find(t => !t.name || !t.categoryId);
  if (invalidTopic) return next(new AppError("Each topic must have name and categoryId", 400));

  try {
    const created = await prisma.topic.createMany({
      data: topics.map(t => ({
        name: t.name.trim(),
        description: t.description || null,
        categoryId: t.categoryId,
        difficulty: t.difficulty || undefined,
        tags: t.tags || [],
      })),
      skipDuplicates: true,
    });

    res.status(201).json({
      success: true,
      message: "Topics created successfully",
      count: created.count,
    });
  } catch (error) {
    logger.error({ error }, "Error creating topics");
    return next(new AppError("An error occurred while creating topics", 500));
  }
});

/**
 * Update a topic
 */
export const updateTopic = asyncHandler(async (req, res, next) => {
  const { id } = req.params;
  const { name, description, categoryId, difficulty, tags } = req.body;

  try {
    const updated = await prisma.topic.update({
      where: { id },
      data: {
        ...(name && { name: name.trim() }),
        description: description ?? undefined,
        categoryId: categoryId ?? undefined,
        difficulty: difficulty ?? undefined,
        tags: tags ?? undefined,
      },
    });

    res.status(200).json({
      success: true,
      message: "Topic updated successfully",
      data: updated,
    });
  } catch (error) {
    if (error.code === "P2025") return next(new AppError("Topic not found", 404));
    if (error.code === "P2002")
      return next(new AppError("Topic with this name already exists in this category", 400));

    logger.error({ error }, "Error updating topic");
    return next(new AppError("An error occurred while updating topic", 500));
  }
});

/**
 * Delete a topic
 */
export const deleteTopic = asyncHandler(async (req, res, next) => {
  const { id } = req.params;

  try {
    await prisma.topic.delete({ where: { id } });
    res.status(200).json({
      success: true,
      message: "Topic deleted successfully",
    });
  } catch (error) {
    if (error.code === "P2025") return next(new AppError("Topic not found", 404));
    logger.error({ error }, "Error deleting topic");
    return next(new AppError("An error occurred while deleting topic", 500));
  }
});
