import { prisma } from "../config/prisma.js";
import { asyncHandler } from "../middlewares/asyncHandler.js";
import AppError from "../utils/AppError.js";
import logger from "../utils/logger.js";

// ==================== ASSESSMENT CRUD ====================

/**
 * Create a new assessment
 * Only ADMIN and STAFF can create assessments
 */
export const createAssessment = asyncHandler(async (req, res, next) => {
  const {
    title,
    description,
    topicId,
    quizId,
    deadline,
    scheduledAt,
    timeLimit,
    startDate,
    endDate,
    passingScore,
    maxAttempts,
    maxViolations,
    proctoredMode,
    shuffleQuestions,
    shuffleOptions,
    allowReview,
    allowRetry,
    showResultImmediately,
  } = req.body;

  // Validation
  if (!title) {
    return next(new AppError("Assessment title is required", 400));
  }

  try {
    const assessment = await prisma.assessment.create({
      data: {
        title: title.trim(),
        description: description || null,
        topicId: topicId || null,
        quizId: quizId || null,
        deadline: deadline ? new Date(deadline) : null,
        scheduledAt: scheduledAt ? new Date(scheduledAt) : null,
        timeLimit: timeLimit || null,
        startDate: startDate ? new Date(startDate) : null,
        endDate: endDate ? new Date(endDate) : null,
        passingScore: passingScore ?? 50,
        maxAttempts: maxAttempts ?? 1,
        maxViolations: maxViolations ?? 3,
        proctoredMode: proctoredMode ?? false,
        shuffleQuestions: shuffleQuestions ?? false,
        shuffleOptions: shuffleOptions ?? false,
        allowReview: allowReview ?? true,
        allowRetry: allowRetry ?? true,
        showResultImmediately: showResultImmediately ?? true,
        creatorId: req.user.id,
      },
      include: {
        creator: { select: { id: true, name: true, email: true } },
        topic: true,
        quiz: true,
      },
    });

    logger.info({ id: assessment.id, creatorId: req.user.id }, "Assessment created successfully");

    res.status(201).json({
      success: true,
      message: "Assessment created successfully",
      data: assessment,
    });
  } catch (error) {
    logger.error({ error }, "Error creating assessment");
    return next(new AppError("An error occurred while creating assessment", 500));
  }
});

/**
 * Get all assessments with optional filters
 * Supports filtering by status, topic, creator, and published status
 */
export const getAssessments = asyncHandler(async (req, res, next) => {
  const { status, topicId, creatorId, published } = req.query;

  const filters = {};
  if (status) filters.status = status;
  if (topicId) filters.topicId = topicId;
  if (creatorId) filters.creatorId = creatorId;
  if (published !== undefined) filters.published = published === "true";

  try {
    const assessments = await prisma.assessment.findMany({
      where: filters,
      include: {
        creator: { select: { id: true, name: true, email: true, avatar: true } },
        topic: { include: { category: true } },
        quiz: true,
        assignments: {
          include: {
            user: { select: { id: true, name: true, email: true } },
          },
        },
        _count: {
          select: { attempts: true, assignments: true },
        },
      },
      orderBy: { createdAt: "desc" },
    });

    res.status(200).json({
      success: true,
      message: "Assessments fetched successfully",
      count: assessments.length,
      data: assessments,
    });
  } catch (error) {
    logger.error({ error }, "Error fetching assessments");
    return next(new AppError("An error occurred while fetching assessments", 500));
  }
});

/**
 * Get a single assessment by ID
 */
export const getAssessmentById = asyncHandler(async (req, res, next) => {
  const { id } = req.params;

  try {
    const assessment = await prisma.assessment.findUnique({
      where: { id },
      include: {
        creator: { select: { id: true, name: true, email: true, avatar: true } },
        topic: { include: { category: true } },
        quiz: {
          include: {
            questions: true,
          },
        },
        assignments: {
          include: {
            user: { select: { id: true, name: true, email: true } },
          },
        },
        attempts: {
          where: { userId: req.user.id },
          orderBy: { startedAt: "desc" },
        },
        _count: {
          select: { attempts: true, assignments: true },
        },
      },
    });

    if (!assessment) {
      return next(new AppError("Assessment not found", 404));
    }

    res.status(200).json({
      success: true,
      message: "Assessment fetched successfully",
      data: assessment,
    });
  } catch (error) {
    logger.error({ error, id }, "Error fetching assessment");
    return next(new AppError("An error occurred while fetching assessment", 500));
  }
});

/**
 * Update an assessment
 * Only ADMIN and STAFF can update assessments
 */
export const updateAssessment = asyncHandler(async (req, res, next) => {
  const { id } = req.params;
  const updateData = { ...req.body };

  // Remove read-only fields
  delete updateData.id;
  delete updateData.creatorId;
  delete updateData.createdAt;
  delete updateData.updatedAt;

  // Convert date strings to Date objects
  if (updateData.deadline) updateData.deadline = new Date(updateData.deadline);
  if (updateData.scheduledAt) updateData.scheduledAt = new Date(updateData.scheduledAt);
  if (updateData.startDate) updateData.startDate = new Date(updateData.startDate);
  if (updateData.endDate) updateData.endDate = new Date(updateData.endDate);

  try {
    const updated = await prisma.assessment.update({
      where: { id },
      data: updateData,
      include: {
        creator: { select: { id: true, name: true, email: true } },
        topic: { include: { category: true } },
        quiz: true,
      },
    });

    logger.info({ id, updatedBy: req.user.id }, "Assessment updated successfully");

    res.status(200).json({
      success: true,
      message: "Assessment updated successfully",
      data: updated,
    });
  } catch (error) {
    if (error.code === "P2025") {
      return next(new AppError("Assessment not found", 404));
    }
    logger.error({ error, id }, "Error updating assessment");
    return next(new AppError("An error occurred while updating assessment", 500));
  }
});

/**
 * Delete an assessment
 * Only ADMIN and STAFF can delete assessments
 */
export const deleteAssessment = asyncHandler(async (req, res, next) => {
  const { id } = req.params;

  try {
    await prisma.assessment.delete({
      where: { id },
    });

    logger.info({ id, deletedBy: req.user.id }, "Assessment deleted successfully");

    res.status(200).json({
      success: true,
      message: "Assessment deleted successfully",
    });
  } catch (error) {
    if (error.code === "P2025") {
      return next(new AppError("Assessment not found", 404));
    }
    logger.error({ error, id }, "Error deleting assessment");
    return next(new AppError("An error occurred while deleting assessment", 500));
  }
});

// ==================== ASSESSMENT ACTIONS ====================

/**
 * Get available topics for assessment creation
 */
export const getAvailableTopics = asyncHandler(async (req, res, next) => {
  try {
    const topics = await prisma.topic.findMany({
      select: {
        id: true,
        name: true,
        description: true,
        category: {
          select: {
            id: true,
            name: true,
          },
        },
        difficulty: true,
        _count: {
          select: { questions: true },
        },
      },
      orderBy: [{ category: { name: "asc" } }, { name: "asc" }],
    });

    res.status(200).json({
      success: true,
      message: "Topics fetched successfully",
      data: topics,
    });
  } catch (error) {
    logger.error({ error }, "Error fetching topics");
    return next(new AppError("An error occurred while fetching topics", 500));
  }
});

/**
 * Start an assessment (validate and begin attempt)
 * Security-critical endpoint
 */
export const startAssessment = asyncHandler(async (req, res, next) => {
  const { id } = req.params;
  const userId = req.user.id;

  try {
    // Get assessment with all relations
    const assessment = await prisma.assessment.findUnique({
      where: { id },
      include: {
        quiz: {
          include: {
            questions: true,
          },
        },
        // Topic is modeled as optional single relation (single-topic fix)
        topic: { include: { questions: true } },
        assessmentQuestions: {
          include: { question: true },
          orderBy: { sortOrder: "asc" },
        },
      },
    });


    if (!assessment) {
      return next(new AppError("Assessment not found", 404));
    }

    // Check if assessment is published
    if (!assessment.published) {
      return next(new AppError("Assessment is not published", 400));
    }

    // Check if assessment is within availability window
    const now = new Date();
    if (assessment.startDate && now < new Date(assessment.startDate)) {
      return next(new AppError("Assessment has not started yet", 400));
    }
    if (assessment.endDate && now > new Date(assessment.endDate)) {
      return next(new AppError("Assessment has expired", 400));
    }

    // Check if user is assigned to this assessment
    const assignment = await prisma.assessmentAssignment.findUnique({
      where: {
        assessmentId_userId: {
          assessmentId: id,
          userId: userId,
        },
      },
    });

    if (!assignment) {
      return next(new AppError("You are not assigned to this assessment", 403));
    }

    // Check if user has already completed the assessment
    if (assignment.status === "COMPLETED") {
      if (!assessment.allowRetry) {
        return next(new AppError("You have already completed this assessment and retries are not allowed", 400));
      }
    }

    // Check max attempts
    const attemptCount = await prisma.assessmentAttempt.count({
      where: {
        assessmentId: id,
        userId: userId,
      },
    });

    if (attemptCount >= assessment.maxAttempts) {
      return next(new AppError(`Maximum attempts (${assessment.maxAttempts}) reached`, 400));
    }

    // Update assignment status
    await prisma.assessmentAssignment.update({
      where: { id: assignment.id },
      data: {
        status: "IN_PROGRESS",
        startedAt: now,
      },
    });

    // Create attempt record
    const attempt = await prisma.assessmentAttempt.create({
      data: {
        assessmentId: id,
        userId: userId,
        status: "IN_PROGRESS",
        startedAt: now,
        answers: {},
        score: 0,
      },
    });

    // Prepare questions (with shuffling if enabled)
    // Priority:
    // 1) Quiz questions (existing behavior)
    // 2) Assessment custom questions (AssessmentQuestion -> Question)
    // 3) Topic questions
    let questions = [];


    if (assessment.quiz?.questions?.length) {
      questions = assessment.quiz.questions;
    } else if (assessment.assessmentQuestions?.length) {
      questions = assessment.assessmentQuestions
        .sort((a, b) => a.sortOrder - b.sortOrder)
        .map((aq) => aq.question);
    } else if (assessment.topic?.[0]?.questions?.length) {
      questions = assessment.topic[0].questions;
    }

    if (assessment.shuffleQuestions) {
      questions = questions.sort(() => Math.random() - 0.5);
    }

    // Shuffle options if enabled
    if (assessment.shuffleOptions) {
      questions = questions.map((q) => {
        if (q.options && Array.isArray(q.options)) {
          const shuffledOptions = [...q.options].sort(() => Math.random() - 0.5);
          return { ...q, options: shuffledOptions };
        }
        return q;
      });
    }

    // Remove correct answers from questions sent to client
    const sanitizedQuestions = questions.map((q) => {
      const aq = assessment.assessmentQuestions?.find((x) => x.questionId === q.id);
      return {
        id: q.id,
        questionText: q.questionText,
        questionType: q.questionType,
        options: q.options,
        points: aq?.pointsOverride ?? q.points,
        hints: assessment.allowReview ? q.hints : [],
      };
    });


    logger.info({ id, userId, attemptId: attempt.id }, "Assessment started");

    res.status(200).json({
      success: true,
      message: "Assessment started successfully",
      data: {
        attemptId: attempt.id,
        assessment: {
          id: assessment.id,
          title: assessment.title,
          timeLimit: assessment.timeLimit,
          proctoredMode: assessment.proctoredMode,
          allowReview: assessment.allowReview,
          startedAt: now,
        },
        questions: sanitizedQuestions,
      },
    });
  } catch (error) {
    logger.error({ error, id, userId }, "Error starting assessment");
    return next(new AppError("An error occurred while starting assessment", 500));
  }
});

/**
 * Submit an assessment attempt
 */
export const submitAssessmentAttempt = asyncHandler(async (req, res, next) => {
  const { id } = req.params;
  const userId = req.user.id;
  const { answers, attemptId } = req.body;

  if (!answers || typeof answers !== "object") {
    return next(new AppError("Answers are required", 400));
  }

  try {
    const assessment = await prisma.assessment.findUnique({
      where: { id },
      include: {
        quiz: {
          include: {
            questions: true,
          },
        },
        topic: { include: { questions: true } },
        assessmentQuestions: {
          include: { question: true },
          orderBy: { sortOrder: "asc" },
        },
      },
    });

    if (!assessment) {
      return next(new AppError("Assessment not found", 404));
    }

    // Find the attempt
    const attempt = await prisma.assessmentAttempt.findFirst({
      where: {
        id: attemptId,
        assessmentId: id,
        userId: userId,
        status: "IN_PROGRESS",
      },
    });


    if (!attempt) {
      return next(new AppError("No active attempt found for this assessment", 404));
    }

    // Calculate score
    let score = 0;
    const questionResults = [];

    // Match startAssessment question source priority
    // 1) Quiz questions
    // 2) Assessment custom questions
    // 3) Topic questions
    let questions = [];

    if (assessment.quiz?.questions?.length) {
      questions = assessment.quiz.questions;
    } else if (assessment.assessmentQuestions?.length) {
      questions = assessment.assessmentQuestions
        .sort((a, b) => a.sortOrder - b.sortOrder)
        .map((aq) => aq.question);
    } else if (assessment.topic?.questions?.length) {
      questions = assessment.topic.questions;
    }

    for (const question of questions) {
      const userAnswer = answers[question.id];
      const isCorrect = checkAnswer(question, userAnswer);

      const aq = assessment.assessmentQuestions?.find((x) => x.questionId === question.id);
      const points = aq?.pointsOverride ?? question.points ?? 1;

      if (isCorrect) {
        score += points;
      }

      questionResults.push({
        questionId: question.id,
        isCorrect,
        userAnswer,
        points,
      });
    }


    // Update attempt
    await prisma.assessmentAttempt.update({
      where: { id: attemptId },
      data: {
        status: "COMPLETED",
        completedAt: new Date(),
        answers: answers,
        score: score,
      },
    });

    // Update assignment
    await prisma.assessmentAssignment.updateMany({
      where: {
        assessmentId: id,
        userId: userId,
      },
      data: {
        status: "COMPLETED",
        completedAt: new Date(),
      },
    });

    logger.info({ id, userId, attemptId, score }, "Assessment submitted successfully");

    res.status(200).json({
      success: true,
      message: "Assessment submitted successfully",
      data: {
        score,
        totalQuestions: assessment.quiz?.questions.length || 0,
        correctAnswers: questionResults.filter((r) => r.isCorrect).length,
        passingScore: assessment.passingScore,
        passed: score >= assessment.passingScore,
      },
    });
  } catch (error) {
    logger.error({ error, id, userId }, "Error submitting assessment");
    return next(new AppError("An error occurred while submitting assessment", 500));
  }
});

/**
 * Get assessment completion statistics (for admins)
 */
export const getAssessmentCompletion = asyncHandler(async (req, res, next) => {
  const { id } = req.params;

  try {
    const assessment = await prisma.assessment.findUnique({
      where: { id },
      include: {
        assignments: {
          include: {
            user: { select: { id: true, name: true, email: true } },
          },
        },
        attempts: {
          orderBy: { completedAt: "desc" },
        },
      },
    });

    if (!assessment) {
      return next(new AppError("Assessment not found", 404));
    }

    const totalAssigned = assessment.assignments.length;
    const completed = assessment.assignments.filter((a) => a.status === "COMPLETED").length;
    const inProgress = assessment.assignments.filter((a) => a.status === "IN_PROGRESS").length;
    const pending = assessment.assignments.filter((a) => a.status === "PENDING").length;

    // Calculate average score
    const completedAttempts = assessment.attempts.filter((a) => a.status === "COMPLETED");
    const avgScore =
      completedAttempts.length > 0
        ? completedAttempts.reduce((sum, a) => sum + a.score, 0) / completedAttempts.length
        : 0;

    // Get pass/fail ratio
    const passed = completedAttempts.filter((a) => a.score >= assessment.passingScore).length;
    const failed = completedAttempts.length - passed;

    res.status(200).json({
      success: true,
      message: "Assessment completion stats fetched successfully",
      data: {
        assessment: {
          id: assessment.id,
          title: assessment.title,
          passingScore: assessment.passingScore,
        },
        statistics: {
          totalAssigned,
          completed,
          inProgress,
          pending,
          completionRate: totalAssigned > 0 ? (completed / totalAssigned) * 100 : 0,
          averageScore: Math.round(avgScore),
          passRate: completedAttempts.length > 0 ? (passed / completedAttempts.length) * 100 : 0,
          passed,
          failed,
        },
        attempts: assessment.attempts.map((a) => ({
          id: a.id,
          userId: a.userId,
          score: a.score,
          status: a.status,
          startedAt: a.startedAt,
          completedAt: a.completedAt,
        })),
      },
    });
  } catch (error) {
    logger.error({ error, id }, "Error fetching assessment completion stats");
    return next(new AppError("An error occurred while fetching completion stats", 500));
  }
});

// ==================== ASSIGNMENT MANAGEMENT ====================

/**
 * Assign users to an assessment
 * Only ADMIN and STAFF can assign users
 */
export const assignUsersToAssessment = asyncHandler(async (req, res, next) => {
  const { id } = req.params;
  const { userIds, dueDate } = req.body;

  if (!Array.isArray(userIds) || userIds.length === 0) {
    return next(new AppError("User IDs array is required and cannot be empty", 400));
  }

  try {
    // Verify assessment exists
    const assessment = await prisma.assessment.findUnique({
      where: { id },
    });

    if (!assessment) {
      return next(new AppError("Assessment not found", 404));
    }

    // Create assignments (skip duplicates)
    const assignments = await prisma.assessmentAssignment.createMany({
      data: userIds.map((userId) => ({
        assessmentId: id,
        userId,
        dueDate: dueDate ? new Date(dueDate) : assessment.deadline,
        status: "PENDING",
      })),
      skipDuplicates: true,
    });

    logger.info(
      { assessmentId: id, userIds, assignedBy: req.user.id },
      "Users assigned to assessment"
    );

    res.status(201).json({
      success: true,
      message: `${assignments.count} users assigned to assessment successfully`,
      data: { count: assignments.count },
    });
  } catch (error) {
    logger.error({ error, assessmentId: id }, "Error assigning users to assessment");
    return next(new AppError("An error occurred while assigning users", 500));
  }
});

/**
 * Get all users assigned to an assessment
 * Only ADMIN and STAFF can view assignments
 */
export const getAssignedUsers = asyncHandler(async (req, res, next) => {
  const { id } = req.params;
  const { status } = req.query;

  const filters = { assessmentId: id };
  if (status) filters.status = status;

  try {
    const assignments = await prisma.assessmentAssignment.findMany({
      where: filters,
      include: {
        user: {
          select: {
            id: true,
            name: true,
            email: true,
            avatar: true,
          },
        },
        assessment: {
          select: {
            id: true,
            title: true,
            deadline: true,
          },
        },
      },
      orderBy: { assignedAt: "desc" },
    });

    res.status(200).json({
      success: true,
      message: "Assigned users fetched successfully",
      count: assignments.length,
      data: assignments,
    });
  } catch (error) {
    logger.error({ error, assessmentId: id }, "Error fetching assigned users");
    return next(new AppError("An error occurred while fetching assigned users", 500));
  }
});

/**
 * Remove a user from an assessment
 * Only ADMIN and STAFF can remove users
 */
export const removeUserFromAssessment = asyncHandler(async (req, res, next) => {
  const { assessmentId, userId } = req.params;

  try {
    await prisma.assessmentAssignment.delete({
      where: {
        assessmentId_userId: {
          assessmentId,
          userId,
        },
      },
    });

    logger.info(
      { assessmentId, userId, removedBy: req.user.id },
      "User removed from assessment"
    );

    res.status(200).json({
      success: true,
      message: "User removed from assessment successfully",
    });
  } catch (error) {
    if (error.code === "P2025") {
      return next(new AppError("Assignment not found", 404));
    }
    logger.error({ error, assessmentId, userId }, "Error removing user from assessment");
    return next(new AppError("An error occurred while removing user", 500));
  }
});

/**
 * Update assignment status (e.g., exempt a user)
 * Only ADMIN and STAFF can update assignments
 */
export const updateAssignmentStatus = asyncHandler(async (req, res, next) => {
  const { assessmentId, userId } = req.params;
  const { status, dueDate } = req.body;

  try {
    const updated = await prisma.assessmentAssignment.update({
      where: {
        assessmentId_userId: {
          assessmentId,
          userId,
        },
      },
      data: {
        ...(status && { status }),
        ...(dueDate && { dueDate: new Date(dueDate) }),
      },
      include: {
        user: { select: { id: true, name: true, email: true } },
      },
    });

    logger.info(
      { assessmentId, userId, updatedBy: req.user.id, newStatus: status },
      "Assignment updated"
    );

    res.status(200).json({
      success: true,
      message: "Assignment updated successfully",
      data: updated,
    });
  } catch (error) {
    if (error.code === "P2025") {
      return next(new AppError("Assignment not found", 404));
    }
    logger.error({ error, assessmentId, userId }, "Error updating assignment");
    return next(new AppError("An error occurred while updating assignment", 500));
  }
});

/**
 * Get all assessments for a specific user
 * Only ADMIN and STAFF can view user assessments
 */
export const getUserAssessments = asyncHandler(async (req, res, next) => {
  const { userId } = req.params;

  try {
    const assignments = await prisma.assessmentAssignment.findMany({
      where: { userId },
      include: {
        assessment: {
          include: {
            topic: { include: { category: true } },
            creator: { select: { id: true, name: true } },
          },
        },
      },
      orderBy: { assignedAt: "desc" },
    });

    res.status(200).json({
      success: true,
      message: "User assessments fetched successfully",
      count: assignments.length,
      data: assignments,
    });
  } catch (error) {
    logger.error({ error, userId }, "Error fetching user assessments");
    return next(new AppError("An error occurred while fetching user assessments", 500));
  }
});

/**
 * Get the authenticated user's assessments
 */
export const getMyAssessments = asyncHandler(async (req, res, next) => {
  const userId = req.user.id;

  try {
    const assignments = await prisma.assessmentAssignment.findMany({
      where: { userId },
      include: {
        assessment: {
          include: {
            topic: { include: { category: true } },
            creator: { select: { id: true, name: true } },
            _count: {
              select: { attempts: true },
            },
          },
        },
      },
      orderBy: { assignedAt: "desc" },
    });

    // Categorize assessments
    const now = new Date();
    const activeAssessments = [];
    const upcomingAssessments = [];
    const expiredAssessments = [];

    assignments.forEach(({ assessment, status }) => {
      const assessmentData = { ...assessment, assignmentStatus: status };

      if (!assessment.published) return;

      const startDate = assessment.startDate ? new Date(assessment.startDate) : null;
      const endDate = assessment.endDate ? new Date(assessment.endDate) : null;

      if (startDate && now < startDate) {
        upcomingAssessments.push(assessmentData);
      } else if (endDate && now > endDate) {
        expiredAssessments.push(assessmentData);
      } else {
        activeAssessments.push(assessmentData);
      }
    });

    res.status(200).json({
      success: true,
      message: "My assessments fetched successfully",
      data: assignments.map((a) => a.assessment),
      activeAssessments,
      upcomingAssessments,
      expiredAssessments,
    });
  } catch (error) {
    logger.error({ error, userId }, "Error fetching my assessments");
    return next(new AppError("An error occurred while fetching assessments", 500));
  }
});

// ==================== HELPER FUNCTIONS ====================

/**
 * Check if an answer is correct
 */
function checkAnswer(question, userAnswer) {
  if (!question.options || !Array.isArray(question.options)) {
    return false;
  }

  const correctOptions = question.options.filter((opt) => opt.isCorrect);

  // Handle different question types
  switch (question.questionType) {
    case "MCQ":
      // Single correct answer
      if (correctOptions.length === 1) {
        return userAnswer === correctOptions[0].text;
      }
      // Multiple correct answers
      if (Array.isArray(userAnswer)) {
        const correctTexts = correctOptions.map((opt) => opt.text).sort();
        const userTexts = userAnswer.sort();
        return JSON.stringify(correctTexts) === JSON.stringify(userTexts);
      }
      return false;

    case "TRUE_FALSE":
      return userAnswer === correctOptions[0].text;

    case "FILL_BLANK":
      return (
        userAnswer &&
        correctOptions.some((opt) =>
          opt.text.toLowerCase().trim() === userAnswer.toLowerCase().trim()
        )
      );

    default:
      return false;
  }
}