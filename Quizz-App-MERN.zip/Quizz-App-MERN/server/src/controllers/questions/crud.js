import { prisma } from "../../config/prisma.js";
import { asyncHandler } from "../../middlewares/asyncHandler.js";
import AppError from "../../utils/AppError.js";
import logger from "../../utils/logger.js";

/**
 * Get all questions with optional filters
 */
export const getQuestions = asyncHandler(async (req, res, next) => {
  const { topicId, difficulty, status, questionType } = req.query;

  const filters = {};
  if (topicId) filters.topicId = topicId;
  if (difficulty) filters.difficulty = difficulty;
  if (status) filters.status = status;
  if (questionType) filters.questionType = questionType;

  const questions = await prisma.question.findMany({
    where: filters,
    include: { topic: { include: { category: true } } },
    orderBy: { createdAt: "desc" },
  });

  if (!questions.length) return (
    res.status(200).json({
    success: true,
    message: "questions fetched successfully",
    count: questions.length,
    data: [],
  })
  ) 

  res.status(200).json({
    success: true,
    message: "Questions fetched successfully",
    count: questions.length,
    data: questions,
  });
});

/**
 * Get a question by ID
 */
export const getQuestionById = asyncHandler(async (req, res, next) => {
  const { id } = req.params;

  const question = await prisma.question.findUnique({
    where: { id },
    include: { topic: { include: { category: true } } },
  });

  if (!question) return next(new AppError("Question not found", 404));

  res.status(200).json({
    success: true,
    message: "Question fetched successfully",
    data: question,
  });
});

/**
 * Create a single question
 */
export const createQuestion = asyncHandler(async (req, res, next) => {
  const {
    questionText,
    questionType,
    difficulty,
    points,
    explanation,
    topicId,
    options,
    tags,
    status,
    hints,
  } = req.body;
  console.log(req.body);
  

  if (!questionText || !questionType || !difficulty || !topicId || !options)
    return next(new AppError("Required fields missing", 400));

  try {
    const checkTopicId = await prisma.topic.findFirst({
      where : {id : topicId}
    })
    if(!checkTopicId){
      logger.warn("topic id not found")
      return res.json({
        success : false,
        message : "topic id not found"

      })
    }
    const question = await prisma.question.create({
      data: {
        questionText: questionText.trim(),
        questionType,
        difficulty,
        points: points || 1,
        explanation: explanation || null,
        topicId,
        options,
        tags: tags || [],
        hints: hints || [],
        status: status || "active",
      },
      include: { topic: true },
    });

    logger.info({ id: question.id }, "Question created successfully");

    res.status(201).json({
      success: true,
      message: "Question created successfully",
      data: question,
    });
  } catch (error) {
    logger.error({ error }, "Error creating question");
    return next(new AppError("An error occurred while creating question", 500));
  }
});

/**
 * Create multiple questions (bulk insert)
 */
export const createManyQuestions = asyncHandler(async (req, res, next) => {
  const { questions } = req.body;

  if (!Array.isArray(questions) || questions.length === 0)
    return next(new AppError("Questions array is required and cannot be empty", 400));

  try {
    const formattedData = questions.map((q) => ({
      questionText: q.questionText.trim(),
      questionType: q.questionType,
      difficulty: q.difficulty,
      points: q.points || 1,
      explanation: q.explanation || null,
      topicId: q.topicId,
      options: q.options,
      tags: q.tags || [],
      hints: q.hints || [],
      status: q.status || "active",
    }));

    const created = await prisma.question.createMany({
      data: formattedData,
      skipDuplicates: true,
    });

    res.status(201).json({
      success: true,
      message: "Questions created successfully",
      count: created.count,
    });
  } catch (error) {
    logger.error({ error }, "Error creating questions");
    return next(new AppError("An error occurred while creating questions", 500));
  }
});

/**
 * Update a question by ID
 */
export const updateQuestion = asyncHandler(async (req, res, next) => {
  const { id } = req.params;
  const {
    questionText,
    questionType,
    difficulty,
    points,
    explanation,
    topicId,
    options,
    tags,
    status,
    hints,
  } = req.body;

  try {
    const updated = await prisma.question.update({
      where: { id },
      data: {
        ...(questionText && { questionText: questionText.trim() }),
        questionType: questionType ?? undefined,
        difficulty: difficulty ?? undefined,
        points: points ?? undefined,
        explanation: explanation ?? undefined,
        topicId: topicId ?? undefined,
        options: options ?? undefined,
        tags: tags ?? undefined,
        hints: hints ?? undefined,
        status: status ?? undefined,
      },
    });

    res.status(200).json({
      success: true,
      message: "Question updated successfully",
      data: updated,
    });
  } catch (error) {
    if (error.code === "P2025") return next(new AppError("Question not found", 404));

    logger.error({ error }, "Error updating question");
    return next(new AppError("An error occurred while updating question", 500));
  }
});

/**
 * Delete a question by ID
 */
export const deleteQuestion = asyncHandler(async (req, res, next) => {
  const { id } = req.params;

  try {
    await prisma.question.delete({ where: { id } });
    res.status(200).json({
      success: true,
      message: "Question deleted successfully",
    });
  } catch (error) {
    if (error.code === "P2025") return next(new AppError("Question not found", 404));

    logger.error({ error }, "Error deleting question");
    return next(new AppError("An error occurred while deleting question", 500));
  }
});
