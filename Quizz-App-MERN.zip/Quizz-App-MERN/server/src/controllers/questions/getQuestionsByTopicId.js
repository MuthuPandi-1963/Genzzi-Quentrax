import { prisma } from "../../config/prisma.js";
import { asyncHandler } from "../../middlewares/asyncHandler.js";

export const getQuestionByTopicId = asyncHandler(async (req, res, next) => {
  const { id } = req.params;
  if(!id){
    return res.status(404).json({
        success : false,
        message : "Id not found"
    })
  }

  const question = await prisma.question.findMany({
    where: { topicId : id},
  });

  if (!question) return next(new AppError("Question not found", 404));

  res.status(200).json({
    success: true,
    message: "Question fetched successfully",
    data: question,
  });
});