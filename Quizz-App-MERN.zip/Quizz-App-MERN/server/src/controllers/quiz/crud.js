import { prisma } from "../../config/prisma.js";
import { asyncHandler } from "../../middlewares/asyncHandler.js";
import AppError from "../../utils/AppError.js";
import logger from "../../utils/logger.js";

/**
 * Get all quizzes with optional filters
 * Supports filtering by status, creator, tag, and topic
 */
export const getQuizzes = asyncHandler(async (req, res, next) => {
  const { status, creatorId, tag, topicId } = req.query;

  const filters = {};
  if (status) filters.status = status;
  if (creatorId) filters.creatorId = creatorId;
  if (tag) filters.tags = { has: tag };
  if (topicId) filters.topicId = topicId;

  const quizzes = await prisma.quiz.findMany({
    where: filters,
    include: {
      creator: true,
      topic: true,
      questions :true
      },
    orderBy: { createdAt: "desc" },
  });

  if (!quizzes.length) return (
     res.status(200).json({
      success : false,
      message : "no questions found",
      data : []
     })
  )

  res.status(200).json({
    success: true,
    message: "Quizzes fetched successfully",
    count: quizzes.length,
    data: quizzes,
  });
});

/**
 * Get a single quiz by ID
 */
export const getQuizById = asyncHandler(async (req, res, next) => {
  const { id } = req.params;

  const quiz = await prisma.quiz.findUnique({
    where: { id },
    include: {
      creator: true,
      topic: true,
      questions: { include: { question: true } },
      history: true,
    },
  });

  if (!quiz) return next(new AppError("Quiz not found", 404));

  res.status(200).json({
    success: true,
    message: "Quiz fetched successfully",
    data: quiz,
  });
});

/**
 * Create a new quiz
 */
export const createQuiz = asyncHandler(async (req, res, next) => {
  const { title, description, creatorId, totalPoints, status, tags, timeLimit, topicId, imageUrl } = req.body || {};

  if (!title || !creatorId) return next(new AppError("Title and creatorId are required", 400));

  try {
    const quiz = await prisma.quiz.create({
      data: {
        title: title.trim(),
        description: description || null,
        creatorId,
        totalPoints: totalPoints || 0,
        status: status || "active",
        tags: tags || [],
        timeLimit: timeLimit || null,
        topicId: topicId || null,
        imageUrl : imageUrl || null
      },
      include: { creator: true, topic: true },
    });

    logger.info({ id: quiz.id }, "Quiz created successfully");

    res.status(201).json({
      success: true,
      message: "Quiz created successfully",
      data: quiz,
    });
  } catch (error) {
    logger.error({ error }, "Error creating quiz");
    return next(new AppError("An error occurred while creating quiz", 500));
  }
});

/**
 * Update a quiz
 */
export const updateQuiz = asyncHandler(async (req, res, next) => {
  const { id } = req.params;
  const { title, description, totalPoints, status, tags, timeLimit, topicId } = req.body || {};

  try {
    const updated = await prisma.quiz.update({
      where: { id },
      data: {
        ...(title && { title: title.trim() }),
        description: description ?? undefined,
        totalPoints: totalPoints ?? undefined,
        status: status ?? undefined,
        tags: tags ?? undefined,
        timeLimit: timeLimit ?? undefined,
        topicId: topicId ?? undefined,
      },
      include: { creator: true, topic: true },
    });

    res.status(200).json({
      success: true,
      message: "Quiz updated successfully",
      data: updated,
    });
  } catch (error) {
    if (error.code === "P2025") return next(new AppError("Quiz not found", 404));
    logger.error({ error }, "Error updating quiz");
    return next(new AppError("An error occurred while updating quiz", 500));
  }
});

/**
 * Delete a quiz
 */
export const deleteQuiz = asyncHandler(async (req, res, next) => {
  const { id } = req.params;

  try {
    if(!id){
      return res.status(400).json({
        message : "id not found"
      })
    }
    await prisma.quiz.delete({ where: { id } });
    res.status(200).json({
      success: true,
      message: "Quiz deleted successfully",
    });
  } catch (error) {
    if (error.code === "P2025") return next(new AppError("Quiz not found", 404));
    logger.error({ error }, "Error deleting quiz");
    return next(new AppError("An error occurred while deleting quiz", 500));
  }
});

/**
 * Bulk create quizzes
 */
export const createManyQuizzes = asyncHandler(async (req, res, next) => {
  const { quizzes } = req.body || {};

  if (!Array.isArray(quizzes) || quizzes.length === 0) {
    return next(new AppError("Quizzes array is required and cannot be empty", 400));
  }

  try {
    const created = await prisma.quiz.createMany({
      data: quizzes.map(q => ({
        title: q.title.trim(),
        description: q.description || null,
        creatorId: q.creatorId,
        totalPoints: q.totalPoints || 0,
        status: q.status || "active",
        tags: q.tags || [],
        timeLimit: q.timeLimit || null,
        topicId: q.topicId || null,
      })),
      skipDuplicates: true,
    });

    res.status(201).json({
      success: true,
      message: "Quizzes created successfully",
      count: created.count,
    });
  } catch (error) {
    logger.error({ error }, "Error creating quizzes");
    return next(new AppError("An error occurred while creating quizzes", 500));
  }
});
