import { prisma } from "../../config/prisma.js";
import { asyncHandler } from "../../middlewares/asyncHandler.js";
import AppError from "../../utils/AppError.js";
import logger from "../../utils/logger.js";

export const AddQuestionsInQuiz = asyncHandler(async (req, res, next) => {
  const { id } = req.params;
  const { questions } = req.body;

  try {
    const findQuiz = await prisma.quiz.findUnique({ where: { id } });
    if (!findQuiz) {
      return next(new AppError("Quiz not found", 404));
    }

    // Ensure all question IDs exist
    const findQuestions = await Promise.all(
      questions.map(q_id => prisma.question.findUnique({ where: { id: q_id } }))
    );

    if (findQuestions.includes(null)) {
      return next(new AppError("One or more questions not found", 404));
    }
    const totalPoints = findQuestions.reduce((prev,curr)=>prev+(curr?.points || 0),0)

    const updated = await prisma.quiz.update({
      where: { id },
      
      data: {
        totalPoints ,
        questions: {
          connect: questions.map(q_id => ({ id: q_id })),
        },
      },
      
      include: { creator: true, topic: true },
    });

    res.status(200).json({
      success: true,
      message: "Quiz questions updated successfully",
      data: updated,
    });
  } catch (error) {
    logger.error({ error }, "Error updating quiz");
    return next(new AppError("An error occurred while updating quiz", 500));
  }
});
