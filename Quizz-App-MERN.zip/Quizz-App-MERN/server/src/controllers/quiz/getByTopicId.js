import { prisma } from "../../config/prisma.js";
import { asyncHandler } from "../../middlewares/asyncHandler.js";

export const getByTopicId =  asyncHandler(async (req, res, next) => {
  const { id } = req.params;
  if(!id){
    res.status(404).json({
        message : "id not found",
        success : false
    })
  }

  const quiz = await prisma.quiz.findMany({
    where: { topicId : id },
    include: {
      creator: true,
      topic: true,
      questions: true,
      history: true,
    },
  });

  if (!quiz) return next(new AppError("Quiz not found", 404));

  res.status(200).json({
    success: true,
    message: "Quiz fetched successfully",
    data: quiz,
  });
});
