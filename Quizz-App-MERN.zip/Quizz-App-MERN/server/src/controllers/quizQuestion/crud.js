import { prisma } from "../../config/prisma.js";
import { asyncHandler } from "../../middlewares/asyncHandler.js";
import AppError from "../../utils/AppError.js";
import logger from "../../utils/logger.js";

/**
 * Get all QuizQuestion entries
 * Optional filters: quizId, questionId
 */
export const getQuizQuestions = asyncHandler(async (req, res, next) => {
  const { quizId, questionId } = req.query;

  const filters = {};
  if (quizId) filters.quizId = quizId;
  if (questionId) filters.questionId = questionId;

  const quizQuestions = await prisma.quizQuestion.findMany({
    where: filters,
    include: { quiz: true, question: true },
    orderBy: { id: "asc" },
  });

  if (!quizQuestions.length) return next(new AppError("No quiz questions found", 404));

  res.status(200).json({
    success: true,
    message: "Quiz questions fetched successfully",
    count: quizQuestions.length,
    data: quizQuestions,
  });
});

/**
 * Get QuizQuestion by ID
 */
export const getQuizQuestionById = asyncHandler(async (req, res, next) => {
  const { id } = req.params;

  const quizQuestion = await prisma.quizQuestion.findUnique({
    where: { id },
    include: { quiz: true, question: true },
  });

  if (!quizQuestion) return next(new AppError("QuizQuestion not found", 404));

  res.status(200).json({
    success: true,
    message: "QuizQuestion fetched successfully",
    data: quizQuestion,
  });
});

/**
 * Create a single QuizQuestion
 */
export const createQuizQuestion = asyncHandler(async (req, res, next) => {
  const { quizId, questionId } = req.body;

  if (!quizId || !questionId)
    return next(new AppError("quizId and questionId are required", 400));

  try {
    const quizQuestion = await prisma.quizQuestion.create({
      data: { quizId, questionId },
      include: { quiz: true, question: true },
    });

    logger.info({ id: quizQuestion.id }, "QuizQuestion created successfully");

    res.status(201).json({
      success: true,
      message: "QuizQuestion created successfully",
      data: quizQuestion,
    });
  } catch (error) {
    // Prisma unique constraint violation
    if (error.code === "P2002") {
      return next(new AppError("This question already exists in the quiz", 400));
    }

    logger.error({ error }, "Error creating QuizQuestion");
    return next(new AppError("An error occurred while creating QuizQuestion", 500));
  }
});

/**
 * Create multiple QuizQuestions (bulk)
 */
export const createManyQuizQuestions = asyncHandler(async (req, res, next) => {
  const { quizQuestions } = req.body;

  if (!Array.isArray(quizQuestions) || quizQuestions.length === 0) {
    return next(new AppError("quizQuestions array is required and cannot be empty", 400));
  }

  try {
    const formatted = quizQuestions.map(q => ({
      quizId: q.quizId,
      questionId: q.questionId,
    }));

    const created = await prisma.quizQuestion.createMany({
      data: formatted,
      skipDuplicates: true, // Prevent duplicate quiz-question pairs
    });

    res.status(201).json({
      success: true,
      message: "QuizQuestions created successfully",
      count: created.count,
    });
  } catch (error) {
    logger.error({ error }, "Error creating QuizQuestions");
    return next(new AppError("An error occurred while creating QuizQuestions", 500));
  }
});

/**
 * Delete a QuizQuestion by ID
 */
export const deleteQuizQuestion = asyncHandler(async (req, res, next) => {
  const { id } = req.params;

  try {
    await prisma.quizQuestion.delete({ where: { id } });
    res.status(200).json({
      success: true,
      message: "QuizQuestion deleted successfully",
    });
  } catch (error) {
    if (error.code === "P2025") return next(new AppError("QuizQuestion not found", 404));

    logger.error({ error }, "Error deleting QuizQuestion");
    return next(new AppError("An error occurred while deleting QuizQuestion", 500));
  }
});
