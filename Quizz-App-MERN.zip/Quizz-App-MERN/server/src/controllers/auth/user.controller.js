import { prisma } from "../../config/prisma.js";
import { asyncHandler } from "../../middlewares/asyncHandler.js";
import AppError from "../../utils/AppError.js";

/**
 * Get all users (admin only)
 */
export const getUsers = asyncHandler(async (req, res, next) => {
  const users = await prisma.user.findMany({ orderBy: { createdAt: "desc" } });
  res.status(200).json({
    success: true,
    message: "Users fetched successfully",
    count: users.length,
    data: users,
  });
});

/**
 * Get user by ID (admin only)
 */
export const getUserById = asyncHandler(async (req, res, next) => {
  const { id } = req.params;
  const user = await prisma.user.findUnique({ where: { id } });
  if (!user) return next(new AppError("User not found", 404));

  res.status(200).json({
    success: true,
    message: "User fetched successfully",
    data: user,
  });
});

/**
 * Delete user (admin only)
 */
export const deleteUser = asyncHandler(async (req, res, next) => {
  const { id } = req.params;
  await prisma.user.delete({ where: { id } });

  res.status(200).json({
    success: true,
    message: "User deleted successfully",
  });
});
