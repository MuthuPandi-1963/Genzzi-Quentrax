import { prisma } from "../../prismaClient.js";
export const getAssessmentAssignments = async (req, res) => {
  try {
    const assessmentId = req.params.id;

    const assignments = await prisma.assessmentAssignment.findMany({
      where: { assessmentId },
      include: {
        user: {
          select: {
            id: true,
            name: true,
            email: true,
            role: true,
          },
        },
      },
    });

    return res.status(200).json({
      success: true,
      data: assignments,
    });
  } catch (error) {
    console.error("getAssessmentAssignments error:", error);

    return res.status(500).json({
      success: false,
      message: "Server error",
      error: error.message,
    });
  }
};