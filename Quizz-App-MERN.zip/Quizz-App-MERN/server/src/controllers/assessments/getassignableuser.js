import { prisma } from "../../prismaClient.js";
export const getAssignableUsers = async (req, res) => {
  try {
    const { role } = req.query;

    const users = await prisma.user.findMany({
      where: {
        role: role
          ? role
          : {
              not: "ADMIN",
            },
      },
      select: {
        id: true,
        name: true,
        email: true,
        role: true,
      },
      orderBy: {
        createdAt: "desc",
      },
    });

    return res.status(200).json({
      success: true,
      data: users,
    });
  } catch (error) {
    console.error("getAssignableUsers error:", error);

    return res.status(500).json({
      success: false,
      message: "Server error",
      error: error.message,
    });
  }
};