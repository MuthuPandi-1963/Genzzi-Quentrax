import { prisma } from "../lib/prisma.js";

/**
 * Assign users to an assessment
 * POST /api/assessments/:id/assign-users
 */
export const assignUsersToAssessment = async (req, res) => {
  try {
    const assessmentId = req.params.id;
    const { userIds } = req.body;

    if (!userIds || !Array.isArray(userIds)) {
      return res.status(400).json({
        success: false,
        message: "userIds must be an array",
      });
    }

    // 1. Validate assessment exists
    const assessment = await prisma.assessment.findUnique({
      where: { id: assessmentId },
    });

    if (!assessment) {
      return res.status(404).json({
        success: false,
        message: "Assessment not found",
      });
    }

    // 2. Get valid users (exclude ADMIN)
    const users = await prisma.user.findMany({
      where: {
        id: { in: userIds },
        role: { not: "ADMIN" },
      },
      select: { id: true },
    });

    const validUserIds = users.map((u) => u.id);

    if (validUserIds.length === 0) {
      return res.status(400).json({
        success: false,
        message: "No valid users found for assignment",
      });
    }

    // 3. Create assignments (bulk upsert safe)
    const assignments = await prisma.$transaction(
      validUserIds.map((userId) =>
        prisma.assessmentAssignment.upsert({
          where: {
            assessmentId_userId: {
              assessmentId,
              userId,
            },
          },
          update: {
            status: "ASSIGNED",
          },
          create: {
            assessmentId,
            userId,
            status: "ASSIGNED",
          },
        })
      )
    );

    return res.status(200).json({
      success: true,
      message: "Users assigned successfully",
      data: assignments,
    });
  } catch (error) {
    console.error("assignUsersToAssessment error:", error);

    return res.status(500).json({
      success: false,
      message: "Server error",
      error: error.message,
    });
  }
};