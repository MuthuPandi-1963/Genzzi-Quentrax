import { PrismaClient } from "@prisma/client";

// Central Prisma Client instance.
// Some controllers/routes in this codebase import from `src/prismaClient.js`.
// Keep this file minimal and compatible.

const globalForPrisma = globalThis;

const prisma =
  globalForPrisma.prisma ||
  new PrismaClient({
    log: globalForPrisma.process?.env?.NODE_ENV === "development" ? ["query", "error"] : ["error"],
  });

if (globalForPrisma.process?.env?.NODE_ENV !== "production") globalForPrisma.prisma = prisma;


export { prisma };

