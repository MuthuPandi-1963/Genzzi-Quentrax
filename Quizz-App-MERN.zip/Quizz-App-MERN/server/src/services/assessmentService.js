import { prisma } from "../config/prisma.js";
import logger from "../utils/logger.js";

/**
 * Assessment Service Layer
 * Contains business logic for assessment operations
 */

// ==================== ASSESSMENT SERVICES ====================

/**
 * Create a new assessment
 * @param {Object} assessmentData - Assessment data
 * @param {string} creatorId - ID of the user creating the assessment
 * @returns {Promise<Object>} Created assessment
 */
export const createAssessmentService = async (assessmentData, creatorId) => {
  const {
    title,
    description,
    topicId,
    quizId,
    deadline,
    scheduledAt,
    timeLimit,
    startDate,
    endDate,
    passingScore,
    maxAttempts,
    maxViolations,
    proctoredMode,
    shuffleQuestions,
    shuffleOptions,
    allowReview,
    allowRetry,
    showResultImmediately,
  } = assessmentData;

  const assessment = await prisma.assessment.create({
    data: {
      title: title.trim(),
      description: description || null,
      topicId: topicId || null,
      quizId: quizId || null,
      deadline: deadline ? new Date(deadline) : null,
      scheduledAt: scheduledAt ? new Date(scheduledAt) : null,
      timeLimit: timeLimit || null,
      startDate: startDate ? new Date(startDate) : null,
      endDate: endDate ? new Date(endDate) : null,
      passingScore: passingScore ?? 50,
      maxAttempts: maxAttempts ?? 1,
      maxViolations: maxViolations ?? 3,
      proctoredMode: proctoredMode ?? false,
      shuffleQuestions: shuffleQuestions ?? false,
      shuffleOptions: shuffleOptions ?? false,
      allowReview: allowReview ?? true,
      allowRetry: allowRetry ?? true,
      showResultImmediately: showResultImmediately ?? true,
      creatorId,
    },
    include: {
      creator: { select: { id: true, name: true, email: true } },
      topic: true,
      quiz: true,
    },
  });

  logger.info({ id: assessment.id, creatorId }, "Assessment created via service");
  return assessment;
};

/**
 * Get assessments with filters
 * @param {Object} filters - Filter criteria
 * @returns {Promise<Array>} List of assessments
 */
export const getAssessmentsService = async (filters = {}) => {
  const { status, topicId, creatorId, published, page = 1, limit = 10 } = filters;

  const where = {};
  if (status) where.status = status;
  if (topicId) where.topicId = topicId;
  if (creatorId) where.creatorId = creatorId;
  if (published !== undefined) where.published = published === "true";

  const skip = (page - 1) * limit;

  const [assessments, total] = await Promise.all([
    prisma.assessment.findMany({
      where,
      include: {
        creator: { select: { id: true, name: true, email: true, avatar: true } },
        topic: { include: { category: true } },
        quiz: true,
        assignments: {
          include: {
            user: { select: { id: true, name: true, email: true } },
          },
        },
        _count: {
          select: { attempts: true, assignments: true },
        },
      },
      orderBy: { createdAt: "desc" },
      skip,
      take: parseInt(limit),
    }),
    prisma.assessment.count({ where }),
  ]);

  return {
    data: assessments,
    total,
    page: parseInt(page),
    totalPages: Math.ceil(total / limit),
  };
};

/**
 * Get assessment by ID
 * @param {string} id - Assessment ID
 * @returns {Promise<Object|null>} Assessment data
 */
export const getAssessmentByIdService = async (id) => {
  return prisma.assessment.findUnique({
    where: { id },
    include: {
      creator: { select: { id: true, name: true, email: true, avatar: true } },
      topic: { include: { category: true } },
      quiz: { include: { questions: true } },
      assignments: {
        include: {
          user: { select: { id: true, name: true, email: true } },
        },
      },
      attempts: {
        orderBy: { startedAt: "desc" },
      },
      _count: {
        select: { attempts: true, assignments: true },
      },
    },
  });
};

/**
 * Update assessment
 * @param {string} id - Assessment ID
 * @param {Object} updateData - Data to update
 * @returns {Promise<Object>} Updated assessment
 */
export const updateAssessmentService = async (id, updateData) => {
  // Convert date strings to Date objects
  const data = { ...updateData };
  if (data.deadline) data.deadline = new Date(data.deadline);
  if (data.scheduledAt) data.scheduledAt = new Date(data.scheduledAt);
  if (data.startDate) data.startDate = new Date(data.startDate);
  if (data.endDate) data.endDate = new Date(data.endDate);

  // Remove read-only fields
  delete data.id;
  delete data.creatorId;
  delete data.createdAt;
  delete data.updatedAt;

  const updated = await prisma.assessment.update({
    where: { id },
    data,
    include: {
      creator: { select: { id: true, name: true, email: true } },
      topic: { include: { category: true } },
      quiz: true,
    },
  });

  logger.info({ id, updatedBy: updateData.updatedBy }, "Assessment updated via service");
  return updated;
};

/**
 * Delete assessment
 * @param {string} id - Assessment ID
 * @returns {Promise<void>}
 */
export const deleteAssessmentService = async (id) => {
  await prisma.assessment.delete({ where: { id } });
  logger.info({ id }, "Assessment deleted via service");
};

// ==================== ASSESSMENT ATTEMPT SERVICES ====================

/**
 * Start an assessment attempt
 * @param {string} assessmentId - Assessment ID
 * @param {string} userId - User ID
 * @returns {Promise<Object>} Attempt data with questions
 */
export const startAssessmentService = async (assessmentId, userId) => {
  const assessment = await prisma.assessment.findUnique({
    where: { id: assessmentId },
    include: {
      quiz: { include: { questions: true } },
      topic: true,
    },
  });

  if (!assessment) {
    throw new Error("Assessment not found");
  }

  if (!assessment.published) {
    throw new Error("Assessment is not published");
  }

  // Check availability window
  const now = new Date();
  if (assessment.startDate && now < new Date(assessment.startDate)) {
    throw new Error("Assessment has not started yet");
  }
  if (assessment.endDate && now > new Date(assessment.endDate)) {
    throw new Error("Assessment has expired");
  }

  // Check assignment
  const assignment = await prisma.assessmentAssignment.findUnique({
    where: {
      assessmentId_userId: {
        assessmentId,
        userId,
      },
    },
  });

  if (!assignment) {
    throw new Error("You are not assigned to this assessment");
  }

  // Check max attempts
  const attemptCount = await prisma.assessmentAttempt.count({
    where: { assessmentId, userId },
  });

  if (attemptCount >= assessment.maxAttempts) {
    throw new Error(`Maximum attempts (${assessment.maxAttempts}) reached`);
  }

  // Create attempt
  const attempt = await prisma.assessmentAttempt.create({
    data: {
      assessmentId,
      userId,
      status: "IN_PROGRESS",
      startedAt: now,
      answers: {},
      score: 0,
    },
  });

  // Update assignment status
  await prisma.assessmentAssignment.update({
    where: { id: assignment.id },
    data: { status: "IN_PROGRESS", startedAt: now },
  });

  // Prepare questions
  let questions = assessment.quiz?.questions || [];
  if (assessment.shuffleQuestions) {
    questions = questions.sort(() => Math.random() - 0.5);
  }
  if (assessment.shuffleOptions) {
    questions = questions.map((q) => {
      if (q.options && Array.isArray(q.options)) {
        return { ...q, options: [...q.options].sort(() => Math.random() - 0.5) };
      }
      return q;
    });
  }

  // Sanitize questions (remove correct answers)
  const sanitizedQuestions = questions.map((q) => ({
    id: q.id,
    questionText: q.questionText,
    questionType: q.questionType,
    options: q.options,
    points: q.points,
    hints: assessment.allowReview ? q.hints : [],
  }));

  return {
    attemptId: attempt.id,
    assessment: {
      id: assessment.id,
      title: assessment.title,
      timeLimit: assessment.timeLimit,
      proctoredMode: assessment.proctoredMode,
      allowReview: assessment.allowReview,
      startedAt: now,
    },
    questions: sanitizedQuestions,
  };
};

/**
 * Submit assessment attempt
 * @param {string} assessmentId - Assessment ID
 * @param {string} userId - User ID
 * @param {string} attemptId - Attempt ID
 * @param {Object} answers - User answers
 * @returns {Promise<Object>} Result with score
 */
export const submitAssessmentService = async (assessmentId, userId, attemptId, answers) => {
  const assessment = await prisma.assessment.findUnique({
    where: { id: assessmentId },
    include: { quiz: { include: { questions: true } } },
  });

  if (!assessment) {
    throw new Error("Assessment not found");
  }

  const attempt = await prisma.assessmentAttempt.findFirst({
    where: { id: attemptId, assessmentId, userId, status: "IN_PROGRESS" },
  });

  if (!attempt) {
    throw new Error("No active attempt found");
  }

  // Calculate score
  let score = 0;
  const questionResults = [];

  for (const question of assessment.quiz?.questions || []) {
    const userAnswer = answers[question.id];
    const isCorrect = checkAnswer(question, userAnswer);

    if (isCorrect) {
      score += question.points || 1;
    }

    questionResults.push({
      questionId: question.id,
      isCorrect,
      userAnswer,
      points: question.points || 1,
    });
  }

  // Update attempt and assignment
  await Promise.all([
    prisma.assessmentAttempt.update({
      where: { id: attemptId },
      data: {
        status: "COMPLETED",
        completedAt: new Date(),
        answers,
        score,
      },
    }),
    prisma.assessmentAssignment.updateMany({
      where: { assessmentId, userId },
      data: { status: "COMPLETED", completedAt: new Date() },
    }),
  ]);

  return {
    score,
    totalQuestions: assessment.quiz?.questions.length || 0,
    correctAnswers: questionResults.filter((r) => r.isCorrect).length,
    passingScore: assessment.passingScore,
    passed: score >= assessment.passingScore,
  };
};

// ==================== ASSIGNMENT SERVICES ====================

/**
 * Assign users to assessment
 * @param {string} assessmentId - Assessment ID
 * @param {string[]} userIds - Array of user IDs
 * @param {Date} dueDate - Optional due date
 * @returns {Promise<Object>} Assignment result
 */
export const assignUsersService = async (assessmentId, userIds, dueDate) => {
  const assessment = await prisma.assessment.findUnique({ where: { id: assessmentId } });

  if (!assessment) {
    throw new Error("Assessment not found");
  }

  const result = await prisma.assessmentAssignment.createMany({
    data: userIds.map((userId) => ({
      assessmentId,
      userId,
      dueDate: dueDate ? new Date(dueDate) : assessment.deadline,
      status: "PENDING",
    })),
    skipDuplicates: true,
  });

  logger.info({ assessmentId, userIds, count: result.count }, "Users assigned via service");
  return { count: result.count };
};

/**
 * Get assigned users for an assessment
 * @param {string} assessmentId - Assessment ID
 * @param {string} status - Optional status filter
 * @returns {Promise<Array>} List of assignments
 */
export const getAssignedUsersService = async (assessmentId, status) => {
  const where = { assessmentId };
  if (status) where.status = status;

  return prisma.assessmentAssignment.findMany({
    where,
    include: {
      user: { select: { id: true, name: true, email: true, avatar: true } },
      assessment: { select: { id: true, title: true, deadline: true } },
    },
    orderBy: { assignedAt: "desc" },
  });
};

/**
 * Remove user from assessment
 * @param {string} assessmentId - Assessment ID
 * @param {string} userId - User ID
 * @returns {Promise<void>}
 */
export const removeUserFromAssessmentService = async (assessmentId, userId) => {
  await prisma.assessmentAssignment.delete({
    where: {
      assessmentId_userId: { assessmentId, userId },
    },
  });
  logger.info({ assessmentId, userId }, "User removed via service");
};

/**
 * Update assignment status
 * @param {string} assessmentId - Assessment ID
 * @param {string} userId - User ID
 * @param {Object} updateData - Update data
 * @returns {Promise<Object>} Updated assignment
 */
export const updateAssignmentService = async (assessmentId, userId, updateData) => {
  const data = { ...updateData };
  if (data.dueDate) data.dueDate = new Date(data.dueDate);

  const updated = await prisma.assessmentAssignment.update({
    where: {
      assessmentId_userId: { assessmentId, userId },
    },
    data,
    include: {
      user: { select: { id: true, name: true, email: true } },
    },
  });

  logger.info({ assessmentId, userId, newStatus: data.status }, "Assignment updated via service");
  return updated;
};

/**
 * Get user's assessments
 * @param {string} userId - User ID
 * @returns {Promise<Array>} List of assessments
 */
export const getUserAssessmentsService = async (userId) => {
  return prisma.assessmentAssignment.findMany({
    where: { userId },
    include: {
      assessment: {
        include: {
          topic: { include: { category: true } },
          creator: { select: { id: true, name: true } },
        },
      },
    },
    orderBy: { assignedAt: "desc" },
  });
};

/**
 * Get authenticated user's assessments with categorization
 * @param {string} userId - User ID
 * @returns {Promise<Object>} Categorized assessments
 */
export const getMyAssessmentsService = async (userId) => {
  const assignments = await prisma.assessmentAssignment.findMany({
    where: { userId },
    include: {
      assessment: {
        include: {
          topic: { include: { category: true } },
          creator: { select: { id: true, name: true } },
          _count: { select: { attempts: true } },
        },
      },
    },
    orderBy: { assignedAt: "desc" },
  });

  const now = new Date();
  const activeAssessments = [];
  const upcomingAssessments = [];
  const expiredAssessments = [];

  assignments.forEach(({ assessment, status }) => {
    if (!assessment.published) return;

    const startDate = assessment.startDate ? new Date(assessment.startDate) : null;
    const endDate = assessment.endDate ? new Date(assessment.endDate) : null;

    const assessmentData = { ...assessment, assignmentStatus: status };

    if (startDate && now < startDate) {
      upcomingAssessments.push(assessmentData);
    } else if (endDate && now > endDate) {
      expiredAssessments.push(assessmentData);
    } else {
      activeAssessments.push(assessmentData);
    }
  });

  return {
    assessments: assignments.map((a) => a.assessment),
    activeAssessments,
    upcomingAssessments,
    expiredAssessments,
  };
};

// ==================== HELPER FUNCTIONS ====================

/**
 * Check if an answer is correct
 * @param {Object} question - Question object
 * @param {*} userAnswer - User's answer
 * @returns {boolean} Whether the answer is correct
 */
function checkAnswer(question, userAnswer) {
  if (!question.options || !Array.isArray(question.options)) {
    return false;
  }

  const correctOptions = question.options.filter((opt) => opt.isCorrect);

  switch (question.questionType) {
    case "MCQ":
      if (correctOptions.length === 1) {
        return userAnswer === correctOptions[0].text;
      }
      if (Array.isArray(userAnswer)) {
        const correctTexts = correctOptions.map((opt) => opt.text).sort();
        const userTexts = userAnswer.sort();
        return JSON.stringify(correctTexts) === JSON.stringify(userTexts);
      }
      return false;

    case "TRUE_FALSE":
      return userAnswer === correctOptions[0].text;

    case "FILL_BLANK":
      return (
        userAnswer &&
        correctOptions.some(
          (opt) => opt.text.toLowerCase().trim() === userAnswer.toLowerCase().trim()
        )
      );

    default:
      return false;
  }
}

// ==================== STATISTICS SERVICES ====================

/**
 * Get assessment completion statistics
 * @param {string} assessmentId - Assessment ID
 * @returns {Promise<Object>} Statistics data
 */
export const getAssessmentStatsService = async (assessmentId) => {
  const assessment = await prisma.assessment.findUnique({
    where: { id: assessmentId },
    include: {
      assignments: {
        include: {
          user: { select: { id: true, name: true, email: true } },
        },
      },
      attempts: {
        orderBy: { completedAt: "desc" },
      },
    },
  });

  if (!assessment) {
    throw new Error("Assessment not found");
  }

  const totalAssigned = assessment.assignments.length;
  const completed = assessment.assignments.filter((a) => a.status === "COMPLETED").length;
  const inProgress = assessment.assignments.filter((a) => a.status === "IN_PROGRESS").length;
  const pending = assessment.assignments.filter((a) => a.status === "PENDING").length;

  const completedAttempts = assessment.attempts.filter((a) => a.status === "COMPLETED");
  const avgScore =
    completedAttempts.length > 0
      ? completedAttempts.reduce((sum, a) => sum + a.score, 0) / completedAttempts.length
      : 0;

  const passed = completedAttempts.filter((a) => a.score >= assessment.passingScore).length;
  const failed = completedAttempts.length - passed;

  return {
    assessment: {
      id: assessment.id,
      title: assessment.title,
      passingScore: assessment.passingScore,
    },
    statistics: {
      totalAssigned,
      completed,
      inProgress,
      pending,
      completionRate: totalAssigned > 0 ? (completed / totalAssigned) * 100 : 0,
      averageScore: Math.round(avgScore),
      passRate: completedAttempts.length > 0 ? (passed / completedAttempts.length) * 100 : 0,
      passed,
      failed,
    },
    attempts: assessment.attempts.map((a) => ({
      id: a.id,
      userId: a.userId,
      score: a.score,
      status: a.status,
      startedAt: a.startedAt,
      completedAt: a.completedAt,
    })),
  };
};