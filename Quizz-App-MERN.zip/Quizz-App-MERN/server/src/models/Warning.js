const mongoose = require('mongoose');

const warningSchema = new mongoose.Schema({
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  quiz: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Quiz',
    required: true
  },
  type: {
    type: String,
    required: true,
    enum: [
      'RIGHT_CLICK',
      'COPY_PASTE',
      'KEYBOARD_SHORTCUT',
      'TAB_SWITCH',
      'EXIT_FULLSCREEN',
      'DEVTOOLS_OPENED',
      'DEVTOOLS_KEY',
      'DEVTOOLS_SHORTCUT',
      'PRINT_SCREEN',
      'PAGE_REFRESH',
      'OTHER'
    ]
  },
  timestamp: {
    type: Date,
    default: Date.now,
    required: true
  },
  metadata: {
    warningCount: {
      type: Number,
      default: 0
    },
    ipAddress: String,
    userAgent: String,
    additionalInfo: mongoose.Schema.Types.Mixed
  }
}, {
  timestamps: true
});

// Index for efficient querying
warningSchema.index({ quiz: 1, timestamp: -1 });
warningSchema.index({ user: 1, timestamp: -1 });
warningSchema.index({ type: 1 });

module.exports = mongoose.model('Warning', warningSchema);