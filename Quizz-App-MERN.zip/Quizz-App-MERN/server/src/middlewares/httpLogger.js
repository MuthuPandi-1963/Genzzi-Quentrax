// middlewares/httpLogger.js
import pinoHttp from "pino-http";
import { UAParser } from "ua-parser-js";
import logger from "../utils/logger.js";
import crypto from "crypto";

const httpLogger = pinoHttp({
  logger,
  autoLogging: true, // Automatically log all requests
  customProps: (req, res) => {
    const parser = new UAParser(req.headers["user-agent"]);
    const deviceInfo = parser.getResult();

    return {
      requestId: crypto.randomUUID(), // Unique ID for each request
      device: {
        type: deviceInfo.device.type || "desktop",
        brand: deviceInfo.device.vendor || "Unknown",
        os: deviceInfo.os.name,
        browser: deviceInfo.browser.name,
      },
      clientIp: req.headers["x-forwarded-for"] || req.connection.remoteAddress,
    };
  },
  serializers: {
    req(req) {
      return {
        method: req.method,
        url: req.url,
        query: req.query,
        params: req.params,
        headers: req.headers,
        body: req.raw.body || {},
      };
    },
    res(res) {
      return {
        statusCode: res.statusCode,
        responseTime: res.responseTime, // ms
      };
    },
    err(err) {
      return {
        type: err.type,
        message: err.message,
        stack: err.stack,
      };
    },
  },
});

export default httpLogger;
