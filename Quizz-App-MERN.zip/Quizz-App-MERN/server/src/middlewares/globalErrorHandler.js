// middlewares/globalErrorHandler.js
import logger from "../utils/logger.js";

export const globalErrorHandler = (err, req, res, next) => {
  logger.error({ err, url: req.originalUrl }, "Error caught in global handler");

  const statusCode = err.statusCode || 500;
  const message = err.message || "Internal Server Error";

  res.status(statusCode).json({
    success: false,
    message,
    ...(process.env.NODE_ENV === "development" && { stack: err.stack }),
  });
};
 