export const errorHandler = (err, req, res, next) => {
  console.error("Error:", err);

  // Prisma known errors
  if (err.code === "P2002") {
    return res.status(400).json({
      success: false,
      message: "Duplicate field value entered.",
      meta: err.meta,
    });
  }

  if (err.code === "P2025") {
    return res.status(404).json({
      success: false,
      message: "Record not found.",
    });
  }

  // Validation errors
  if (err.name === "ValidationError") {
    return res.status(400).json({
      success: false,
      message: err.message,
    });
  }

  // Default error
  res.status(500).json({
    success: false,
    message: "Internal Server Error",
    error: err.message,
  });
};
