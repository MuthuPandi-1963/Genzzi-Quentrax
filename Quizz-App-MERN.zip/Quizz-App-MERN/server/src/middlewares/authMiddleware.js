import jwt from "jsonwebtoken";
import { asyncHandler } from "./asyncHandler.js";
import { prisma } from "../config/prisma.js";
import AppError from "../utils/AppError.js";

export const protect = asyncHandler(async (req, res, next) => {
  let token;

  if (req.headers.authorization?.startsWith("Bearer")) {
    token = req.headers.authorization.split(" ")[1];
  } else if (req.cookies?.token) {
    token = req.cookies.token;
  }

  if (!token) return next(new AppError("Not authorized, token missing", 401));

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    const user = await prisma.user.findUnique({ where: { id: decoded.id } });

    if (!user) return next(new AppError("Not authorized, user not found", 401));
    if (user.isBlocked) return next(new AppError("Account is blocked", 403));

    const { password, verificationToken, ...safeUser } = user;
    req.user = safeUser;
    next();
  } catch (error) {
    if (error.name === "TokenExpiredError") {
      return next(new AppError("Token expired, please login again", 401));
    }
    if (error.name === "JsonWebTokenError") {
      return next(new AppError("Invalid token, please login again", 401));
    }
    throw error;
  }
});

/** Optional auth — attaches user when token present */
export const optionalAuth = asyncHandler(async (req, res, next) => {
  let token;
  if (req.headers.authorization?.startsWith("Bearer")) {
    token = req.headers.authorization.split(" ")[1];
  } else if (req.cookies?.token) {
    token = req.cookies.token;
  }
  if (token) {
    try {
      const decoded = jwt.verify(token, process.env.JWT_SECRET);
      const user = await prisma.user.findUnique({ where: { id: decoded.id } });
      if (user && !user.isBlocked) {
        const { password, verificationToken, ...safeUser } = user;
        req.user = safeUser;
      }
    } catch {
      /* ignore invalid token */
    }
  }
  next();
});
