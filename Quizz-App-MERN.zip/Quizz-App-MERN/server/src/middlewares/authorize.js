import AppError from "../utils/AppError.js";

/** Restrict route to one or more roles (e.g. authorize("ADMIN", "STAFF")) */
export const authorize =
  (...roles) =>
  (req, res, next) => {
    if (!req.user) {
      return next(new AppError("Not authorized", 401));
    }
    if (!roles.includes(req.user.role)) {
      return next(new AppError("Forbidden: insufficient permissions", 403));
    }
    next();
  };
