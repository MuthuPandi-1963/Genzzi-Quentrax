import { Router } from "express";
import {
  getTopics,
  getTopicById,
  createTopic,
  createManyTopics,
  updateTopic,
  deleteTopic,
} from "../controllers/topics/crud.js";
import { protect } from "../middlewares/authMiddleware.js";
import { authorize } from "../middlewares/authorize.js";

const topicsRoutes = Router();
const staffAdmin = [protect, authorize("STAFF", "ADMIN")];

topicsRoutes.get("/", getTopics);
topicsRoutes.get("/:id", getTopicById);
topicsRoutes.post("/", ...staffAdmin, createTopic);
topicsRoutes.post("/many", ...staffAdmin, createManyTopics);
topicsRoutes.put("/:id", ...staffAdmin, updateTopic);
topicsRoutes.delete("/:id", ...staffAdmin, deleteTopic);

export default topicsRoutes;
