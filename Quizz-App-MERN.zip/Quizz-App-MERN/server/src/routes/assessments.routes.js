import { Router } from "express";
import {
  createAssessment,
  getAssessments,
  getAssessmentById,
  updateAssessment,
  deleteAssessment,
  submitAssessmentAttempt,
  getAssessmentCompletion,
  getAvailableTopics,
  startAssessment,
  assignUsersToAssessment,
  getAssignedUsers,
  removeUserFromAssessment,
  updateAssignmentStatus,
  getUserAssessments,
  getMyAssessments,
} from "../controllers/assessmentController.js";

import { protect } from "../middlewares/authMiddleware.js";
import { authorize } from "../middlewares/authorize.js";

const router = Router();

router.use(protect);

router.get("/topics", getAvailableTopics);

router.post("/", authorize("ADMIN", "STAFF"), createAssessment);

router.get("/", getAssessments);

router.get("/my", getMyAssessments);

router.get("/user/:userId", authorize("ADMIN", "STAFF"), getUserAssessments);

router.get("/:id", getAssessmentById);

router.put("/:id", authorize("ADMIN", "STAFF"), updateAssessment);

router.delete("/:id", authorize("ADMIN", "STAFF"), deleteAssessment);

router.post(
  "/:id/publish",
  authorize("ADMIN", "STAFF"),
  async (req, res, next) => {
    try {
      const { id } = req.params;
      const { prisma } = await import("../config/prisma.js");

      const updated = await prisma.assessment.update({
        where: { id },
        data: { published: true },
      });

      res.status(200).json({
        success: true,
        message: "Assessment published successfully",
        data: updated,
      });
    } catch (error) {
      next(error);
    }
  }
);


router.post("/:id/start", startAssessment);

router.post("/:id/submit", submitAssessmentAttempt);

router.get("/:id/completion", getAssessmentCompletion);

// Spec alias (keeps backward compatibility)
router.get("/:id/results", getAssessmentCompletion);


router.post(
  "/:id/assign-users",
  authorize("ADMIN", "STAFF"),
  assignUsersToAssessment
);

router.get(
  "/:id/assignments",
  authorize("ADMIN", "STAFF"),
  getAssignedUsers
);

router.delete(
  "/:id/assignments/:userId",
  authorize("ADMIN", "STAFF"),
  removeUserFromAssessment
);

router.put(
  "/:id/assignments/:userId",
  authorize("ADMIN", "STAFF"),
  updateAssignmentStatus
);

export default router;