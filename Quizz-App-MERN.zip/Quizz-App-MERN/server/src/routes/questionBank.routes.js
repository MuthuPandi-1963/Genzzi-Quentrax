import express from 'express';
import { prisma } from '../config/prisma.js';

const router = express.Router();

// Create a new question bank
router.post('/', async (req, res) => {
  try {
    const { name, description, subject, category, tags, createdBy, isPublic, quizId } = req.body;

    const questionBank = await prisma.questionBank.create({
      data: {
        name,
        description,
        subject,
        category,
        tags: tags || [],
        createdBy,
        isPublic: isPublic || false,
        quizId: quizId || null
      }
    });

    res.status(201).json({
      success: true,
      data: questionBank
    });

  } catch (error) {
    console.error('Error creating question bank:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to create question bank'
    });
  }
});

// Get all question banks
router.get('/', async (req, res) => {
  try {
    const { subject, category, isPublic, createdBy, search } = req.query;

    const where = {};
    if (subject) where.subject = subject;
    if (category) where.category = category;
    if (isPublic !== undefined) where.isPublic = isPublic === 'true';
    if (createdBy) where.createdBy = createdBy;
    if (search) {
      where.OR = [
        { name: { contains: search, mode: 'insensitive' } },
        { description: { contains: search, mode: 'insensitive' } }
      ];
    }

    const questionBanks = await prisma.questionBank.findMany({
      where,
      include: {
        questions: {
          include: {
            question: {
              select: {
                id: true,
                questionText: true,
                questionType: true,
                difficulty: true,
                marks: true
              }
            }
          },
          orderBy: { order: 'asc' }
        },
        creator: {
          select: { id: true, name: true, email: true }
        }
      },
      orderBy: { createdAt: 'desc' }
    });

    res.json({
      success: true,
      data: questionBanks
    });

  } catch (error) {
    console.error('Error fetching question banks:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch question banks'
    });
  }
});

// Get a single question bank
router.get('/:id', async (req, res) => {
  try {
    const { id } = req.params;

    const questionBank = await prisma.questionBank.findUnique({
      where: { id },
      include: {
        questions: {
          include: {
            question: true
          },
          orderBy: { order: 'asc' }
        },
        creator: {
          select: { id: true, name: true, email: true }
        }
      }
    });

    if (!questionBank) {
      return res.status(404).json({
        success: false,
        message: 'Question bank not found'
      });
    }

    res.json({
      success: true,
      data: questionBank
    });

  } catch (error) {
    console.error('Error fetching question bank:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch question bank'
    });
  }
});

// Add questions to a question bank
router.post('/:id/questions', async (req, res) => {
  try {
    const { id } = req.params;
    const { questionIds } = req.body;

    // Verify question bank exists
    const questionBank = await prisma.questionBank.findUnique({
      where: { id }
    });

    if (!questionBank) {
      return res.status(404).json({
        success: false,
        message: 'Question bank not found'
      });
    }

    // Get current max order
    const existingEntries = await prisma.questionBankEntry.findMany({
      where: { questionBankId: id },
      orderBy: { order: 'desc' },
      take: 1
    });

    const maxOrder = existingEntries.length > 0 ? existingEntries[0].order : 0;

    // Add questions
    const entries = await Promise.all(
      questionIds.map((questionId, index) =>
        prisma.questionBankEntry.create({
          data: {
            questionBankId: id,
            questionId,
            order: maxOrder + index + 1
          }
        })
      )
    );

    res.status(201).json({
      success: true,
      data: entries
    });

  } catch (error) {
    console.error('Error adding questions to bank:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to add questions to bank'
    });
  }
});

// Remove question from a question bank
router.delete('/:id/questions/:questionId', async (req, res) => {
  try {
    const { id, questionId } = req.params;

    await prisma.questionBankEntry.deleteMany({
      where: {
        questionBankId: id,
        questionId: questionId
      }
    });

    res.json({
      success: true,
      message: 'Question removed from bank'
    });

  } catch (error) {
    console.error('Error removing question from bank:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to remove question from bank'
    });
  }
});

// Update question bank
router.put('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const { name, description, subject, category, tags, isPublic } = req.body;

    const questionBank = await prisma.questionBank.update({
      where: { id },
      data: {
        name,
        description,
        subject,
        category,
        tags,
        isPublic
      }
    });

    res.json({
      success: true,
      data: questionBank
    });

  } catch (error) {
    console.error('Error updating question bank:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to update question bank'
    });
  }
});

// Delete question bank
router.delete('/:id', async (req, res) => {
  try {
    const { id } = req.params;

    await prisma.questionBank.delete({
      where: { id }
    });

    res.json({
      success: true,
      message: 'Question bank deleted'
    });

  } catch (error) {
    console.error('Error deleting question bank:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to delete question bank'
    });
  }
});

// Get questions by tags (for reuse)
router.get('/search/by-tags', async (req, res) => {
  try {
    const { tags, subject } = req.query;
    const tagArray = tags ? tags.split(',') : [];

    const where = {};
    if (subject) where.subject = subject;
    if (tagArray.length > 0) {
      where.tags = {
        hasSome: tagArray
      };
    }

    const questionBanks = await prisma.questionBank.findMany({
      where,
      include: {
        questions: {
          include: {
            question: true
          }
        },
        creator: {
          select: { id: true, name: true }
        }
      }
    });

    res.json({
      success: true,
      data: questionBanks
    });

  } catch (error) {
    console.error('Error searching question banks:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to search question banks'
    });
  }
});

export default router;