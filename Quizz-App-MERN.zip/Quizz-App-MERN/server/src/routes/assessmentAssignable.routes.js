import { Router } from "express";

import { protect } from "../middlewares/authMiddleware.js";
import { authorize } from "../middlewares/authorize.js";

import { getAssignableUsers } from "../controllers/assessments/getassignableuser.js";

const router = Router();

router.use(protect);

// Used by admin assignment modal
router.get(
  "/assignable-users",
  authorize("ADMIN", "STAFF"),
  getAssignableUsers
);

export default router;

