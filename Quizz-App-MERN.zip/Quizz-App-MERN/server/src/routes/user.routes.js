import {Router} from 'express'
import { login, logout, refreshAuth, register, verifyEmail } from '../controllers/auth/auth.controller.js';


 const AuthRoutes = Router();
AuthRoutes.post("/signup",register);
AuthRoutes.post("/login",login);
AuthRoutes.get('/verify-email',verifyEmail);
AuthRoutes.get('/refresh-token',refreshAuth);
AuthRoutes.post('/logout',logout);

export default AuthRoutes;