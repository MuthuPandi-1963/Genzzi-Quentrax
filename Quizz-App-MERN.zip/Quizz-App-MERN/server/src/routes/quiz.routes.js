import { Router } from "express";
import {
  getQuizzes,
  getQuizById,
  createQuiz,
  updateQuiz,
  deleteQuiz,
  createManyQuizzes,
} from "../controllers/quiz/crud.js";
import { getByTopicId } from "../controllers/quiz/getByTopicId.js";
import { AddQuestionsInQuiz } from "../controllers/quiz/addQuestions.js";
import { protect } from "../middlewares/authMiddleware.js";
import { authorize } from "../middlewares/authorize.js";

const quizRoutes = Router();
const staffAdmin = [protect, authorize("STAFF", "ADMIN")];

quizRoutes.get("/", getQuizzes);
quizRoutes.get("/topic/:id", getByTopicId);
quizRoutes.get("/:id", getQuizById);
quizRoutes.post("/", ...staffAdmin, createQuiz);
quizRoutes.post("/many", ...staffAdmin, createManyQuizzes);
quizRoutes.put("/:id/questions", ...staffAdmin, AddQuestionsInQuiz);
quizRoutes.put("/:id", ...staffAdmin, updateQuiz);
quizRoutes.delete("/:id", ...staffAdmin, deleteQuiz);

export default quizRoutes;
