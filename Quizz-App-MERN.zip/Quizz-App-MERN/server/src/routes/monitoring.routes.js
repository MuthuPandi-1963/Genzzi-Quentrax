import express from 'express';
import { prisma } from '../config/prisma.js';
import { protect } from '../middlewares/authMiddleware.js';

const router = express.Router();

const EVENT_TYPES = new Set([
  'TAB_SWITCH',
  'WINDOW_BLUR',
  'FULLSCREEN_EXIT',
  'PAGE_HIDDEN',
  'OTHER',
]);

function safeJson(value) {
  if (value === undefined) return undefined;
  try {
    if (typeof value === 'string') return JSON.parse(value);
    return value;
  } catch {
    return value;
  }
}

// POST /api/track-monitoring-event
router.post('/track-monitoring-event', protect, async (req, res) => {
  try {
    const userId = req.user?.id || req.user?.userId;
    if (!userId) return res.status(401).json({ success: false, message: 'Unauthorized' });

    const { attemptId, eventType, timestamp, metadata } = req.body || {};

    if (!attemptId || !eventType) {
      return res.status(400).json({ success: false, message: 'Missing attemptId or eventType' });
    }

    if (!EVENT_TYPES.has(eventType)) {
      return res.status(400).json({ success: false, message: 'Invalid eventType' });
    }

    const ts = timestamp ? new Date(timestamp) : new Date();
    if (Number.isNaN(ts.getTime())) {
      return res.status(400).json({ success: false, message: 'Invalid timestamp' });
    }

    // Validate attempt ownership + active attempt.
    const attempt = await prisma.quizAttempt.findFirst({
      where: { id: attemptId, userId },
      select: { id: true, status: true },
    });

    if (!attempt) {
      return res.status(404).json({ success: false, message: 'Attempt not found' });
    }

    if (attempt.status !== 'in_progress') {
      // Do not allow tracking for inactive attempts.
      return res.status(200).json({ success: true, data: { ignored: true } });
    }

    // Rate-limit + dedupe: store at most 1 event of the same type per 3 seconds.
    const windowMs = 3000;
    const recent = await prisma.monitoringEvent.findFirst({
      where: {
        attemptId,
        eventType,
        createdAt: { gte: new Date(Date.now() - windowMs) },
      },
      select: { id: true },
    });

    if (recent) {
      return res.status(200).json({ success: true, data: { deduped: true } });
    }

    const created = await prisma.monitoringEvent.create({
      data: {
        attemptId,
        userId,
        eventType,
        occurredAt: ts,
        metadata: safeJson(metadata),
        ipAddress: req.ip,
        userAgent: req.get('User-Agent') || null,
      },
      select: { id: true },
    });

    return res.status(201).json({ success: true, data: { id: created.id } });
  } catch (err) {
    console.error('track-monitoring-event error:', err);
    return res.status(500).json({ success: false, message: 'Failed to track event' });
  }
});

export default router;

