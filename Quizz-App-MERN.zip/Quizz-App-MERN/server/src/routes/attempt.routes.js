import express from 'express';
import { prisma } from '../config/prisma.js';

const router = express.Router();

// Start a new quiz attempt
router.post('/start', async (req, res) => {
  try {
    const { quizId, userId } = req.body;

    // Validate quiz exists
    const quiz = await prisma.quiz.findUnique({
      where: { id: quizId }
    });

    if (!quiz) {
      return res.status(404).json({
        success: false,
        message: 'Quiz not found'
      });
    }

    // Check if user already has an in-progress attempt
    const existingAttempt = await prisma.quizAttempt.findFirst({
      where: {
        quizId,
        userId,
        status: 'in_progress'
      }
    });

    if (existingAttempt) {
      return res.status(400).json({
        success: false,
        message: 'You already have an in-progress attempt for this quiz'
      });
    }

    // Check if max attempts reached
    if (quiz.maxAttempts > 0) {
      const attemptCount = await prisma.quizAttempt.count({
        where: {
          quizId,
          userId,
          status: { in: ['submitted', 'auto_submitted'] }
        }
      });

      if (attemptCount >= quiz.maxAttempts) {
        return res.status(400).json({
          success: false,
          message: 'Maximum attempts reached for this quiz'
        });
      }
    }

    // Get questions for the quiz
    let questions = await prisma.question.findMany({
      where: { quizId },
      select: {
        id: true,
        questionText: true,
        questionType: true,
        options: true,
        marks: true,
        difficulty: true
      }
    });

    // Shuffle questions if configured
    if (quiz.shuffleQuestions) {
      questions = questions.sort(() => Math.random() - 0.5);
    }

    // Shuffle options if configured
    if (quiz.shuffleOptions) {
      questions = questions.map(q => {
        if (q.options && Array.isArray(q.options)) {
          return {
            ...q,
            options: q.options.sort(() => Math.random() - 0.5)
          };
        }
        return q;
      });
    }

    // Create attempt
    const attempt = await prisma.quizAttempt.create({
      data: {
        quizId,
        userId,
        answers: {
          create: questions.map(q => ({
            questionId: q.id,
            selectedOption: null,
            isCorrect: false,
            timeSpent: 0
          }))
        },
        status: 'in_progress',
        ipAddress: req.ip,
        userAgent: req.get('User-Agent'),
        screenResolution: req.headers['screen-resolution'],
        timezone: req.headers['timezone']
      },
      include: {
        answers: {
          include: {
            question: {
              select: {
                id: true,
                questionText: true,
                questionType: true,
                options: true,
                marks: true
              }
            }
          }
        }
      }
    });

    res.status(201).json({
      success: true,
      data: {
        attemptId: attempt.id,
        duration: quiz.duration,
        questions: attempt.answers.map(a => ({
          id: a.question.id,
          questionText: a.question.questionText,
          questionType: a.question.questionType,
          options: a.question.options,
          marks: a.question.marks,
          answerId: a.id
        })),
        allowReview: quiz.allowReview,
        startedAt: attempt.startedAt
      }
    });

  } catch (error) {
    console.error('Error starting quiz attempt:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to start quiz attempt'
    });
  }
});

// Submit quiz attempt
router.post('/submit', async (req, res) => {
  try {
    const { attemptId, userId } = req.body;
    const { answers } = req.body;

    const attempt = await prisma.quizAttempt.findFirst({
      where: {
        id: attemptId,
        userId,
        status: 'in_progress'
      },
      include: {
        quiz: true,
        answers: {
          include: {
            question: true
          }
        }
      }
    });

    if (!attempt) {
      return res.status(404).json({
        success: false,
        message: 'Attempt not found or already submitted'
      });
    }

    // Update answers
    if (answers) {
      for (const userAnswer of answers) {
        await prisma.attemptAnswer.update({
          where: { id: userAnswer.answerId },
          data: {
            selectedOption: userAnswer.selectedOption
          }
        });
      }
    }

    // Calculate score
    let correctCount = 0;
    let totalMarks = 0;
    let obtainedMarks = 0;

    for (const attemptAnswer of attempt.answers) {
      const question = attemptAnswer.question;
      totalMarks += question.marks || 1;
      
      const userAnswer = answers?.find(a => a.questionId === question.id);
      if (userAnswer) {
        const isCorrect = JSON.stringify(userAnswer.selectedOption) === JSON.stringify(question.correctOption);
        
        await prisma.attemptAnswer.update({
          where: { id: attemptAnswer.id },
          data: { isCorrect }
        });

        if (isCorrect) {
          correctCount++;
          obtainedMarks += question.marks || 1;
        }
      }
    }

    const percentage = totalMarks > 0 ? (obtainedMarks / totalMarks) * 100 : 0;

    // Update attempt
    await prisma.quizAttempt.update({
      where: { id: attemptId },
      data: {
        score: obtainedMarks,
        percentage,
        status: 'submitted',
        submittedAt: new Date(),
        timeSpent: Math.floor((new Date() - attempt.startedAt) / 1000),
        resultVisible: attempt.quiz.showResultImmediately
      }
    });

    res.json({
      success: true,
      data: {
        score: obtainedMarks,
        percentage,
        totalQuestions: attempt.answers.length,
        correctAnswers: correctCount,
        passed: percentage >= attempt.quiz.passingScore,
        resultVisible: attempt.quiz.showResultImmediately
      }
    });

  } catch (error) {
    console.error('Error submitting quiz attempt:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to submit quiz attempt'
    });
  }
});

// Auto-submit quiz (due to violations or timeout)
router.post('/auto-submit', async (req, res) => {
  try {
    const { attemptId, userId, reason } = req.body;

    const attempt = await prisma.quizAttempt.findFirst({
      where: {
        id: attemptId,
        userId,
        status: 'in_progress'
      },
      include: {
        quiz: true,
        answers: {
          include: {
            question: true
          }
        }
      }
    });

    if (!attempt) {
      return res.status(404).json({
        success: false,
        message: 'Attempt not found or already submitted'
      });
    }

    // Calculate score with current answers
    let correctCount = 0;
    let totalMarks = 0;
    let obtainedMarks = 0;

    for (const attemptAnswer of attempt.answers) {
      const question = attemptAnswer.question;
      totalMarks += question.marks || 1;
      
      if (attemptAnswer.selectedOption && 
          JSON.stringify(attemptAnswer.selectedOption) === JSON.stringify(question.correctOption)) {
        correctCount++;
        obtainedMarks += question.marks || 1;
        
        await prisma.attemptAnswer.update({
          where: { id: attemptAnswer.id },
          data: { isCorrect: true }
        });
      } else {
        await prisma.attemptAnswer.update({
          where: { id: attemptAnswer.id },
          data: { isCorrect: false }
        });
      }
    }

    const percentage = totalMarks > 0 ? (obtainedMarks / totalMarks) * 100 : 0;

    // Get violations for this attempt
    const violations = await prisma.violation.findMany({
      where: {
        userId,
        quizId: attempt.quizId,
        timestamp: { gte: attempt.startedAt }
      },
      orderBy: { timestamp: 'desc' }
    });

    // Create violation records for the attempt
    for (const violation of violations) {
      await prisma.violationRecord.create({
        data: {
          attemptId,
          type: violation.type,
          timestamp: violation.timestamp,
          warningCount: violation.warningCount
        }
      });
    }

    // Update attempt
    await prisma.quizAttempt.update({
      where: { id: attemptId },
      data: {
        score: obtainedMarks,
        percentage,
        status: 'auto_submitted',
        submittedAt: new Date(),
        timeSpent: Math.floor((new Date() - attempt.startedAt) / 1000)
      }
    });

    console.log(`Quiz auto-submitted for user ${userId}. Reason: ${reason}`);

    res.json({
      success: true,
      message: `Quiz auto-submitted due to: ${reason}`,
      data: {
        score: obtainedMarks,
        percentage,
        violations: violations.length
      }
    });

  } catch (error) {
    console.error('Error auto-submitting quiz:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to auto-submit quiz'
    });
  }
});

// Save answer progress
router.put('/save-answer', async (req, res) => {
  try {
    const { attemptId, userId, answerId, selectedOption } = req.body;

    const attempt = await prisma.quizAttempt.findFirst({
      where: {
        id: attemptId,
        userId,
        status: 'in_progress'
      }
    });

    if (!attempt) {
      return res.status(404).json({
        success: false,
        message: 'Attempt not found or already submitted'
      });
    }

    // Update the answer
    await prisma.attemptAnswer.update({
      where: { id: answerId },
      data: { selectedOption }
    });

    res.json({
      success: true,
      message: 'Answer saved successfully'
    });

  } catch (error) {
    console.error('Error saving answer:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to save answer'
    });
  }
});

// Get user's attempts for a quiz
router.get('/user/:userId/quiz/:quizId', async (req, res) => {
  try {
    const { userId, quizId } = req.params;

    const attempts = await prisma.quizAttempt.findMany({
      where: {
        userId,
        quizId
      },
      include: {
        quiz: {
          select: {
            id: true,
            title: true,
            duration: true,
            passingScore: true,
            allowReview: true,
            allowRetry: true,
            showResultImmediately: true,
            shuffleQuestions: true,
            shuffleOptions: true,
            proctoredMode: true,
            maxViolations: true
          }
        }
      },
      orderBy: { startedAt: 'desc' }
    });

    res.json({
      success: true,
      data: attempts
    });

  } catch (error) {
    console.error('Error fetching attempts:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch attempts'
    });
  }
});

// Get attempt details
router.get('/:attemptId', async (req, res) => {
  try {
    const { attemptId } = req.params;
    const { userId } = req.query;

    const attempt = await prisma.quizAttempt.findUnique({
      where: { id: attemptId },
      include: {
        quiz: {
          select: {
            id: true,
            title: true,
            subject: true,
            passingScore: true,
            allowReview: true,
            allowRetry: true,
            showResultImmediately: true,
            shuffleQuestions: true,
            shuffleOptions: true,
            proctoredMode: true,
            maxViolations: true
          }
        },
        answers: {
          include: {
            question: {
              select: {
                id: true,
                questionText: true,
                questionType: true,
                options: true,
                marks: true,
                correctOption: true
              }
            }
          }
        },
        violations: true
      }
    });

    if (!attempt) {
      return res.status(404).json({
        success: false,
        message: 'Attempt not found'
      });
    }

    // Hide correct answers if result is not visible
    if (!attempt.resultVisible) {
      attempt.answers = attempt.answers.map(a => ({
        ...a,
        question: {
          ...a.question,
          correctOption: undefined
        }
      }));
    }

    res.json({
      success: true,
      data: attempt
    });

  } catch (error) {
    console.error('Error fetching attempt:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch attempt'
    });
  }
});

// Get quiz analytics for admin
router.get('/quiz/:quizId/analytics', async (req, res) => {
  try {
    const { quizId } = req.params;

    // Get quiz details
    const quiz = await prisma.quiz.findUnique({
      where: { id: quizId }
    });

    if (!quiz) {
      return res.status(404).json({
        success: false,
        message: 'Quiz not found'
      });
    }

    // Get all completed attempts
    const attempts = await prisma.quizAttempt.findMany({
      where: {
        quizId,
        status: { in: ['submitted', 'auto_submitted'] }
      },
      include: {
        user: {
          select: { id: true, name: true, email: true }
        }
      }
    });

    const totalAttempts = attempts.length;
    const passedAttempts = attempts.filter(a => a.percentage >= quiz.passingScore).length;
    const averageScore = totalAttempts > 0 
      ? attempts.reduce((sum, a) => sum + a.percentage, 0) / totalAttempts 
      : 0;
    const averageTime = totalAttempts > 0
      ? attempts.reduce((sum, a) => sum + a.timeSpent, 0) / totalAttempts
      : 0;

    // Score distribution
    const scoreRanges = [
      { range: '0-20%', count: 0 },
      { range: '21-40%', count: 0 },
      { range: '41-60%', count: 0 },
      { range: '61-80%', count: 0 },
      { range: '81-100%', count: 0 }
    ];

    attempts.forEach(attempt => {
      const percentage = attempt.percentage;
      if (percentage <= 20) scoreRanges[0].count++;
      else if (percentage <= 40) scoreRanges[1].count++;
      else if (percentage <= 60) scoreRanges[2].count++;
      else if (percentage <= 80) scoreRanges[3].count++;
      else scoreRanges[4].count++;
    });

    // Top performers
    const topPerformers = attempts
      .sort((a, b) => b.percentage - a.percentage)
      .slice(0, 10)
      .map(a => ({
        userId: a.userId,
        userName: a.user?.name,
        userEmail: a.user?.email,
        score: a.percentage,
        timeSpent: a.timeSpent,
        submittedAt: a.submittedAt
      }));

    res.json({
      success: true,
      data: {
        totalAttempts,
        passedAttempts,
        passRate: totalAttempts > 0 ? (passedAttempts / totalAttempts) * 100 : 0,
        averageScore: Math.round(averageScore * 100) / 100,
        averageTime: Math.round(averageTime),
        scoreDistribution: scoreRanges,
        topPerformers
      }
    });

  } catch (error) {
    console.error('Error fetching quiz analytics:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch analytics'
    });
  }
});

export default router;