import { Router } from "express";
import {
  getQuestions,
  getQuestionById,
  createQuestion,
  createManyQuestions,
  updateQuestion,
  deleteQuestion,
} from "../controllers/questions/crud.js";
import { getQuestionByTopicId } from "../controllers/questions/getQuestionsByTopicId.js";
import { protect } from "../middlewares/authMiddleware.js";
import { authorize } from "../middlewares/authorize.js";

const questionsRoutes = Router();
const staffAdmin = [protect, authorize("STAFF", "ADMIN")];

questionsRoutes.get("/", getQuestions);
questionsRoutes.get("/topic/:id", getQuestionByTopicId);
questionsRoutes.get("/:id", getQuestionById);
questionsRoutes.post("/", ...staffAdmin, createQuestion);
questionsRoutes.post("/many", ...staffAdmin, createManyQuestions);
questionsRoutes.put("/:id", ...staffAdmin, updateQuestion);
questionsRoutes.delete("/:id", ...staffAdmin, deleteQuestion);

export default questionsRoutes;
