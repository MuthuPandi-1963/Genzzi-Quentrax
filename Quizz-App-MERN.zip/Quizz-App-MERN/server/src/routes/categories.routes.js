import { Router } from "express";
import { createCategory, createManyCategories, deleteCategory, getCategories, getCategoryById, updateCategory } from "../controllers/categories/crud.js";
import { protect } from "../middlewares/authMiddleware.js";
import { authorize } from "../middlewares/authorize.js";

const categoryRoutes = Router();
const staffAdmin = [protect, authorize("STAFF", "ADMIN")];

categoryRoutes.get("/", getCategories);
categoryRoutes.get("/:id", getCategoryById);
categoryRoutes.post("/", ...staffAdmin, createCategory);
categoryRoutes.post("/many", ...staffAdmin, createManyCategories);
categoryRoutes.put("/:id", ...staffAdmin, updateCategory);
categoryRoutes.delete("/:id", ...staffAdmin, deleteCategory);

export default categoryRoutes;
