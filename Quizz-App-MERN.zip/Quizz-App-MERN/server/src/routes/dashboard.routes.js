import { Router } from "express";
import { protect } from "../middlewares/authMiddleware.js";
import { authorize } from "../middlewares/authorize.js";
import {
  getAdminDashboard,
  getStaffDashboard,
  getStudentDashboard,
  getAnalytics,
} from "../controllers/dashboard/stats.js";

const dashboardRoutes = Router();

dashboardRoutes.use(protect);

dashboardRoutes.get("/admin", authorize("ADMIN"), getAdminDashboard);
dashboardRoutes.get("/staff", authorize("STAFF", "ADMIN"), getStaffDashboard);
dashboardRoutes.get("/student", authorize("STUDENT"), getStudentDashboard);
dashboardRoutes.get("/analytics", authorize("STAFF", "ADMIN"), getAnalytics);

export default dashboardRoutes;
