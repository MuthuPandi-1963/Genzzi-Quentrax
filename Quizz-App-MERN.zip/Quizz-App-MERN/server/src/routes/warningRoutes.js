const express = require('express');
const router = express.Router();
const Warning = require('../models/Warning');
const Quiz = require('../models/Quiz');
const User = require('../models/User');

// Track warning/violation
router.post('/track-warning', async (req, res) => {
  try {
    const { type, timestamp, quizId, userId, warningCount } = req.body;

    // Validate required fields
    if (!type || !quizId || !userId) {
      return res.status(400).json({
        success: false,
        message: 'Missing required fields'
      });
    }

    // Create warning record
    const warning = new Warning({
      user: userId,
      quiz: quizId,
      type,
      timestamp: timestamp || new Date(),
      metadata: {
        warningCount,
        ipAddress: req.ip,
        userAgent: req.get('User-Agent')
      }
    });

    await warning.save();

    // Update quiz violations count
    await Quiz.findByIdAndUpdate(quizId, {
      $inc: { totalViolations: 1 },
      $push: { recentViolations: { type, timestamp: new Date() } }
    });

    console.log('Violation Detected:', {
      type,
      userId,
      quizId,
      warningCount,
      timestamp
    });

    res.status(201).json({
      success: true,
      warningId: warning._id,
      warningCount: warningCount || 1
    });

  } catch (error) {
    console.error('Error tracking warning:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to track warning'
    });
  }
});

// Get warnings for a specific quiz
router.get('/quiz/:quizId/warnings', async (req, res) => {
  try {
    const { quizId } = req.params;
    const { page = 1, limit = 50, type, userId } = req.query;

    const query = { quiz: quizId };
    if (type) query.type = type;
    if (userId) query.user = userId;

    const warnings = await Warning.find(query)
      .populate('user', 'name email')
      .sort({ timestamp: -1 })
      .limit(limit * 1)
      .skip((page - 1) * limit);

    const count = await Warning.countDocuments(query);

    res.json({
      success: true,
      data: warnings,
      totalPages: Math.ceil(count / limit),
      currentPage: page,
      total: count
    });

  } catch (error) {
    console.error('Error fetching warnings:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch warnings'
    });
  }
});

// Get warnings for a specific user
router.get('/user/:userId/warnings', async (req, res) => {
  try {
    const { userId } = req.params;
    const { page = 1, limit = 50 } = req.query;

    const warnings = await Warning.find({ user: userId })
      .populate('quiz', 'title subject')
      .sort({ timestamp: -1 })
      .limit(limit * 1)
      .skip((page - 1) * limit);

    const count = await Warning.countDocuments({ user: userId });

    res.json({
      success: true,
      data: warnings,
      totalPages: Math.ceil(count / limit),
      currentPage: page,
      total: count
    });

  } catch (error) {
    console.error('Error fetching user warnings:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch warnings'
    });
  }
});

// Get analytics for warnings
router.get('/analytics', async (req, res) => {
  try {
    const { startDate, endDate, quizId } = req.query;

    const query = {};
    if (startDate && endDate) {
      query.timestamp = {
        $gte: new Date(startDate),
        $lte: new Date(endDate)
      };
    }
    if (quizId) {
      query.quiz = quizId;
    }

    // Group by type
    const violationsByType = await Warning.aggregate([
      { $match: query },
      {
        $group: {
          _id: '$type',
          count: { $sum: 1 },
          users: { $addToSet: '$user' }
        }
      },
      {
        $project: {
          type: '$_id',
          count: 1,
          uniqueUsers: { $size: '$users' }
        }
      }
    ]);

    // Total violations
    const totalViolations = await Warning.countDocuments(query);
    
    // Unique users with violations
    const uniqueUsers = await Warning.distinct('user', query);

    // Violations over time (daily)
    const violationsOverTime = await Warning.aggregate([
      { $match: query },
      {
        $group: {
          _id: {
            $dateToString: { format: '%Y-%m-%d', date: '$timestamp' }
          },
          count: { $sum: 1 }
        }
      },
      { $sort: { _id: 1 } }
    ]);

    res.json({
      success: true,
      data: {
        totalViolations,
        uniqueUsers: uniqueUsers.length,
        violationsByType,
        violationsOverTime
      }
    });

  } catch (error) {
    console.error('Error fetching analytics:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch analytics'
    });
  }
});

// Export warnings as CSV
router.get('/export/csv', async (req, res) => {
  try {
    const { quizId, startDate, endDate } = req.query;

    const query = {};
    if (quizId) query.quiz = quizId;
    if (startDate && endDate) {
      query.timestamp = {
        $gte: new Date(startDate),
        $lte: new Date(endDate)
      };
    }

    const warnings = await Warning.find(query)
      .populate('user', 'name email')
      .populate('quiz', 'title subject')
      .sort({ timestamp: -1 });

    // CSV header
    const headers = ['Timestamp', 'User Name', 'User Email', 'Quiz Title', 'Violation Type', 'Warning Count', 'IP Address'];
    
    // CSV rows
    const rows = warnings.map(warning => [
      new Date(warning.timestamp).toLocaleString(),
      warning.user?.name || 'N/A',
      warning.user?.email || 'N/A',
      warning.quiz?.title || 'N/A',
      warning.type,
      warning.metadata?.warningCount || 0,
      warning.metadata?.ipAddress || 'N/A'
    ]);

    // Create CSV content
    const csvContent = [
      headers.join(','),
      ...rows.map(row => row.map(cell => `"${cell}"`).join(','))
    ].join('\n');

    // Set headers for download
    res.setHeader('Content-Type', 'text/csv');
    res.setHeader('Content-Disposition', 'attachment; filename=violations-report.csv');
    
    res.send(csvContent);

  } catch (error) {
    console.error('Error exporting CSV:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to export CSV'
    });
  }
});

module.exports = router;