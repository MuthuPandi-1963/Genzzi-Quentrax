import { Router } from "express";

import { protect } from "../middlewares/authMiddleware.js";
import { authorize } from "../middlewares/authorize.js";

import {
  assignUsersToAssessment,
  getAssignedUsers,
  removeUserFromAssessment,
  updateAssignmentStatus,
} from "../controllers/assessmentController.js";

const router = Router();

router.use(protect);

// Compatibility routes to match the client API contract.
// Base path is /api/assessments
router.post(
  "/:id/assign",
  authorize("ADMIN", "STAFF"),
  assignUsersToAssessment
);

router.get(
  "/:id/users",
  authorize("ADMIN", "STAFF"),
  getAssignedUsers
);

router.delete(
  "/:assessmentId/users/:userId",
  authorize("ADMIN", "STAFF"),
  removeUserFromAssessment
);

router.put(
  "/:assessmentId/users/:userId",
  authorize("ADMIN", "STAFF"),
  updateAssignmentStatus
);

router.get(
  "/users/:userId",
  authorize("ADMIN", "STAFF"),
  (req, res, next) => {
    // assessmentController expects :userId in params
    return next();
  }
);

// We keep /:userId endpoint as defined in assessmentController by mounting below elsewhere.

export default router;

