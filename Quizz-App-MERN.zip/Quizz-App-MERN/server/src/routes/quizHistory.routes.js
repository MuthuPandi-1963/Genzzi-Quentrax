import { Router } from "express";
import {
  createQuizHistory,
  getUserQuizHistory,
  getQuizHistoryById,
  getAllQuizHistory,
} from "../controllers/quizHistory/crud.js";
import { protect } from "../middlewares/authMiddleware.js";
import { authorize } from "../middlewares/authorize.js";

const quizHistoryRoutes = Router();

quizHistoryRoutes.use(protect);

quizHistoryRoutes.post("/", createQuizHistory);
quizHistoryRoutes.get("/users", authorize("STAFF", "ADMIN"), getAllQuizHistory);
quizHistoryRoutes.get("/user/:userId", getUserQuizHistory);
quizHistoryRoutes.get("/:id", getQuizHistoryById);

export default quizHistoryRoutes;
