import { Router } from "express";
import { getUserById, getUsers } from "../controllers/users/getUsers.js";
import {
  createUser,
  updateUser,
  deleteUser,
  updateProfile,
  changePassword,
} from "../controllers/users/crud.js";
import { protect } from "../middlewares/authMiddleware.js";
import { authorize } from "../middlewares/authorize.js";

const userRoutes = Router();

userRoutes.get("/", protect, authorize("STAFF", "ADMIN"), getUsers);
userRoutes.get("/:id", protect, getUserById);
userRoutes.post("/", protect, authorize("STAFF", "ADMIN"), createUser);
userRoutes.put("/profile", protect, updateProfile);
userRoutes.put("/password", protect, changePassword);
userRoutes.put("/:id", protect, authorize("STAFF", "ADMIN"), updateUser);
userRoutes.delete("/:id", protect, authorize("ADMIN"), deleteUser);

export default userRoutes;
