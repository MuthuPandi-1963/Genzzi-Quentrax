-- AlterTable
ALTER TABLE "public"."Assessment" ADD COLUMN     "allowRetry" BOOLEAN NOT NULL DEFAULT true,
ADD COLUMN     "allowReview" BOOLEAN NOT NULL DEFAULT true,
ADD COLUMN     "maxAttempts" INTEGER NOT NULL DEFAULT 1,
ADD COLUMN     "maxViolations" INTEGER NOT NULL DEFAULT 3,
ADD COLUMN     "passingScore" INTEGER NOT NULL DEFAULT 50,
ADD COLUMN     "proctoredMode" BOOLEAN NOT NULL DEFAULT false,
ADD COLUMN     "showResultImmediately" BOOLEAN NOT NULL DEFAULT true,
ADD COLUMN     "shuffleOptions" BOOLEAN NOT NULL DEFAULT false,
ADD COLUMN     "shuffleQuestions" BOOLEAN NOT NULL DEFAULT false,
ADD COLUMN     "topicId" TEXT;

-- CreateIndex
CREATE INDEX "Assessment_topicId_idx" ON "public"."Assessment"("topicId");

-- AddForeignKey
ALTER TABLE "public"."Assessment" ADD CONSTRAINT "Assessment_topicId_fkey" FOREIGN KEY ("topicId") REFERENCES "public"."Topic"("id") ON DELETE SET NULL ON UPDATE CASCADE;
